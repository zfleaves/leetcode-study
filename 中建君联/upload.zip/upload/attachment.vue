<template>
  <div class="attachment">
    <div class="upload-file" v-if="attachmentConfig.editAttachment">
      <uploadFile :flowStatus="true" :attachmentConfig="attachmentConfig" :attachment.sync="uploadAttachment">
      </uploadFile>
    </div>
    <el-table :data="cloneGridData" border stripe height="500">
      <template slot="empty">
        <no-data>
        </no-data>
      </template>
      <el-table-column prop="fileName" :label="$t('fConfig.fileName')">
        <template slot-scope="scope">
          <span>{{scope.row.fileName | fileNameFilter}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="fileSuffix" :label="$t('fConfig.fileSuffix')"  width="100">
      </el-table-column>
      <el-table-column prop="fileSize" :label="$t('fConfig.fileSize')" width="100">
        <template slot-scope="scope">
          <span>{{scope.row.fileSize}}KB</span>
        </template>
      </el-table-column>
      <el-table-column :label="$t('fConfig.operate')" fixed="right" width="150" align="center">
        <template slot-scope="scope">
          <div class="popover-img">
            <span
              slot="reference"
              class="midFont set"
              style="min-width: 60px;"
              v-if="judgeFileImage(scope.row.fileSuffix)"
              @click="handleImageViewer(scope.row)"
              type="text" size="small">
              {{$t('button.info')}}
            </span>
            <span
              slot="reference"
              class="midFont set"
              style="min-width: 60px;" v-if="judgeFile(scope.row.fileSuffix)"
              @click="handleFileInfo(scope.row)"
              type="text" size="small">
              {{$t('button.info')}}
            </span>
            <div style="min-width: 60px;display: inline-block;text-decoration: none;"
               @click="downFilePath(scope.row)">
              <span type="text" class="midFont set" size="small" :disabled="false">{{$t('button.download')}}</span>
            </div>
            <div
              v-if="attachmentConfig.editAttachment"
              class="midFont error"
              style="min-width: 60px;"
              @click="handleDelete(scope.row)"
              type="text" size="small">
              {{$t('button.delete')}}
            </div>
          </div>
        </template>
      </el-table-column>
    </el-table>

    <imageViewer
      v-if="visible"
      :image-viewer-list="imageViewerList"
      @clearImg="getClearImg"
      :current-img="currentImg" :visible="visible">
    </imageViewer>


  </div>
</template>

<script>
  import config from 'util/config';

  export default {
    name: 'attachment',
    inject: ['reload', 'reloadPage'],
    components: {
      imageViewer (resolve) {
        require(['./imageViewer.vue'], resolve);
      },
      uploadFile(resolve) {
        require(['./uploadFile.vue'], resolve);
      }
    },
    data () {
      return {
        imageUrl: config.imageUrl,
        viewerShow: false,
        maskBtn: false,
        currentImg: '',
        visible: false,
        fileViewShow: false,
        fileId: '',
        uploadAttachment: '',
        cloneGridData: [],
        dataAttachment: ''
      };
    },
    props: {
      gridData: {
        default: () => []
      },
      mainId: {
        default: 0
      },
      attachmentConfig: {
        default: () => {
          return {
            editAttachment: false
          };
        }
      }
    },
    computed: {
      imageViewerList () {
        if (this.gridData.length === 0) return;
        const arr = [];
        for (const i in this.gridData) {
          const item = this.gridData[i];
          item.imagePath = this.imageUrl + item.filePath;
          arr.push(item);
        }
        return arr;
      }
    },
    created() {
      this.cloneGridData = this.$clone(this.gridData);
    },
    filters: {
      filterFile (val) {
        if (/jpg|bmp|gif|ico|pcx|jpeg|tif|png|raw|tga/.test(val)) {
          return false;
        } else {
          return true;
        }
      },
      fileNameFilter (val) {
        return val ? val.substr(0, val.lastIndexOf('_')) : '';
      }
    },
    watch: {
      uploadAttachment: {
        handler() {
          this._uploadAttachment('upload');
        },
        deep: true
      }
    },
    methods: {
      // 文件名称
      fileNameFilvalter(item) {
        const fileName = item.fileName ? item.fileName.substr(0, item.fileName.lastIndexOf('_')) : '';
        return fileName ? `${fileName}.${item.fileSuffix}` : '';
      },
      judgeFileImage (val) {
        val = val.toLowerCase();
        return /jpg|bmp|gif|ico|pcx|jpeg|tif|png|raw|tga/.test(val);
      },
      judgeFile (val) {
        val = val.toLowerCase();
        return /ppt|doc|xls|xlsx|txt|docx|pptx|pdf/.test(val);
      },
      handleClickGridData () {
        this.viewerShow = true;
      },
      handleImageViewer (row) {
        this.currentImg = this.imageUrl + row.filePath;
        this.visible = true;
      },
      getClearImg () {
        this.visible = false;
      },
      // 下载图片资源
      downFilePath (row) {
        const url = `${config.fileCmsUrl}${row.id}`;
        const link = document.createElement('a');
        link.style.display = 'none';
        link.target = '_Blank';
        link.href = url;
        link.target = '_Blank';
        const fileName = this.fileNameFilvalter(row);
        link.setAttribute('download', fileName);
        document.body.appendChild(link);
        link.click();
      },
      // 文件预览
      handleFileInfo (row) {
        // const fileName = this.fileNameFilvalter(row);
        // const downloadUrl = `${this.$utils.config.url}/file/api/local/download?fileId=${row.id}&fullfilename=${fileName}`;
        // const url = `${this.$utils.config.fileViewerUrl}${encodeURIComponent(downloadUrl)}`;
        // window.open(url);
        window.open(`${this.$utils.config.fileViewUrl}${row.id}`);
      },
      // 删除
      handleDelete(row) {
        this.cloneGridData.splice(this.cloneGridData.indexOf(row), 1);
        this._uploadAttachment('delete');
      },
      // 上传附件
      _uploadAttachment(type) {
        const ids = this.cloneGridData.map(v => JSON.stringify(v.id));
        const uploadAttachment = this.uploadAttachment.split(',');
        const data = ids.concat(uploadAttachment);
        const filterData = Array.from(new Set((data))).filter(v => v);
        this.dataAttachment = filterData.join(',');
        this.$store.dispatch(this.attachmentConfig.url, {[this.attachmentConfig.receiveId]: this.mainId, attachment: this.dataAttachment}).then(res => {
          if (res.status === 0) {
            this.getFile();
            this.reloadPage();
          } else {
            this.$message.error(`${this.$t(`exception.${res.errorCode}`)}${this.$t(`button.${type}`)}${this.$t('tips.fail')}!`);
          }
        });
      },
      // 获取文件
      getFile() {
        const attachmentIdList = this.dataAttachment.split(',');
        const data = {
          fileIds: attachmentIdList.map((item) => (item = Number(item)))
        };
        this.$store.dispatch('publicApi/getFilepath', data).then(res => {
          this.cloneGridData = res.results;
        });
      }
    }
  };
</script>

<style scoped lang="scss">
.attachment{
  width: 100%;
  padding: 20px;
  box-sizing: border-box;
}
.upload-file{
  height: 40px;
  line-height: 40px;
  width: 30%;
}
  .popover-img {
    display: flex;
    justify-content: space-around;
    align-items: center;
    img {
      margin: 0 auto;
    }
    .img-show-mask {
      width: 100%;
      height: 100%;
      position: absolute;
      left: 0;
      top: 0;
      z-index: 3000;
      background: rgba(0, 0, 0, .5);
    }

    .img-show-mask .bigImg {
      width: 500px;
      height: 280px;
      position: absolute;
      z-index: 3100;
      top: 0;
      left: 0;
      margin: auto;
    }
  }
</style>
