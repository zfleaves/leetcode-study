<template>
  <div class="uploadFileWrap">
    <ul :class="!flowStatus?'info':''" v-if="imgUrlList.length > 0">
      <li>
        <el-dropdown size="height:40px;">
          <p class="set" style=" white-space: nowrap;text-overflow: ellipsis;overflow:hidden;">
            {{imgUrlList[0].fileName | fileNameFilter}}</p>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item :key="item.id" v-for="(item,index) in imgUrlList">
              {{item.fileName | fileNameFilter}}
              <span v-if="!attachmentConfig.editAttachment" v-show="flowStatus" @click="deleltImages(index)"
                style="float: right;margin-left: 6px;">
                <i class="el-icon-circle-close"></i>
              </span>
            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </li>
    </ul>
    <el-upload v-if="flowStatus" style=" vertical-align: middle;display: inline-block;height: 100%;" :action="fileUrl"
      :headers="myHeaders" :data="fileName" ref="upload" :multiple="multiple" :limit="limit" :on-exceed='handleExceed'
      :file-list="imgUrlList" :on-error="handleError" :on-change="imgPreview" :on-success="handleSuccess"
      :on-remove="handleRemove" :before-upload="beforeAvatarUpload">
      <el-button class="uploadBtn" :disabeld="uploadTitle=== `${$t('tips.uploadTitleLoading1')}...'`" size="mini"
        style="vertical-align: middle;" type="text">
        <span style="font-size: 12px;">{{title}}</span>
      </el-button>
    </el-upload>
    <template>
      <span v-if="!attachmentConfig.editAttachment" v-show="imgUrlList.length > 0" @click="handleGridData"
        class="uploadBtn findFiles smallFont set" type="text">{{$t('button.info')}}({{imgUrlList.length}})
      </span>
    </template>
    <span v-if="imgUrlList.length===0 && !flowStatus">{{$t('tips.noFile')}}</span>

    <!-- 附件弹框 -->
    <el-dialog class="el-dialog-auto" :title="$t('tips.fileList')" append-to-body v-if="dialogGridData"
      :visible.sync="dialogGridData" width="70%">
      <attachment :gridData="gridData">
      </attachment>
    </el-dialog>
  </div>
</template>

<script>
import Auth from 'util/auth';
import config from 'util/config';

export default {
  name: 'upload-file',
  components: {
    attachment (resolve) {
      require(['./attachment.vue'], resolve);
    }
  },
  data () {
    return {
      fileUrl: config.fileTenantUrl,
      myHeaders: {
        'Access-Token': Auth.hasToken(),
        'Access-Domain': 'customer',
        userId: Auth.hasUserInfo().userId,
        Language: Auth.hasLanguage(),
        'resource': 'P2'
      },
      fileName: {
        fileName: '',
        subSystemCode: config.subSystemCode
      },
      imgUrlList: [],
      gridData: [],
      uploadTitle: this.$t('tips.uploadTitle1'),
      title: this.$t('tips.uploadTitle1'),
      dialogGridData: false,
      firstImgUrl: {}
    };
  },
  props: {
    flowStatus: {
      type: Boolean,
      default: true
    },
    attachment: {
      type: String,
      default: ''
    },
    limit: {
      type: Number,
      default: 10
    },
    multiple: {
      type: Boolean,
      default: true
    },
    attachmentConfig: {
      default: () => {
        return {
          editAttachment: false
        };
      }
    }
  },
  watch: {
    attachment: {
      handler () {
        this.getGridData();
      },
      immediate: true
    }
  },
  methods: {
    // 获取文件
    getGridData () {
      if (this.attachment) {
        const attachmentIdList = this.attachment.split(',');
        const params = {
          fileIds: attachmentIdList
        };
        this.$store.dispatch('publicApi/getFilepath', params).then(res => {
          if (!res.results.length) return;
          this.imgUrlList = res.results;
          this.gridData = res.results;
        });
      }
    },
    // 点击查看文件
    handleGridData () {
      this.dialogGridData = true;
    },
    // 移除文件
    deleltImages (index) {
      this.$confirm(`${this.$t('button.delete')} ${this.imgUrlList[index].fileName}?`, this.$t('button.delete'), {
        confirmButtonText: this.$t('button.determine'),
        cancelButtonText: this.$t('button.close'),
        type: 'warning'
      }).then(() => {
        this.imgUrlList.splice(index, 1); // 假设长度为3
        if (this.imgUrlList.length) {
          const attachment = this.imgUrlList.map(v => v.id).join(',');
          this.$emit('update:attachment', attachment);
        } else {
          this.$emit('update:attachment', '');
        }
      }).catch(() => {
      });
    },
    // 移除文件
    handleRemove () {

    },
    // 文件状态改变时的钩子，添加文件、上传成功和上传失败时都会被调用
    imgPreview () {

    },
    // 文件超出个数限制时的钩子
    handleExceed (files, fileList) {
      this.$message.error(this.$t('tips.limitTips'));
    },
    // 文件上传之前
    beforeAvatarUpload (file) {
      const isLt5M = file.size / 1024 / 1024 < 500;
      if (!isLt5M) {
        this.$message.error(this.$t('tips.isLt5M'));
        return false;
      }
      this.fileName.fileName = file.name;
      this.fileName.sourceCode = this.$route.name;
      this.uploadTitle = this.$t('tips.uploadTitleLoading1');
      this.title = this.$t('tips.uploadTitleLoading1');
      return isLt5M;
    },
    // 文件上传成功
    handleSuccess (response, file, fileList) {
      const timeOut = setTimeout(() => {
        fileList.map(item => {
          if (item.response) {
            item.fileName = item.name;
            item.fileSize = item.size;
            item.id = item.response.results;
          }
        });
        const imgUrlList = fileList.reverse();
        const arr = imgUrlList.map(v => v.id);
        this.$emit('update:attachment', arr.join(','));
        this.$message.success(this.$t('tips.uploadSuccess'));
        this.uploadTitle = this.$t('tips.uploadTitle1');
        this.title = this.$t('button.upload');
        clearTimeout(timeOut);
      }, 100);
    },
    // 文件上传失败
    handleError () {
      this.$message.error(this.$t('tips.uploadFail'));
      this.uploadTitle = this.$t('tips.uploadTitle1');
      this.title = this.$t('button.upload');
    }
  }
};
</script>

<style scoped lang="scss">
.uploadFileWrap {
  font-size: 12px;
  width: 100%;
  height: 36px;
  display: flex;
  align-items: self-end;
  justify-content: center;
  ul {
    width: calc(100% - 130px);
    max-width: calc(100% - 130px);
    height: 100%;
    display: inline-block;
    vertical-align: middle;
    &.info {
      width: calc(100% - 66px);
      max-width: calc(100% - 66px);
    }
    li {
      width: 100%;
      height: 100%;
      list-style: none;
      p {
        width: 100%;
        height: 100%;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        cursor: pointer;
      }
      /deep/ .el-dropdown {
        width: 100%;
      }
    }
  }
  .uploadBtn {
    display: inline-block;
    vertical-align: middle;
    width: 60px;
    height: 100%;
    /*margin: 0 5px;*/
    &.findFiles {
      position: relative;
      top: 0.6px;
    }
  }
}
</style>
