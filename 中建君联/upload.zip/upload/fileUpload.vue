<template>
  <div class="file-upload uploadFileWrap">
    <div class="top" v-if="showSumbit">
      <el-upload
        style="vertical-align: middle; display: inline-block; height: 100%"
        :action="fileUrl"
        :headers="myHeaders"
        :disabled="title=== $t('tips.uploadTitleLoading') || flowStatus"
        :data="fileName"
        ref="upload"
        :multiple="multiple"
        :limit="limit"
        :file-list="imgUrlList"
        :on-error="handleError"
        :on-success="handleSuccess"
        :on-remove="handleRemove"
        :on-exceed='handleExceed'
        :before-upload="beforeAvatarUpload"
      >
        <el-button
          class="uploadBtn"
          icon="el-icon-link"
          :disabled="title === $t('tips.uploadTitleLoading') || flowStatus"
          v-if="title !== $t('tips.uploadTitleLoading')"
          style="vertical-align: middle"
          size="small"
          type="text"
        >
          {{ uploadTitle }}
          <!--添加附件-->
        </el-button>
        <span v-else class="midFont light-grey">{{ uploadTitle }}</span>
      </el-upload>
      <el-progress
        style="width: 10%;display: inline-block;margin-left: 20px"
        v-if="percentage !== 0"
        :percentage="percentage" :color="customColorMethod">
      </el-progress>
      <el-divider direction="vertical"></el-divider>
      <span
        class="midFont grey"
        :style="isImportantTips && 'color: red'"
        v-if="placeholder"
        >{{ $t(placeholder) }}</span
      >
      <span class="midFont" @click="fileShow = !fileShow">
        <i :class="fileShow ? 'el-icon-caret-bottom' : 'el-icon-caret-top'"></i>
      </span>
      <span style="margin-left: 20px" class="midFont"
        >{{ $t("tips.uploadTips") }} {{ filesNum }}{{ $t("tips.uploadTips2") }}
        <span v-if="imgUrlList.length > 0"
          >，{{ $t("tips.uploadTips3") }} {{ fileSizes }}</span
        >
      </span>
      <span class="midFont set" v-if="configParameter && configParameter.filePath" @click="downExampleFilePath(configParameter)">
        <!-- 下载示例模板 -->
        {{ $t("tips.downExampleFile") }}
      </span>
      <br>
      <span class="paste" v-if="!(title === $t('tips.uploadTitleLoading') || flowStatus)">
        <div>
          <div class="img-paste" @paste="handlePaste">
            <!-- 如果您截图了，您可以通过Ctrl+V粘贴至此处 -->
            {{$t('tips.pasteTips')}}
          </div>
        </div>
      </span>
      <span
        class="midFont set"
        style="margin-left: 16px"
        v-if="isIdentify && !flowStatus"
        @click="handleIdentify"
        >{{ $t("dialog.identify") }}</span
      >
    </div>
    <div class="bottom">
      <el-collapse-transition>
        <ul class="files" v-show="fileShow">
          <li
            v-for="(item, index) in imgUrlList"
            :key="item.id"
            :style="{ width: `calc(${100 / arrayNumber}% - 5px)` }"
          >
            <div class="left">
              <img
                v-if="judgeFileImage(item.fileSuffix)"
                :src="imageUrl + item.filePath"
                alt
              />
              <span
                v-else
                class="icon iconfont"
                :class="setClass(item.fileName)"
                style="font-size: 32px !important; margin-left: 8px"
              ></span>
            </div>
            <div class="right">
              <div class="cons">
                <p class="midFont">{{ fileNameFilvalter(item) }}</p>
                <p class="midFont light-grey">
                  {{ handconstransformation(item.fileSize) }}
                </p>
              </div>
              <div class="set">
                <!-- 预览 -->
                <template v-if="!getHandleViewer(item)">
                  <el-tooltip class="item" effect="dark" :content="$t('button.preview')" placement="bottom">
                    <span class="preview" @click="handleViewer(item)">
                      <i class="el-icon-view"></i>
                    </span>
                  </el-tooltip>
                </template>
                <!-- 下载 -->
                <el-tooltip
                  class="item"
                  effect="dark"
                  :content="$t('button.download')"
                  placement="bottom"
                >
                  <span class="download" @click="downFilePath(item)">
                    <i class="el-icon-download"></i>
                  </span>
                </el-tooltip>
                <!-- 删除 -->
                <el-tooltip
                  class="item"
                  effect="dark"
                  :content="$t('button.delete')"
                  placement="bottom"
                >
                  <span
                    class="download"
                    @click="deconsteFile(index)"
                    v-if="!flowStatus"
                  >
                    <i class="el-icon-close"></i>
                  </span>
                </el-tooltip>
              </div>
            </div>
          </li>
        </ul>
      </el-collapse-transition>
    </div>

    <image-viewer
      v-if="visible"
      :image-viewer-list="imageViewerList"
      @clearImg="getClearImg"
      :current-img="currentImg"
      :visible="visible"
    ></image-viewer>
  </div>
</template>

<script>
import Auth from 'util/auth';
import config from 'util/config';

export default {
  name: 'file-upload',
  components: {
    imageViewer(resolve) {
      require(['./imageViewer.vue'], resolve);
    }
  },
  data() {
    return {
      fileUrl: config.fileTenantUrl,
      myHeaders: {
        'Access-Token': Auth.hasToken(),
        'Access-Domain': 'customer',
        userId: Auth.hasUserInfo().userId,
        tenantId: Auth.hasUserInfo().tenantId,
        Language: Auth.hasLanguage(),
        resource: 'P2'
      },
      fileName: {
        fileName: '',
        subSystemCode: config.subSystemCode
      },
      imgUrlList: [],
      gridData: [],
      uploadTitle: this.$t('tips.uploadTitle'),
      dialogGridData: false,
      firstImgUrl: {},
      fileShow: true,
      fileCmsUrl: config.fileViewUrl,
      imageUrl: config.imageUrl, // 图片预览
      visible: false,
      currentImg: '',
      title: '',
      whetherPhoto: '',
      percentage: 0
    };
  },
  props: {
    configParameter: {
      type: Object,
      default: () => {}
    },
    flowStatus: {
      type: Boolean,
      default: true
    },
    attachment: {
      type: String,
      default: ''
    },
    isPhoto: {
      type: Boolean,
      default: false
    },
    isPdf: {
      type: Boolean,
      default: false
    },
    limit: {
      type: Number,
      default: 10
    },
    multiple: {
      type: Boolean,
      default: true
    },
    isShop: {
      type: Boolean,
      default: false
    },
    // 一行li显示个数
    arrayNumber: {
      type: Number,
      default: 4
    },
    isIdentify: {
      // 自动识别
      type: Boolean,
      default: false
    },
    // 是否显示上传按钮
    showSumbit: {
      type: Boolean,
      default: true
    },
    // 提示
    placeholder: {
      type: String,
      default: ''
    },
    isImportantTips: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    filesNum() {
      return this.imgUrlList.length;
    },
    fileSizes() {
      let capacityConut = 0;
      for (const i in this.imgUrlList) {
        const item = this.imgUrlList[i];
        capacityConut += item.fileSize;
      }
      return this.formatFileSize(capacityConut);
    },
    imageViewerList() {
      if (this.imgUrlList.length === 0) return;
      const arr = [];
      for (const i in this.imgUrlList) {
        const item = this.imgUrlList[i];
        const fileSuffix = item.fileSuffix.toLowerCase();
        // 为图片预览
        if (/jpg|bmp|gif|ico|pcx|jpeg|tif|png|raw|tga/.test(fileSuffix)) {
          item.imagePath = this.imageUrl + item.filePath;
          arr.push(item);
        }
      }
      return arr;
    }
  },
  mounted() {
    // console.log(this.limit, this.attachment, 'limit');
  },
  watch: {
    attachment: {
      handler() {
        this.getGridData();
      },
      immediate: true
    }
  },
  methods: {
    customColorMethod(percentage) {
      if (percentage < 30) {
        return '#909399';
      } else if (percentage < 70) {
        return '#e6a23c';
      } else {
        return '#67c23a';
      }
    },
    // 文件名称
    fileNameFilvalter (item) {
      const fileName = item.fileName ? item.fileName.substr(0, item.fileName.lastIndexOf('_')) : '';
      return fileName ? `${fileName}.${item.fileSuffix}` : '';
    },
    // 获取文件
    getGridData () {
      if (this.attachment) {
        const attachmentIdList = this.attachment.split(',');
        const data = {
          fileIds: attachmentIdList.map((item) => (item = Number(item)))
        };
        this.$store.dispatch('publicApi/getFilepath', data).then(res => {
          this.imgUrlList = res.results;
        });
      } else {
        this.imgUrlList = [];
      }
    },
    getClearImg () {
      this.visible = false;
    },
    // 移除文件
    handleRemove(file, fileList) {},
    // 文件超出个数限制时的钩子
    handleExceed (files, fileList) {
      this.$message.error(this.$t('tips.limitTips'));
    },
    // 文件上传之前
    beforeAvatarUpload (file) {
      let isJPG;
      if (this.isPhoto) {
        isJPG = file.type.indexOf('image') >= 0;
      } else {
        isJPG = true;
      }
      const isLt5M = file.size / 1024 / 1024 < 500;
      if (!isJPG) {
        this.$message.error(this.$t('tips.isJPG'));
        return false;
      }
      let isVIDEO;
      if (this.isVideo) {
        isVIDEO = file.type.indexOf('video') >= 0;
      } else {
        isVIDEO = true;
      }
      if (!isVIDEO) {
        this.$message.error(this.$t('tips.isVideo'));
        return false;
      }
      if (!isLt5M) {
        this.$message.error(this.$t('tips.isLt5M'));
      } else {
        console.log(file, 'file');
        this.fileName.fileName = file.name;
        this.uploadTitle = this.$t('tips.uploadTitleLoading');
        this.title = this.$t('tips.uploadTitleLoading'); // '附件上传中'
      }
      return isLt5M && isJPG;
    },
    // 获取出纳粘贴图片
    handlePaste(event) {
      const attachment = this.attachment ? this.attachment.split(',') : [];
      // 上传文件个数已超过限制
      if (this.limit <= attachment.length && this.attachment) {
        return this.$message.error(this.$t('tips.limitTips'));
      }
      const items = (event.clipboardData || window.clipboardData).items;
      let file = null;
      if (!items || items.length === 0) {
        // 请使用添加附件，选择文件后上传！
        this.$message.error(this.$t('tips.pasteTips1'));
        return;
      }
      // 搜索剪切板items
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          file = items[i].getAsFile();
          break;
        }
      }
      if (!file) {
        // 粘贴内容非图片
        this.$message.error(`${this.$t('tips.pasteTypeTips')}！${this.$t('tips.pasteTips1')}`);
        return;
      }
      this.customHttpRequest(file, true);
    },
    // 自定义上传
    // isPaste是否为粘贴图片上传
     customHttpRequest(file, isPaste) {
      console.log(file, 'file');
      try {
        this.uploadTitle = this.$t('tips.uploadTitleLoading');
        this.title = this.$t('tips.uploadTitleLoading'); // '附件上传中'
        const formData = new FormData();
        formData.append('file', file);
        formData.append('subSystemCode', 'promanager');
        formData.append('fileName', file.name);
        this.localUpload(formData);
        } catch (e) {
          !isPaste && file.onError({});
      }
    },
    async localUpload(formData) {
      console.log(formData, 'formData');
      await this.$store.dispatch('publicApi/localUpload', formData).then(res => {
          if (res.status === 0) {
            const attachment = this.attachment ? `,${this.attachment}` : '';
            this.$emit('update:attachment', `${res.results}${attachment}`);
            this.$message.success(this.$t('tips.uploadSuccess'));
            this.uploadTitle = this.$t('tips.uploadTitle');
            this.title = this.$t('tips.attachmentUpload'); // '附件上传'
          }
        }).catch(e => {
          console.log(e, '');
        });
    },
    // 正在上传时的钩子
    handleProgress(event, file, fileList) {
      if (event.percent === 100) {
        const timeOut = setTimeout(() => {
          this.percentage = 100;
          clearTimeout(timeOut);
        }, 500);
      } else {
        this.percentage = event.percent === 0 ? 3 : event.percent;
      }
    },
    // 文件上传成功
    handleSuccess (response, file, fileList) {
      const timeOut = setTimeout(() => {
        fileList.map((item) => {
          if (item.response) {
            item.fileName = item.name;
            item.fileSize = item.size;
            item.id = item.response.results;
          }
        });
        const arr = fileList.map(v => v.id);
        this.$emit('update:attachment', arr.join(','));
        // console.log(fileList);
        this.$emit('fileList', fileList);
        this.$message.success(this.$t('tips.uploadSuccess'));
        this.uploadTitle = this.$t('tips.uploadTitle');
        this.title = this.$t('tips.attachmentUpload'); // '附件上传'
        clearTimeout(timeOut);
      }, 100);
    },
    // 文件上传失败
    handleError () {
      this.$message.error(this.$t('tips.uploadFail'));
      this.uploadTitle = this.$t('tips.uploadTitle');
      this.title = this.$t('tips.attachmentUpload'); // '附件上传'
    },
    formatFileSize (size) {
      const value = Number(size);
      if (size && !isNaN(value)) {
        const units = [
          'B',
          'KB',
          'MB',
          'GB',
          'TB',
          'PB',
          'EB',
          'ZB',
          'YB',
          'BB'
        ];
        let index = 0;
        let k = value;
        if (value >= 1024) {
          while (k > 1024) {
            k = k / 1024;
            index++;
          }
        }
        return `${k.toFixed(2)}${units[index + 1]}`;
      }
      return 0;
    },
    // 转换容量
    handconstransformation (capacityConut) {
      if (capacityConut < 1024) {
        return `${capacityConut}kb`;
      }
      capacityConut = capacityConut / 1024; // 转换为MB
      if (capacityConut < 1024) {
        return `${capacityConut.toFixed(2)}Mb`;
      }
      capacityConut = capacityConut / 1024; // 转换为G
      return `${capacityConut.toFixed(2)}G`;
    },
    // 文件预览
    handleViewer (item) {
      const fileSuffix = item.fileSuffix.toLowerCase();
      // 为图片预览
      if (/jpg|bmp|gif|ico|pcx|jpeg|tif|png|raw|tga/.test(fileSuffix)) {
        this.handleImageViewer(item);
      }
      if (/ppt|doc|xls|xlsx|txt|docx|pptx|pdf/.test(fileSuffix)) {
        this.handleFileInfo(item);
      }
    },
    handleImageViewer(item) {
      this.currentImg = this.imageUrl + item.filePath;
      this.visible = true;
    },
    // 本地上传文件预览隐藏
    getHandleViewer(item) {
      const fileSuffix = item.fileSuffix.toLowerCase();
      if (/ppt|doc|xls|xlsx|txt|docx|pptx|pdf/.test(fileSuffix)) {
        return true;
      }
      return false;
    },
    // 文件预览
    handleFileInfo (row) {
      window.open(`${this.$utils.config.fileViewUrl}${row.id}`);
    },

    // 下载示例模板
    downExampleFilePath(configParameter) {
      configParameter.fileName = `${this.$t(configParameter.fileName)}.${configParameter.fileSuffix}`;
      const link = document.createElement('a');
      link.style.display = 'none';
      link.href = configParameter.filePath;
      const fileName = configParameter.fileName;
      link.setAttribute('download', fileName);
      document.body.appendChild(link);
      link.click();
    },
    // 文件下载
    downFilePath(row) {
      const url = `${config.url}/file/api/local/download?fileId=${row.id}`;
      const link = document.createElement('a');
      link.style.display = 'none';
      link.href = url;
      link.target = '_Blank';
      const fileName = this.fileNameFilvalter(row);
      link.setAttribute('download', fileName);
      document.body.appendChild(link);
      link.click();
    },
    // 移除文件
    deconsteFile (index) {
      this.$confirm(
        `${this.$t('button.delete')} ${this.imgUrlList[index].fileName}?`,
        this.$t('button.delete'),
        {
          confirmButtonText: this.$t('button.determine'),
          cancelButtonText: this.$t('button.close'),
          type: 'warning'
        }
      )
        .then(() => {
          this.imgUrlList.splice(index, 1); // 假设长度为3
          if (this.imgUrlList.length) {
            const attachment = this.imgUrlList.map(v => v.id).join(',');
            this.$emit('update:attachment', attachment);
          } else {
            this.$emit('update:attachment', '');
          }
        })
        .catch(() => {
        });
    },
    // 判断是否为图片
    judgeFileImage (val) {
      val = val.toLowerCase();
      return /jpg|bmp|gif|ico|pcx|jpeg|tif|png|raw|tga/.test(val);
    },
    // 判断其他文件
    judgeFile(val) {
      val = val.toLowerCase();
      return /ppt|doc|xls|xlsx|txt|docx|pptx|pdf/.test(val);
    },
    // 判断是什么类型的文件
    setClass(val) {
      if (val) {
        const filePath = val.split('.');
        const ficonstype = filePath[filePath.length - 1];
        ficonstype.toLowerCase();
        if (ficonstype === 'txt') {
          return 'icon-txt';
        } else if (ficonstype === 'ppt' || ficonstype === 'pptx') {
          return 'icon-ppt';
        } else if (ficonstype === 'rar') {
          return 'icon-rar_1';
        } else if (ficonstype === 'pdf') {
          return 'icon-pdf';
        } else if (ficonstype === 'zip') {
          return 'icon-ZIP_1';
        } else if (ficonstype === 'doc' || ficonstype === 'docx') {
          return 'icon-word';
        } else if (ficonstype === 'xls' || ficonstype === 'xlsx') {
          return 'icon-excel1';
        } else {
          return 'icon-weizhi1';
        }
      }
    },
    // 自动识别
    handleIdentify() {
      if (this.imgUrlList.length === 0) {
        this.$message.error(this.$t('tips.uploadFile'));
        return;
      }
      const whetherPhoto = /jpg|bmp|gif|ico|pcx|jpeg|tif|png|raw|tga/.test(this.whetherPhoto);
      if (whetherPhoto) {
        const identifyUrl = `${config.imageUrl}${this.imgUrlList[0].filePath}`;
        this.$emit('identify', identifyUrl);
        this.$emit('moreIdentifyList', this.imgUrlList); // 多个发票
      } else {
        this.$message.error(this.$t('tips.whetherPhotoTips'));
      }
    }
  }
};
</script>

<style scoped lang="scss">
.paste{
  display: inline-block;
  max-width: 300px;
  padding: 10px 20px;
  margin: 5px 0 10px 0;
  border: 1px solid #eeeeee;
  border-style:dashed;
  text-align: center;
  color: gray;
  cursor: pointer;
}
.icon-txt {
  color: #1f7246;
}
.icon-ppt {
  color: #d81e06;
}
.icon-rar_1 {
  color: #8475ff;
}
.icon-pdf {
  color: #e70400;
}
.icon-ZIP_1 {
  color: #733781;
}
.icon-word {
  color: #0095e0;
}
.icon-excel1 {
  color: #1f7246;
}
.icon-weizhi1{
  color: gray;
}
ul {
  li {
    list-style: none;
  }
}
.file-upload {
  width: 100%;
  .top {
    position: relative;
    .progress {
      position: absolute;
      width: 200px;
      bottom: -16px;
      left: 0px;
    }
  }
  .bottom {
    width: 100%;
    overflow: hidden;
    ul {
      width: 100%;
      overflow: hidden;
      display: flex;
      flex-wrap: wrap;
      li {
        height: 50px;
        // flex: 1;
        margin-right: 5px;
        margin-bottom: 15px;
        position: relative;
        &:nth-child(4) {
          margin-right: 0;
        }
        .left {
          width: 50px;
          height: 50px;
          float: left;
          display: flex;
          align-items: center;
          line-height: 50px;
          margin-right: 5px;
          img {
            display: inline-block;
            vertical-align: mathematical;
            max-width: 50px;
            max-height: 50px;
          }
        }
        .right {
          width: calc(100% - 65px);
          height: 50px;
          float: left;
          cursor: pointer;
          position: relative;
          background: rgb(245, 245, 245);
          .cons {
            width: 100%;
            height: 100%;
            padding: 5px;
            box-sizing: border-box;
            p {
              line-height: 24px;
              width: 100%;
              overflow: hidden;
              height: 20px;
              font-size: 12px;
              white-space: nowrap;
              text-overflow: ellipsis;
            }
          }
          .set {
            width: 100%;
            height: 100%;
            position: absolute;
            display: none;
            top: 0;
            left: 0;
            z-index: 99;
            background: rgba(0, 0, 0, 0.6);
            line-height: 50px;
            padding-right: 5px;
            text-align: right;
            span {
              margin: 0 8px;
              font-size: 18px;
              color: white;
              font-weight: bold;
            }
          }
          &:hover {
            .set {
              display: block;
            }
          }
        }
      }
    }
  }
}
</style>
