/*
 * @Author: your name
 * @Date: 2021-08-04 14:42:27
 * @LastEditTime: 2022-09-30 10:36:00
 * @LastEditors: zengqin 1058574586@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_projectmaterial\src\mixins\processMixins.js
 */
export const process = {
    data() {
        return {
            isProcessOver: true, // 判断当前分支节点是否已经执行完成(不包含当前节点) true表示已经执行完成，false表示没执行完成
            stepTaskApproveNodeDtos: [],
            dataInfo: {}
        };
    },
    methods: {
        // 提交
        nextStep () {
            // 将当前行存储于缓存中
            localStorage.setItem('dataInfo', JSON.stringify(this.pageConfigEdit.projectForm));
            this.checkRequired(() => {
              this.processType = 'next';
              this.$refs.processEdit.handleSave(true);
            });
        },
        // 快速同意
        quickConsent() {
            // 将当前行存储于缓存中
            localStorage.setItem('dataInfo', JSON.stringify(this.pageConfigEdit.projectForm));
            this.checkRequired(() => {
                this.processType = 'quickConsent';
                this.$refs.processEdit.handleSave(true);
            });
        },
        // 在流程审批时，对非必填字段根据字段状态进行约束
        checkRequired(callback) {
          if (this.nodeCode !== 'BEGIN') {
            const list = [];
            const subTableCustomRules = this.$refs.processEdit.subTableCustomRules || {};
            const pageConfigEdit = this.$refs.processEdit.page.PageConfig;
            const subTableMatch = pageConfigEdit.subTableMatch;
            if (subTableMatch && subTableMatch.length) {
                for (const subTable of subTableMatch) {
                    const subTableConfig = pageConfigEdit.subTableConfig[subTable.assignment];
                    const tableList = subTableConfig.tableList.slaveColumns;
                    const tableData = subTableConfig.tableData;
                    const rules = subTableConfig.tableList.rules;
                    const rule = {...rules, ...subTableCustomRules};
                    if (tableData && !tableData.length) {
                        for (const item of tableList) {
                            if (rule[item.prop] && item.inputStatus !== 'hide' && item.inputStatus !== 'disable') {
                                list.push(item);
                            }
                        }
                    }
                }
            }
            if (list && list.length) {
              const dataNull = list.map(v => this.$t(v.label)).join('，');
              this.$message.error(`${this.$t('tips.pleaseFillIn')}：${dataNull}！`);
            } else {
                callback && callback();
            }
          } else {
            callback && callback();
          }
        },
        // 提交流程
        processSubmit () {
            // 提交
            this.processType === 'next' && this._getProcessNodeInfo();
            // 快速提交
            this.processType === 'quickConsent' && this.handleQuickConsent();
        },
        // 快速同意
        handleQuickConsent() {
            this.getNextProcessInfo();
        },
        // 判断当前节点是否为分支节点
        async checkProcessOver(callback) {
            const overData = {
                processNodeCode: this.nextProcessForm.stepNextNodesDto.currentProcessNodeCode,
                taskId: this.nextProcessForm.taskId
            };
            const overRes = await this.$store.dispatch('publicApi/judgeProcessOver', overData);
            // true表示已经执行完成，false表示没执行完成
            this.isProcessOver = overRes.results;
            callback && callback();
        },
        // 获取下一步流程节点信息
        getNextProcessInfo() {
            const nextInfo = this.pageConfigEdit.processParmas.nextInfo;
            const nextParmas = {};
            if (nextInfo.parmasList && nextInfo.parmasList.length) {
                for (const item of nextInfo.parmasList) {
                    nextParmas[item.receive] = this.processTaskInfo[item.value] || this.pageConfigEdit.projectForm[item.value] || '';
                }
            } else {
                nextParmas[nextInfo.parmas] = this.processTaskInfo.sid;
            }
            const processParmas = {
                processNodeCode: this.processTaskInfo.processNodeCode,
                taskId: this.processTaskInfo.taskId
            };
            const data = Object.assign(nextParmas, processParmas);
            data.formCode = this.pageConfigEdit.formCode;
            this.$store.dispatch(nextInfo.url, data).then(res => {
                this.nextProcessForm = res.results;
                this.checkProcessOver(() => {
                    this.nextProcess();
                });
            });
        },
        nextProcess() {
            const dataInfo = localStorage.getItem('dataInfo');
            this.dataInfo = dataInfo ? JSON.parse(dataInfo) : {};
            if (this.nextProcessForm.stepNextNodesDto === null) {
                this.processName = 'noProcess';
                this.dialogProcess = true;
            } else {
                const nextNodes = this.nextProcessForm.stepNextNodesDto.nextNodes;
                let isSendSms = 0;
                let isSendEmail = 0;
                let isSendVoice = 0;
                if (nextNodes.some(v => v.isSendSms === 1)) {
                    isSendSms = 1;
                }
                if (nextNodes.some(v => v.isSendEmail === 1)) {
                    isSendEmail = 1;
                }
                if (nextNodes.some(v => v.isSendVoice === 1)) {
                    isSendVoice = 1;
                }
                const data = {
                    comment: this.$t('dialog.agree'),
                    createBy: this.$utils.Auth.hasUserInfo().userId,
                    createByEmail: this.$utils.Auth.hasUserInfo().email,
                    createByMobile: this.$utils.Auth.hasUserInfo().mobile,
                    createByName: this.$utils.Auth.hasUserInfo().userName,
                    currentProcessNodeCode: this.nextProcessForm.stepNextNodesDto.currentProcessNodeCode,
                    formCode: this.nextProcessForm.formCode,
                    isSendEmail,
                    isSendSms,
                    isSendVoice,
                    processCode: this.nextProcessForm.stepNextNodesDto.processCode,
                    sid: this.nextProcessForm.sid,
                    signature: this.$utils.Auth.hasUserInfo().signPic,
                    stepTaskApproveNodeDtos: this.stepTaskApproveNodeDtos,
                    taskId: this.nextProcessForm.taskId,
                    taskName: this.nextProcessForm.taskName,
                    tenantId: this.dataInfo.tenantId
                };
                if (nextNodes.some(v => v.nodeCode === 'END')) {
                    // 提交后本条数据将更新为已审批状态。 已审批状态的数据不能撤回，不能修改，不能删除。
                    const mseeage = `${this.$t('dialog.nextTips1')}<br><span style="color:red;">${this.$t('dialog.nextTips2')}</span>`;
                    //  提交流程
                    this.$confirm(mseeage, this.$t('button.startProcess'), {
                        cancelButtonClass: 'button-close',
                        dangerouslyUseHTMLString: true,
                        confirmButtonText: this.$t('button.determine'),
                        cancelButtonText: this.$t('button.close'),
                        type: 'warning'
                    }).then(() => {
                        this.submitNextProcess({ url: this.pageConfigEdit.processParmas.approveSubmit.url, data });
                    }).catch(e => {
                    });
                } else {
                    const currentNodeCode = this.nextProcessForm.stepNextNodesDto.currentNodeCode;
                    if (currentNodeCode === 'APPROVAL' || currentNodeCode === 'BEGIN') {
                        this.submitNextProcess({ url: this.pageConfigEdit.processParmas.approveSubmit.url, data });
                    } else {
                        // 下一节点为分支任务，需要您通过提交按钮手动提交，谢谢！
                        this.$message.error(this.$t('tips.processBranchTips'));
                    }
                }
            }
        }
    }
};
