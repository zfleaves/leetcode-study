import {closeRoute} from 'mixins/index';
import Auth from 'util/auth';

export const importPage = {
    mixins: [closeRoute],
    data () {
        return {
            // 导入明细
            dialogImportFlag: false,
            subImportTable: '',
            dialogImportConfig: {
                title: this.$t('dialog.importDetail'),
                appendBody: false,
                center: true,
                top: '50px',
                width: '80%',
                span: '0.75'
            },
            deleteImportList: [],
            that: '',
            importLoading: null
        };
    },
    created () {
        this.that = this;
    },
    methods: {
        // -------------------------------------------- 导入子表 ----------------------------------------
        // 子表事件按钮事件传出
        dialogEvent(eventName) {
            if (eventName === 'close') {
                this.dialogImportFlag = false;
            }
            if (eventName === 'save') {
                this.sysHandleImportSave(this.subImportTable.subTableName); // 批量删除
            }
            if (eventName === 'delete') {
                this.sysHandleImportDeleta(this.subImportTable.subTableName); // 批量删除
            }
        },
        // 批量删除
        sysHandleImportDeleta(tableName) {
          this.handleDeleteImportSubTable(this.deleteImportList, this.$t(`${this.translateName}.${tableName}`), tableName);
        },
        batchDeleteDetail(tableData, v) {
          const index = tableData.indexOf(v);
          if (index > -1) {
            tableData.splice(index, 1);
          }
          tableData.forEach(item => {
            if (item.children && item.children.length > 0) {
              this.batchDeleteDetail(item.children, v);
            }
          });
        },
        // 批量删除操作
        handleDeleteImportSubTable(arr, keyValue, tableName) {
            if (arr && arr.length > 0) {
              const deletMessage = this.$t('tips.deleteDetailedTips').replace('{keyValue}', keyValue);
              const deleteDetailsMessage = this.$t('tips.deleteDetailsApiTips').replace('{keyValue}', keyValue);
              const messageTips = deletMessage;
              this.$confirm(messageTips, `${this.$t('button.batchDeletion')}${keyValue}`, {
                cancelButtonClass: 'button-close',
                dangerouslyUseHTMLString: true,
                confirmButtonText: this.$t('button.determine'),
                cancelButtonText: this.$t('button.close'),
                type: 'warning'
              }).then(() => {
                console.log(arr, 'arr');
                 arr.forEach(v => {
                   this.batchDeleteDetail(this.subImportTable.tableData, v);
                    // this.subImportTable.tableData.splice(this.subImportTable.tableData.indexOf(v), 1);
                 });
              }).catch(e => {});
            } else {
              // 请选择明细清单
              this.$message.error(this.$t('tips.pleaseSelectDetailed'));
            }
        },
        // 子表操作事件
        editImportTableEvent({eventName, params}) {
            if (eventName === 'tableSelect') { // 下拉选择
                this.handleImportTableSelect(params);
            }
            if (eventName === 'operateDataEvent') { // 数值计算
                this.handleImportCalculation(params);
            }
            if (eventName === 'handleTable') { // 表格文本操作事件
                params.item && params.item.fn && params.item.fn(params);
            }
        },
        // 子表下拉选择赋值
        handleImportTableSelect({item, row, event, subTable, rowIndex}) {
            item.relationList.forEach(res => {
                let index = 0;
                if (item.formType === 'select') {
                    index = item.selectList.findIndex(v => v[item.valueCode] === event);
                } else {
                    index = item.selectList.findIndex(v => v.dataCode === event);
                }
                this.$set(this.subImportTable.tableData[rowIndex], res.receive, item.selectList[index][res.value]);
            });
        },
        // 数值计算
        handleImportCalculation(params) {
            console.log(params);
        },
        // 获取导入模板数据
        getImportData (val) {
          if (!val.tableData || !val.tableData.length) {
            this.$message.info(this.$t('tips.unllImport'));
            return;
          }
          this.subImportTable = val;
          this.dialogImportFlag = true;
        },
        // 保存导入明细数据
        sysHandleImportSave(tableName) {
            const importDetails = this.$refs.importTable.validateTableData();
            if (!importDetails) {
                // 请检查必填项是否填写，特别注意边框变为红色的数据
                this.$message.error(this.$t('tips.importSaveTips'));
            } else {
                this.setImportDetails(importDetails, tableName);
            }
        },
        // 设置导入数据
        setImportDetails(importDetails, tableName) {
          const fieldLengthAll = this.setFieldLength(importDetails);
          if (fieldLengthAll.list.length) {
            const tipsList = [];
            for (const item of fieldLengthAll.list) {
              tipsList.push(`<span style="color:red">${this.$t('tips.theFirst')}${item.index}${this.$t('tips.row')}：${item.label};</span><br>`);
            }
            // 字段长度超过限制数，点击确认系统会动截取，是否继续？
            this.$confirm(`${tipsList.join('')}${this.$t('tips.fieldLengthTips1')}`,
            `${this.$t(`menu.${this.$route.params.translateName}`)}${this.$t('tips.fieldLengthTips2')}`, {
                cancelButtonClass: 'button-close',
                dangerouslyUseHTMLString: true,
                confirmButtonText: this.$t('tips.interceptBut1'),
                cancelButtonText: this.$t('button.close'),
                type: 'warning'
            }).then(() => {
              this.saveImportData(fieldLengthAll.details, tableName);
            }).catch(() => {
            });
          } else {
            this.saveImportData(importDetails, tableName);
          }
        },
        saveImportData(importDetails, tableName) {
          this.importLoading = this.$loading({
            lock: true,
            text: this.$t('tips.saveTips'),
            background: 'rgba(255, 255, 255, 0.5)'
          });
          const tableData = this.pageConfig.subTableConfig[tableName].tableData;
          this.$set(this.pageConfig.subTableConfig[tableName], 'tableData', tableData.concat(importDetails));
          this.dialogImportFlag = false;
          // 子表长度变化后的数值计算回调
          this.deletTableCallback && this.deletTableCallback(tableName);
          this.$nextTick(() => {
            this.importLoading.close();
          });
        },
        // 导入时判断字段长度是否超出
        setFieldLength(importDetails) {
          const list = [];
          const details = this.$clone(importDetails);
          let listIndex = -1;
          for (const i in details) {
            const item = details[i];
            for (const prop in item) {
              const tableList = this.subImportTable.tableList.slaveColumns;
              const index = tableList.findIndex(v => v.prop === prop);
              if (index >= 0 && tableList[index].formType !== 'text') {
                if ((item[prop] && item[prop].length && tableList[index].maxlength) && (item[prop].length > tableList[index].maxlength)) {
                  if (typeof item[prop] !== 'number') {
                    item[prop] = item[prop].substr(0, tableList[index].maxlength);
                  }
                  if (list[listIndex] && (list[listIndex] && list[listIndex].index === Number(i) + 1)) {
                    list[listIndex].label = `${list[listIndex].label},${this.$t(tableList[index].label)}`;
                  } else {
                    listIndex = listIndex + 1;
                    list[listIndex] = {index: Number(i) + 1, label: this.$t(tableList[index].label)};
                  }
                }
              }
            }
          }
          return {
            list,
            details
          };
        }
    }
};
