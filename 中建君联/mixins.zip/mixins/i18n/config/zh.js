/*
 * @Author: zengqin 1058574586@qq.com
 * @Date: 2022-07-29 15:54:46
 * @LastEditors: zengqin 1058574586@qq.com
 * @LastEditTime: 2022-12-09 15:39:20
 * @FilePath: \web_projectmaterial\src\mixins\i18n\config\zh.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
/*
 * @Author: your name
 * @Date: 2020-06-28 09:08:48
 * @LastEditTime: 2020-06-28 17:05:47
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web_basicconfiguration-企业信息及配置\src\i18n\config\zh.js
 */
import zhLocale from 'element-ui/lib/locale/lang/zh-CN';

const zh = {
  menu: {
    home: '首页'
  },
  errorCode: {
    20001001: '账号或密码错误',
    40001005: '密码验证失败'
  },
  globalData: {
    browserTitle: '',
    currentLanguage: '中文',
    noData: '暂无数据',
    serialNumber: '序号',
    putItAway: '收起',
    open: '展开',
    tips: '提示',
    signOut: '退出',
    exitTheSystem: '退出系统'
  },
  login: {
    title: '欢迎使用施企云',
    logIn: '登录',
    username: '手机号/账号/邮箱',
    usernameErrorTips: '手机号/账号/邮箱不能为空',
    password: '密码',
    passwordErrorTips: '密码不能为空',
    rememberPassword: '记住密码',
    forgetPassword: '忘记密码',
    footer: '版权所有：君联有限公司 | 建议使用火狐，谷歌浏览器'
  },
  ...zhLocale
};
export default zh;
