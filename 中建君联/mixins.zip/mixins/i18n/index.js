/*
 * @Author: zengqin 1058574586@qq.com
 * @Date: 2023-01-09 10:34:37
 * @LastEditors: zengqin 1058574586@qq.com
 * @LastEditTime: 2023-01-13 12:40:01
 * @FilePath: \web_projecttmaterials\src\mixins\i18n\index.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import Vue from 'vue';
import VueI18n from 'vue-i18n';
import locale from 'element-ui/lib/locale';
import Auth from 'util/auth';
// 引入各个语言基础包配置文件
import zh from './config/zh'; // 中文
import en from './config/en'; // 英文

Vue.use(VueI18n);

const i18n = new VueI18n({
  locale: Auth.hasLanguage(), // 从缓存中获取当前语言类型
  messages: {
    zh,
    en
  },
  // 隐藏警告
  silentTranslationWarn: true
});
locale.i18n((key, value) => i18n.t(key, value)); // 为了实现element插件的多语言切换

export default i18n;
