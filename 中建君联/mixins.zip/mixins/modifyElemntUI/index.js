/*
 * @Author: your name
 * @Date: 2021-09-13 11:42:05
 * @LastEditTime: 2021-09-13 11:42:06
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \src\mixins\modifyElemntUI\index.js
 */
import elemntUI from 'element-ui';
// 想要修改其他默认值,同理修改对应的默认值即可
console.log(elemntUI.Dialog.props, 'elemntUI.Dialog.props');
elemntUI.Dialog.props.closeOnClickModal.default = false;
