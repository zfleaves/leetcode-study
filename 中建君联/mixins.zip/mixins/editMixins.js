/*
 * @Author: your name
 * @Date: 2020-07-13 09:00:27
 * @LastEditTime: 2023-08-10 14:22:16
 * @LastEditors: zengqin 1058574586@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_unit\src\mixins\editMixins.js
 */
import { closeRoute } from 'mixins/index';
import Utils from 'util';

export const editPage = {
  mixins: [closeRoute],
  data() {
    return {
      pageConfig: {},
      type: 'add',
      id: 0,
      dialogVisible: false,
      deleteList: {},
      pageDisabled: false,
      loading: false,
      pageConfigLoading: true,
      isProcess: false,
      translateName: '',
      pageData: '',
      subTableData: [],
      oldProjectForm: {},
      isRefreshFlag: false,
      isSumbitSave: false, // 是否是提交流程,
      editPage: null, // editPage
      wbsFlag: false,
      subTableWbsRow: {},
      wbsDialogConfig: {
        title: `${this.$t('tips.pleaseSelect')}${this.$t('fConfig.progressProcess')}`,
        appendBody: false,
        center: true,
        top: '80px',
        width: '60%',
        span: '0.7'
      },
      isPayDataIncomplete: false, // 是否存在未完成的付款单
      printConfig: {}
    };
  },
  created() {
    if (this.$route.name === 'processApprovalPage' || this.$route.name === 'sceneProcessApprovalPage') {
      this.type = this.$base64.decode(this.$route.params.type);
      this.translateName = this.$route.params.translateName;
      this.isProcess = true;
    } else {
      if (!this.$route.params.type) return;
      this.type = this.$base64.decode(this.$route.params.type);
      this.id = Number(this.$base64.decode(this.$route.params.id));
      this.translateName = this.$route.params.translateName;
      if (this.page) {
        if (this.type !== 'add' && this.id) {
          this.pageConfig.projectForm = this.projectForm; // 挂载form 对象
          this._getInfoData(this.id);
        } else {
          this.pageConfig = this.page.PageConfig;
          this.pageConfig.projectForm = this.projectForm; // 挂载form 对象
          this.oldProjectForm = this.$clone(this.projectForm);
          if (this.pageConfig.subTableMatch) {
            for (const item of this.pageConfig.subTableMatch) {
              const slaveColumns = this.pageConfig.subTableConfig[item.assignment].tableList.slaveColumns;
              const tableList = slaveColumns;
              this.$set(this.pageConfig.subTableConfig[item.assignment].tableList, 'slaveColumns', tableList);
              this.$set(this.pageConfig.subTableConfig[item.assignment], 'tableData', this.$clone(this.subTableData));
            }
          }
          this.pageConfigLoading = true;
          // 项目自动赋值
          this.setPorjcetData && this.setPorjcetData();
          // 所属组织自动赋值
          this.setOrgData && this.setOrgData();
        }
      }
    }
    this.pageStatus();
  },
  activated() {
    if (this.page) {
      this.page.init();
      this.pageConfig = this.page.PageConfig;
    }
  },
  methods: {
    // 校验
    repeatCheckData(rule, value, callback, params) {
      if (!value) {
        // 请输入
        callback(new Error(`${this.$t('tips.pleaseEnter')}${this.$t(params.codeName)}`));
      } else {
        this.$store.dispatch(params.url, { [params.keyName]: value, [params.keyId]: this.id || '' }).then(res => {
          if (res.results) {
            // 重复，请重新输入
            callback(new Error(`${this.$t(params.codeName)}${this.$t('tips.repeat')}`));
          } else {
            callback();
          }
        });
      }
    },
    // 获取数据
    handleGetInfoData(id = 0, infoUrl, callback) {
      if (Number(id) === 0) {
        this.pageConfig.projectForm = this.projectForm; // 挂载form 对象
        this.pageConfigLoading = true;
        return;
      }
      this.id = id;
      this.loading = true;
      if (!infoUrl) return;
      this.$store.dispatch(infoUrl.url, { [infoUrl.params]: this.id }).then(res => {
        const results = this.$clone(res.results);
        if (!results) {
          this.pageConfig = this.page.PageConfig;
          this.pageConfig.projectForm = this.projectForm; // 挂载form 对象
          this.pageConfigLoading = true;
          this.loading = false;
          return;
        }
        if (results.continent) {
          results.areas = [];
          const keysList = ['continent', 'country', 'province', 'city', 'area'];
          for (const key of keysList) {
            if (results[key] && results[key].indexOf('-')) {
              const id = results[key].split('-')[1];
              results.areas.push(Number(id));
            }
          }
        }
        this.pageConfig = this.page.PageConfig;
        this.$set(this.pageConfig, 'projectForm', results);
        this.oldProjectForm = this.$clone(results);
        if (this.pageConfig.subTableMatch) {
          for (const item of this.pageConfig.subTableMatch) {
            const slaveColumns = this.pageConfig.subTableConfig[item.assignment].tableList.slaveColumns;
            const tableList = slaveColumns;
            this.$set(this.pageConfig.subTableConfig[item.assignment].tableList, 'slaveColumns', tableList);
            this.$set(this.pageConfig.subTableConfig[item.assignment], 'tableData', results[item.value]);
            if (this.pageConfig.subTableConfig[item.assignment].isSetTableStatus) {
              // this.setSysHandleExportDetailStatus(item.assignment);
            }
          }
        }
        callback && callback();
        this.pageConfigLoading = true;
        this.loading = false;
      });
    },
    // 更新个人任务状态
    driveJobUpdateStatus(postBusinessKey) {
      const jobInfo = localStorage.getItem('jobInfo') ? JSON.parse(localStorage.getItem('jobInfo')) : '';
      // 判断缓存中是否存在此任务信息
      // 当前页面路由是否为任务信息中的路由
      // 只在添加时调用
      if (jobInfo && jobInfo.engineDriverJobAssigneeId && this.translateName === jobInfo.postMenuPath && this.type === 'add') {
        const data = {
          handerStatus: '02',
          engineDriverJobAssigneeId: jobInfo.engineDriverJobAssigneeId,
          postBusinessKey
        };
        this.$store.dispatch('driveJob/updateStatus', data).then(res => {
          // 销毁缓存中的任务数据
          localStorage.removeItem('jobInfo');
        });
      } else {
        // 销毁缓存中的任务数据
        localStorage.removeItem('jobInfo');
      }
    },
    // 设置导入明细按钮状态
    setSysHandleExportDetailStatus(tableName) {
      if (this.type !== 'info') return;
      const subTableButton = this.pageConfig.subTableConfig[tableName].subTableButton;
      const index = subTableButton.findIndex(v => v.code === 'sysHandleExportDetail');
      if (index >= 0) {
        this.$set(this.pageConfig.subTableConfig[tableName].subTableButton[index], 'disabled', false);
      }
      this.$forceUpdate();
    },
    // 保存数据
    handleSaveData(data, isProcess = false, callback) {
      // 数据截取
      const formList = this.pageConfig.mainFormConfig.formList;
      for (const item of formList) {
        const formTypeList = ['input', 'textarea', 'slot']; // 需求截取的数字类型
        if ((formTypeList.includes(item.formType)) && (!item.inputStatus || item.inputStatus === 'edit') &&
          item.maxlength && data[item.prop] && typeof data[item.prop] === 'string') {
          data[item.prop] = data[item.prop].substr(0, item.maxlength);
        }
      }
      if (this.pageConfig.subTableMatch && this.pageConfig.subTableMatch.length) {
        for (const subTable of this.pageConfig.subTableMatch) {
          const details = data[subTable.value];
          if (details && details.length > 0) {
            // 数据截取
            const tableList = this.$clone(this.pageConfig.subTableConfig[subTable.assignment].tableList.slaveColumns);
            for (const item of tableList) {
              if ((item.formType === 'input' || item.formType === 'textarea') && (!item.inputStatus || item.inputStatus === 'edit') && item.maxlength) {
                for (const row of details) {
                  if (row[item.prop] && typeof row[item.prop] === 'string') {
                    row[item.prop] = row[item.prop].substr(0, item.maxlength);
                  }
                }
              }
            }
          }
        }
      }
      if (!isProcess) {
        this.saveData(data, isProcess, callback);
        return;
      }
      this.pageData = this.$clone(data);
      this.handleProcess();
    },
    // 保存数据
    saveData(data, isProcess, callback) {
      const loadingSubmit = this.$loading({
        lock: true,
        background: 'rgba(0,0,0,0.7)',
        spinner: 'el-icon-loading'
      });
      const saveUrl = this.page.PageConfig.processParmas.saveUrl;
      this.$store.dispatch(saveUrl.url, data).then(res => {
        const status = this.type === 'add' ? this.$t('button.add') : this.$t('button.edit');
        if (res.status === 0) {
          if (!isProcess) {
            if (this.isSumbitSave) { // 是否是保存流程后提交
              // console.log(res.results, 'res.results');
              this.handleStartProcess(data, res.results, loadingSubmit); // 传入ID
              this.$message.success(`${status}${this.$t('tips.success')}!`);
            } else {
              // 特殊提示
              if (data.specialTips) {
                this.$message.success(`${data.specialTips}${this.$t('tips.success')}!`);
              } else {
                this.$message.success(`${status}${this.$t('tips.success')}!`);
              }
              loadingSubmit.close();
              this.setRoute();
              return;
            }
          }
          loadingSubmit.close();
          callback && callback();
        } else {
          this.handleMessageTips(res, `${status}${this.$t('tips.fail')}!${this.$t(`exception.${res.errorCode}`)}`);
          loadingSubmit.close();
        }
      }).catch(e => {
        loadingSubmit.close();
      });
    },
    handleMessageTips(res, otherTips) {
      if (res.errorCode === 10000001) {
        const errorMessage = JSON.parse(res.errorMessage);
        if (errorMessage && errorMessage instanceof Array && errorMessage.length) {
          // 主表判断值是否填写
          if (errorMessage[0].formType === 'mainTable') {
            this.$message.error(errorMessage.map(v => {
              const messages = [];
              for (const i in v.message) {
                messages.push(v.message[i]);
              }
              return messages.join(';');
            }).join(';'));
          }
          // 子表判断值是否填写
          if (errorMessage[0].formType === 'subTable') {
            errorMessage.map(mes => {
              const info = this.pageConfig.subTableMatch.find(v => v.value === mes.tableName);
              if (info) {
                const messages = [];
                for (const i in mes.message) {
                  messages.push(mes.message[i]);
                }
                // eslint-disable-next-line max-len
                this.$message.error(`【${this.$t(`${this.translateName || this.$route.name}.${info.assignment}`)}】${this.$t('tips.theFirst')}${Number(mes.rowNum) + 1}${this.$t('tips.row')}：${messages.join(';')}`);
              }
            });
          }
        } else {
          this.$message.error(res.errorMessage);
        }
      } else {
        this.$message.error(otherTips);
      }
    },
    // 保存后 的 提交流程
    handleStartProcess(data, id, loadingSubmit) {
      // console.log(this.pageConfig.processParmas, 'id');
      const infoUrl = this.pageConfig.processParmas.infoUrl;
      this.$store.dispatch(infoUrl.url, { [infoUrl.params]: id }).then(res => {
        const results = this.$clone(res.results);
        const translateName = this.$route.params.translateName;
        const currentMenu = this.$utils.menu.getCurrentMenu(translateName);
        const component = currentMenu.component;
        const componentUrlList = component.split('/');
        componentUrlList[componentUrlList.length - 1] = 'config';
        const SearchPage = require(`views/${componentUrlList.join('/')}.js`).default;
        const searchPage = new SearchPage();
        this.editPage.handleStartProcess && this.editPage.handleStartProcess({ data: results, id, processParmas: searchPage.PageConfig.processParmas });
        loadingSubmit && loadingSubmit.close();
      }).catch(e => {
        this.$message.warning(`${this.$t('button.startProcess')}${this.$t('tips.fail')}`);
        this.setRoute();
      });
    },
    handleProcess() {
      this.$emit('processSubmit', true);
    },
    // 页面状态
    pageStatus() {
      this.pageDisabled = this.type !== 'info';
      if (this.type === 'info') {
        // console.log(this.page.PageConfig.subTableConfig, 'this.page.PageConfig.subTableConfig');
        for (const i in this.page.PageConfig.subTableConfig) {
          const item = this.page.PageConfig.subTableConfig[i];
          item.isSelection = false;
          for (const child of item.tableList.slaveColumns) {
            this.$set(child, 'inputStatus', 'disable');
          }
          for (const but of item.subTableButton) {
            but.disabled === undefined ? (but.disabled = false) : (but.disabled = true);
          }
        }
      }
    },
    editEvent({ eventName, editPage }) {
      if (eventName === 'close') {
        this.isSumbitSave = false;
        this.setRoute();
      }
      if (eventName === 'save') {
        this.isSumbitSave = false;
        this.handleSave();
      }
      if (eventName === 'startProcess') {
        this.isSumbitSave = true;
        this.editPage = editPage;
        this.handleSave(); // 先保存数据
      }
      if (eventName === 'startProcessSaveSuccess') {
        this.isSumbitSave = false;
        this.setRoute();
      }
      if (eventName === 'startProcessSaveFail') {
        this.isSumbitSave = false;
        this.setRoute();
      }
      // 初始化表单
      if (eventName === 'initForm') {
        this.isSumbitSave = false;
        if (!this.page.PageConfig.formCode) {
          this.$message.error('configEdit.js未配置formCode，不能初始化');
          return;
        }
        this.$confirm('<span style="color:red">该操作建议由技术人员进行操作，避免出现不可逆转的功能性问题。</span><br>你确定继续进行该操作吗？',
          `${this.$t(`menu.${this.$route.params.translateName}`)}${this.$t('button.initForm')}`, {
          cancelButtonClass: 'button-close',
          dangerouslyUseHTMLString: true,
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.checkFormcodeExistPublicApi(() => {
            this.sysInitForm();
          });
        }).catch(() => {
        });
      }
      if (eventName === 'monitorProcess') {
        const projectForm = this.$clone(this.page.PageConfig.projectForm);
        // 判断是否否已提交
        if (projectForm.flowStatus === '0') {
          // 该流程未提交
          this.$message.warning(this.$t('tips.monitorProcessTips2'));
          return;
        }
        if (!projectForm.taskId) {
          // 该数据没有流程
          this.$message.warning(this.$t('tips.monitorProcessTips3'));
          return;
        }
        // 将当前行存储于缓存中 是否为场景流程
        localStorage.setItem('processType', this.page.PageConfig.processType);
        this.$store.commit('diaLog/set_process_dialog', projectForm.taskId);
      }
      if (eventName === 'sysHandlePrint') {
        this.sysHandlePrint();
      }
      if (eventName === 'languageInit') {
        this.handleAddLanguageInit();
      }
      if (eventName === 'logPage') {
        this.handleLogPage();
      }
    },
    // 流程中打印
    async sysHandlePrint() {
      const row = this.$clone(this.page.PageConfig.projectForm);
      let belongCompanyId = row.belongCompanyId || '';
      if (!row.belongCompanyId) {
        const params = {
          id: row.projectId
        };
        await this.$store.dispatch('proProject/getProjectInfo', params).then(res => {
          if (res.status === 0) {
            belongCompanyId = res.results ? res.results.parentSubOrgId : '';
          }
        });
      }
      const taskDetailId = Number(this.$base64.decode(this.$route.params.taskDetailId));
      const loadRouteName = this.$route.params.translateName;
      const res = await this.$store.dispatch('processApi/workflowTaskDetailInfo', { taskDetailId }).then();
      const results = res.results;
      const printModelCode = this.$base64.encode(results.formCode);
      const taskId = this.$base64.encode(results.taskId); // 打印
      const id = this.$base64.encode(results.taskSid);
      const flowStatus = this.$base64.encode(row.flowStatus);
      const RouteTitleObj = { name: 'printDesign', loadRouteName, translateType: 'print' };
      localStorage.setItem('RouteTitle', JSON.stringify(RouteTitleObj));
      let printModelId = 0;
      await this.$store.dispatch('publicApi/getPrintModelPrintcodeList', { belongCompanyIds: [belongCompanyId], printModelCode: results.formCode }).then(res => {
        if (res.status === 0 && res.results && res.results.length) {
          if (res.results.length === 1) {
            printModelId = this.$base64.encode(res.results[0].id);
            this.jumpPrintDesign(printModelCode, taskId, id, loadRouteName, printModelId, flowStatus);
          } else {
            this.printTemplateList = res.results;
            this.printConfig = {
              printModelCode, taskId, id, loadRouteName, printModelId, flowStatus
            };
            console.log(this.printTemplateList, 'this.printTemplateList');
            this.$store.commit('tagNav/set_print_dialogShow', this.printTemplateList);
          }
        } else {
          this.$confirm(this.$t('tips.selectPrintDataTips'), this.$t('tips.tips'), {
            cancelButtonClass: 'button-close',
            confirmButtonText: this.$t('button.determine'),
            cancelButtonText: this.$t('button.close'),
            dangerouslyUseHTMLString: true,
            type: 'warning'
          }).then(() => {
            printModelId = this.$base64.encode(0);
            this.jumpPrintDesign(printModelCode, taskId, id, loadRouteName, printModelId, flowStatus);
          }).catch();
        }
      });
    },
    jumpPrintDesign(printModelCode, taskId, id, loadRouteName, printModelId, flowStatus) {
      this.$router.push(`/printDesign/${printModelCode}/${taskId}/${id}/${loadRouteName}?printModelId=${printModelId}&flowStatus=${flowStatus}`);
    },
    // 校验formCode是否存在
    checkFormcodeExistPublicApi(callback) {
      this.$store.dispatch('publicApi/checkFormcodeExistPublicApi', { formCode: this.page.PageConfig.formCode }).then(res => {
        if (res.status === 0) {
          if (res.results) {
            this.$confirm(`<span style="color:red">当前formCode【${this.page.PageConfig.formCode}】已初始化数据。</span><br>你确定继续进行该操作吗？`,
              `${this.$t(`menu.${this.$route.params.translateName}`)}${this.$t('button.initForm')}`, {
              cancelButtonClass: 'button-close',
              dangerouslyUseHTMLString: true,
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              callback && callback();
            }).catch(() => {
            });
          } else {
            callback && callback();
          }
        } else {
          this.$message.error('初始化失败，请查看日志');
        }
      });
    },
    sysInitForm() {
      const mainColumns = [];
      const detailsColumns = [];
      const pageConfig = this.page.PageConfig;
      const formList = pageConfig.mainFormConfig.formList;
      const subTableConfig = pageConfig.subTableConfig;
      const subTableMatch = pageConfig.subTableMatch;
      // 主表
      for (const item of formList) {
        // (item.inputStatus === 'disable' || item.formType === 'operate') && !item.processStatus
        if (item.formType === 'divisionTitle' || item.formType === 'text' || item.formType === 'promptInformation' || item.formType === 'operate') {
          continue;
        } else {
          mainColumns.push(
            {
              columnCode: item.prop,
              columnName: this.$t(item.label)
            }
          );
        }
      }
      // 子表
      if (subTableMatch) {
        for (const subTable of subTableMatch) {
          const multitonColumns = [];
          for (const item of subTableConfig[subTable.assignment].tableList.slaveColumns) {
            // (item.formType === 'operate') && !item.processStatus
            if (item.formType === 'operate') {
              continue;
            } else {
              multitonColumns.push(
                {
                  columnCode: item.prop,
                  columnName: this.$t(item.label)
                }
              );
            }
          }
          detailsColumns.push(
            {
              columns: multitonColumns,
              multitonCode: subTable.assignment,
              multitonName: this.$t(`${this.$route.params.translateName}.${subTable.assignment}`)
            }
          );
        }
      }
      const formName = this.$t(`menu.${this.$route.params.translateName}`);
      const data = {
        columns: mainColumns,
        details: detailsColumns,
        formCode: this.page.PageConfig.formCode,
        formName,
        position: ''
      };
      // console.log(data, 'data');
      this.$store.dispatch('publicApi/initWorkflowFormPublicApi', data).then(res => {
        if (res.status === 0) {
          this.$message.success('正在初始化，请勿重复点击');
        } else {
          this.$message.error('初始化失败，请查看日志');
        }
      });
    },
    // ------------------------------------- 主表 ----------------------------------------------------
    // 获取编辑表单的项目
    editFormEvent({ eventName, params }) {
      if (eventName === 'clearProjcet') {
        this.handleClearProject(params);
      }
      if (eventName === 'projcet') {
        this.handleSelectProject(params);
      }
      // 合同
      if (eventName === 'clearContract') {
        this.handleClearContract(params);
      }
      if (eventName === 'contract') {
        this.handleSelectContract(params);
      }
      if (eventName === 'clearPartyA') {
        this.handleClearPartyA(params);
      }
      if (eventName === 'partyA') {
        this.handleSelectPartyA(params);
      }
      if (eventName === 'clearPartyB') {
        this.handleClearPartyB(params);
      }
      if (eventName === 'partyB') {
        this.handleSelectPartyB(params);
      }
      if (eventName === 'relationTable') {
        this.handleOtherSelect(params);
      }
      if (eventName === 'clearUsePlace') {
        this.handleClearUsePlace(params);
      }
      if (eventName === 'usePlace') {
        this.handleSelectUsePlace(params);
      }
      if (eventName === 'operateFun') {
        this[params.operateFun] && this[params.operateFun](params);
      }
      if (eventName === 'clearUser') { // 清除用户
        this.handleClearUser(params);
      }
      if (eventName === 'user') { // 获取用户
        this.handleSelectUser(params);
      }
      // 所属公司
      if (eventName === 'clearOrg') { // 清除用户
        this.handleClearOrg(params);
      }
      if (eventName === 'org') { // 获取用户
        this.handleSelectOrg(params);
      }
      // 组织权限
      if (eventName === 'clearAsPropertyOrg') { // 清除用户
        this.handleClearAs(params);
      }
      if (eventName === 'asPropertyOrg') { // 获取用户
        this.handleSelectAs(params);
      }
      if (eventName === 'identify') { // 自动识别
        this.handleIdentify(params);
      }
      if (eventName === 'moreIdentifyList') { // 自动识别
        this.handleMoreIdentify(params);
      }
      if (eventName === 'setPrintModelId') {
        console.log(params.printModelId, 'params.printModelId');
        this.jumpPrintDesign(this.printConfig.printModelCode, this.printConfig.taskId, this.printConfig.id, this.printConfig.loadRouteName, params.printModelId, this.printConfig.flowStatus);
      }
      if (eventName === 'close') {
        this.setRoute();
      }
    },
    // 自动识别附件
    handleIdentify(params) {

    },
    // ----------------------------- 项目 -------------------------------
    // 清除项目
    handleClearProject(params) {
      if (params.item && params.item.formType === 'multipleProject') {
        const projectList = this.pageConfig.projectForm[params.item.prop];
        projectList.splice(projectList.indexOf(params.tag), 1);
        return;
      }
      this.handleSelectProject({ selectList: [], paramsConfig: params });
    },
    // 选择项目
    handleSelectProject(params) {
      if (params.paramsConfig.check) {
        this.handleCheckProject(params);
        return;
      }
      // 多选项目
      if (params.paramsConfig.formType === 'multipleProject') {
        this.$set(this.pageConfig.projectForm, params.paramsConfig.prop, this.$clone(params.selectList));
        return;
      }
      this.handleSelect(params, 'projectName');
    },
    // ----------------------------- 收入合同 -------------------------------
    // 清除收入合同
    handleClearContract(params) {
      this.handleSelectContract({ selectList: [], paramsConfig: params });
    },
    // 选择收入合同
    handleSelectContract(params) {
      this.handleSelect(params, 'contractName');
    },
    // ----------------------------- 甲方单位 -------------------------------
    // 清除甲方单位
    handleClearPartyA(params) {
      this.handleSelectPartyA({ selectList: [], paramsConfig: params });
    },
    // 选择甲方单位
    handleSelectPartyA(params) {
      this.handleSelect(params, 'partyAName');
    },
    // ----------------------------- 乙方单位 -------------------------------
    // 清除甲方单位
    handleClearPartyB(params) {
      this.handleSelectPartyB({ selectList: [], paramsConfig: params });
    },
    // 选择甲方单位
    handleSelectPartyB(params) {
      this.handleSelect(params, 'partyBName');
    },
    // ----------------------------- 员工 ---------------------------------
    // 清除员工
    handleClearUser(params) {
      this.handleSelectUser({ selectList: [], paramsConfig: params });
    },
    // 选择子工程
    handleSelectUser(params) {
      this.handleSelect(params, 'userName');
    },
    // ----------------------------- 所属公司 ---------------------------------
    // 清除所属公司
    handleClearOrg(params) {
      this.handleSelectOrg({ selectList: [], paramsConfig: params });
    },
    // 选择所属公司
    handleSelectOrg(params) {
      for (const item of params.selectList) {
        item[params.paramsConfig.prop] = item.orgName;
      }
      this.handleSelect(params, params.paramsConfig.prop);
    },
    // ------------------------------  权限组织 ------------------------------
    handleClearAs(params) {
      this.handleSelectAs({ selectList: [], paramsConfig: params });
    },
    // 选择权限组织
    handleSelectAs(params) {
      this.handleSelect(params, params.paramsConfig.prop);
    },
    // ----------------------------- 其他与子表关联 -------------------------------
    // 下拉选择框
    handleOtherSelect(params) {
      const arr = params.selectList;
      const item = params.paramsConfig;
      const oldRelationForm = params.oldRelationForm;
      const oldProjectForm = this.oldProjectForm;
      let isTableList = false;
      if (!item.isRelationTable && (!item.relationTable || item.relationTable.length === 0)) {
        this.setSelectValue(item, this.pageConfig.projectForm[item.prop]);
        return;
      }
      for (const table of item.relationTable) {
        if (this.pageConfig.subTableConfig[table] && this.pageConfig.subTableConfig[table].tableData.length) {
          isTableList = true;
        }
      }
      if (oldProjectForm[item.prop] && isTableList) {
        const deletMessage = this.$t('tips.chengeDataTips').replace('{keyValue}', this.$t(`${item.label}`));
        this.$confirm(deletMessage, this.$t('tips.dataChangePrompt'), {
          cancelButtonClass: 'button-close',
          confirmButtonText: this.$t('button.determine'),
          cancelButtonText: this.$t('button.close'),
          dangerouslyUseHTMLString: true,
          type: 'warning'
        }).then(() => {
          if (this.$refs.editForm.$refs.elSelect && this.$refs.editForm.$refs.elSelect.length) {
            this.$set(this.$refs.editForm.$refs.elSelect[0], 'visible', false);
          }
          for (const table of item.relationTable) {
            this.deleteDetail(table);
          }
          this.setSelectValue(item, this.pageConfig.projectForm[item.prop]);
        }).catch(() => {
          this.$set(this.pageConfig.projectForm, item.prop, oldProjectForm[item.prop] || ''); // 显示值
          if (this.$refs.editForm.$refs.elSelect && this.$refs.editForm.$refs.elSelect.length) {
            this.$set(this.$refs.editForm.$refs.elSelect[0], 'visible', false);
          }
          this.setSelectValue(item, this.pageConfig.projectForm[item.prop], false); //
          if (item.formType === 'week') {
            this.$refs.editForm.setWeek(this.pageConfig.projectForm[item.prop] || this.$utils.commonUtil.formatTime(new Date()));
          }
        });
      } else {
        this.setSelectValue(item, this.pageConfig.projectForm[item.prop]);
      }
    },
    // 根据日期判断是月的第几周
    getWeekInMonth(t, item) {
      if (t === undefined || t === '' || t == null) {
        t = new Date();
      } else {
        const _t = new Date();
        _t.setYear(t.getFullYear());
        _t.setMonth(t.getMonth());
        _t.setDate(t.getDate());
        const date = _t.getDate(); // 给定的日期是几号
        _t.setDate(1);
        const d = _t.getDay(); // 1. 得到当前的1号是星期几。
        let fisrtWeekend = d;
        if (d === 0) {
          fisrtWeekend = 1;
          // 1号就是星期天
        } else {
          fisrtWeekend = 7 - d + 1; // 第一周的周未是几号
        }
        if (date <= fisrtWeekend) {
          return 1;
        } else {
          return 1 + Math.ceil((date - fisrtWeekend) / 7);
        }
      }
    },
    // 下拉框联动赋值
    setSelectValue(item, event, cancleFlag = true) {
      this.$set(this.oldProjectForm, item.prop, event);
      if (item.isRelation) {
        item.relationList && item.relationList.forEach(row => {
          let index = 0;
          if (item.formType === 'select' || item.formType === 'selectProject') {
            index = item.selectList.findIndex(v => v[item.valueCode] === event);
          } else {
            index = item.selectList.findIndex(v => v.dataCode === event);
          }
          const value = item.selectList[index] ? item.isTranslate ? this.$t(item.selectList[index][row.value]) : item.selectList[index][row.value] : '';
          this.$set(this.pageConfig.projectForm, row.receive, value); // 显示值
          this.$set(this.oldProjectForm, row.receive, value); // 显示值
        });
      }
      if (item.otherOperate && cancleFlag) {
        item.otherOperateFun && this[item.otherOperateFun](item);
      }
    },
    // ----------------------------- 使用弹出框选择后的一系列赋值操作 -------------------------------
    // 确认选择
    handleSelect(params, displayValue, callback) {
      const arr = params.selectList;
      const item = params.paramsConfig;
      if (displayValue === 'projectName') {
        this.isRefreshFlag = params.isRefreshFlag || false;
      }
      if (!callback) { // 弹窗选择后的下拉框回调
        if (item.otherOperate && item.otherOperateFun) {
          callback = this[item.otherOperateFun];
        }
      }
      // 关联子表时
      if (item.relationTable && item.relationTable.length) {
        let isTableList = false;
        for (const table of item.relationTable) {
          if (this.pageConfig.subTableConfig[table] && this.pageConfig.subTableConfig[table].tableData.length) {
            isTableList = true;
          }
        }
        if (this.pageConfig.projectForm[item.prop] && isTableList) {
          this.selectChange(item, arr, displayValue, callback);
        } else {
          this.setRelationData(item, arr, displayValue, callback);
        }
      } else {
        this.setRelationData(item, arr, displayValue, callback);
      }
    },
    // 选择 关联明细删除提示
    selectChange(item, arr, displayValue, callback) {
      const deletMessage = this.$t('tips.chengeDataTips').replace('{keyValue}', this.$t(`fConfig.${displayValue}`));
      // 页眉更改的时候，不需要再次提示
      if (displayValue === 'projectName' && this.isRefreshFlag === true) {
        for (const table of item.relationTable) {
          this.deleteDetail(table);
        }
        this.setRelationData(item, arr, displayValue, callback);
      } else {
        this.$confirm(deletMessage, this.$t('tips.dataChangePrompt'), {
          confirmButtonText: this.$t('button.determine'),
          cancelButtonText: this.$t('button.close'),
          dangerouslyUseHTMLString: true,
          type: 'warning'
        }).then(() => {
          for (const table of item.relationTable) {
            this.deleteDetail(table);
          }
          this.setRelationData(item, arr, displayValue, callback);
        }).catch((e) => {
          console.log(e, 'e');
        });
      }
    },
    // 主表联动赋值
    setRelationData(item, arr, displayValue, callback) {
      this.$set(this.pageConfig.projectForm, item.prop, arr.length > 0 ? arr[0][displayValue] : ''); // 显示值
      this.$set(this.pageConfig.projectForm, item.key, arr.length > 0 ? arr[0].id : ''); // 关键值
      // console.log(this.pageConfig.projectForm[item.key], [item.key], arr[0].id, 'arr[0].id');
      if (item.isRelation) {
        item.relationList.forEach(row => {
          if (row.isAddress) {
            // 获取详细地址
            let address = '';
            if (arr.length > 0) {
              const continent = arr[0].continent && arr[0].continent.split('-')[0];
              const country = arr[0].country && arr[0].country.split('-')[0];
              const province = arr[0].province && arr[0].province.split('-')[0];
              const city = arr[0].city && arr[0].city.split('-')[0];
              const area = arr[0].area && arr[0].area.split('-')[0];
              address = `${continent}${country}${province}${city}${area}`;
            }
            this.$set(this.pageConfig.projectForm, row.receive, arr.length > 0 ? address : ''); // 显示值
          } else if (row.areaCode) {
            // 货取地址代码
            const areas = [];
            const keysList = ['continent', 'country', 'province', 'city', 'area'];
            for (const key of keysList) {
              if (arr.length && arr[0][key] && arr[0][key].indexOf('-')) {
                const id = arr[0][key].split('-')[1];
                areas.push(Number(id));
              }
              this.$set(this.pageConfig.projectForm, key, arr.length && arr[0][key] ? arr[0][key] : ''); // 显示值
            }
            this.$set(this.pageConfig.projectForm, row.receive, arr.length > 0 ? areas : ''); // 显示值
          } else {
            let value = '';
            if (arr.length) {
              value = arr[0][row.value] === undefined ? '' : arr[0][row.value];
            } else {
              value = '';
            }
            this.$set(this.pageConfig.projectForm, row.receive, value); // 显示值
          }
        });
      }
      if (item.clearRelation && item.clearRelation.length) {
        this.clearRelationData(item.clearRelation);
      }
      callback && callback();
    },
    // 清除相关连动数据
    clearRelationData(clearList) {
      for (const v of clearList) {
        const index = this.pageConfig.mainFormConfig.formList.findIndex(item => item.prop === v.prop);
        if (index >= 0) {
          this[v.clearFun] && this[v.clearFun](this.pageConfig.mainFormConfig.formList[index]);
        }
      }
    },
    // -------------------------------------------- 子表 ----------------------------------------
    // 子表事件按钮事件传出
    mainOperateBtnSubTable(parameter) {
      this[parameter.code](parameter.subTableCode, parameter);
    },
    // 导出明细
    sysHandleExportDetail(tableName) {
      // if (this.type === 'add' || this.type === 'edit') {
      //     this.$message.info(this.$t('tips.exportDetailTips'));
      //     return;
      // }
      const exportParams = {
        url: this.page.PageConfig.processParmas.exportDetail.url,
        params: this.pageConfig.subTableConfig[tableName].tableData
        // params: {
        //     [this.page.PageConfig.processParmas.exportDetail.params]: this.id
        // }
      };
      this.handleExportDetail(exportParams);
    },
    // 导出明细列表操作
    handleExportDetail(exportParams, tableName) {
      const pageName = this.$route.params && this.$route.params.translateName ? this.$route.params.translateName : this.$route.name;
      const tranSlateName = `menu.${pageName}`;
      this.$store.dispatch(exportParams.url, exportParams.params).then(data => {
        if (!data) return;
        const url = window.URL.createObjectURL(new Blob([data]));
        const link = document.createElement('a');
        link.style.display = 'none';
        link.href = url;
        link.setAttribute('download', `${this.$t(tranSlateName)} ${this.$t('fConfig.contractOrderSubsDetails')} ${this.$t('fConfig.excel')}.xls`);
        document.body.appendChild(link);
        link.click();
      });
    },
    // 添加明细
    sysHandleDeletaAdd(tableName) {
      if (this.tableRow) {
        this.pageConfig.subTableConfig[tableName].tableData.push(this.$clone(this.tableRow));
        return;
      }
      const tableDataRow = this.$clone(this.pageConfig.subTableConfig[tableName].tableList.tableDataRow);
      const sorts = this.pageConfig.subTableConfig[tableName].tableData.length + 1;
      tableDataRow.sorts = sorts;
      this.pageConfig.subTableConfig[tableName].tableData.push(tableDataRow);
    },
    // 批量删除
    sysHandleDeletaBatch(tableName, otherOperate) {
      if (otherOperate) {
        this.handleDeleteSubTable(Array.from(this.pageConfig.subTableConfig[tableName].tableData), this.$t(`${this.translateName}.${tableName}`), tableName);
      } else {
        if (this.deleteList[tableName] && this.deleteList[tableName].length) {
          this.handleDeleteSubTable(this.deleteList[tableName], this.$t(`${this.translateName}.${tableName}`), tableName);
        } else {
          this.$message.error(this.$t('tips.pleaseSelectDetailed'));
        }
      }
    },
    // 批量删除操作
    handleDeleteSubTable(arr, keyValue, tableName) {
      if (arr && arr.length > 0) {
        const deletMessage = this.$t('tips.deleteDetailedTips').replace('{keyValue}', keyValue);
        const deleteDetailsMessage = this.$t('tips.deleteDetailsApiTips').replace('{keyValue}', keyValue);
        let messageTips = deletMessage;
        (this.pageConfig.processParmas.deleteDetailsParams && this.pageConfig.processParmas.deleteDetailsParams.url) && (messageTips = deleteDetailsMessage);
        this.$confirm(messageTips, `${this.$t('button.batchDeletion')}${keyValue}`, {
          cancelButtonClass: 'button-close',
          dangerouslyUseHTMLString: true,
          confirmButtonText: this.$t('button.determine'),
          cancelButtonText: this.$t('button.close'),
          type: 'warning'
        }).then(() => {
          this.deleteDetail(tableName, arr);
        }).catch(e => { });
      } else {
        // 请选择明细清单
        arr && this.$message.error(this.$t('tips.pleaseSelectDetailed'));
      }
    },
    // 树形递归删除
    batchDeleteDetail(tableData, v) {
      const index = tableData.indexOf(v);
      if (index > -1) {
        tableData.splice(index, 1);
      }
      tableData.forEach(item => {
        if (item.children && item.children.length > 0) {
          this.batchDeleteDetail(item.children, v);
        }
      });
    },
    deleteDetail(tableName, deleteList) {
      if (!this.pageConfig.subTableConfig[tableName]) return;
      if (!deleteList) {
        deleteList = Array.from(this.pageConfig.subTableConfig[tableName].tableData);
      }
      deleteList.forEach(v => {
        this.batchDeleteDetail(this.pageConfig.subTableConfig[tableName].tableData, v);
        // this.pageConfig.subTableConfig[tableName].tableData.splice(this.pageConfig.subTableConfig[tableName].tableData.indexOf(v), 1);
      });
      if (this.pageConfig.processParmas.deleteDetailsParams && this.pageConfig.processParmas.deleteDetailsParams.url) {
        const deleteDetailsParams = this.pageConfig.processParmas.deleteDetailsParams;
        const deleteIds = deleteList.filter(v => v.id).map(i => i.id);
        deleteIds.length && this.$store.dispatch(deleteDetailsParams.url, deleteIds).then(res => {
          if (res.status === 0) {
            this.$message.success(`${this.$t('button.delete')}${this.$t('tips.success')}!`);
          } else {
            this.$message.error(`${this.$t('button.delete')}${this.$t('tips.fail')}!`);
          }
        });
      }
      if (this.$refs[tableName] && this.$refs[tableName].length) {
        this.$refs[tableName][0].clearSelectionTable();
      }
      // 删除后的数值计算回调
      this.deletTableCallback && this.deletTableCallback(tableName, deleteList);
    },
    // 子表操作事件
    editTableEvent({ eventName, params }) {
      if (eventName === 'tableSelect') { // 下拉选择
        this.handleTableSelect(params);
      }
      if (eventName === 'operateDataEvent') { // 数值计算
        this.handleCalculation(params);
      }
      if (eventName === 'handleTable') { // 表格文本操作事件
        params.item && params.item.fn && this[params.item.fn](params);
      }
      if (eventName === 'fnRowName') { // 表格操作按钮
        const { btnParameter, row, index } = params;
        btnParameter.fn && this[btnParameter.fn](row, index);
      }
    },
    // 子表下拉选择赋值
    handleTableSelect({ item, row, event, subTable, rowIndex }) {
      item.relationList.forEach(res => {
        let index = 0;
        if (item.formType === 'select' || item.formType === 'selectProject') {
          index = item.selectList.findIndex(v => v[item.valueCode] === event);
        } else {
          index = item.selectList.findIndex(v => v.dataCode === event);
        }
        const value = item.selectList[index] ? item.isTranslate ? this.$t(item.selectList[index][res.value]) : item.selectList[index][res.value] : '';
        this.$set(this.pageConfig.subTableConfig[subTable.subTableName].tableData[rowIndex], res.receive, value);
        if (item.otherOperate) {
          item.otherOperateFun && this[item.otherOperateFun](item);
        }
      });
    },
    // 数值计算
    handleCalculation(params) {
    },
    // 行内样式表格方法
    getRowClassName({ row, rowIndex }) {
      if (!this.checkRow(row)) {
        return '';
      } else { // 返回true 则爆红
        return 'error-active';
      }
    },
    // 明细模板下载
    sysHandleDownloadTemplate() {
      const pageName = this.$route.params && this.$route.params.translateName ? this.$route.params.translateName : this.$route.name;
      const tranSlateName = `menu.${pageName}`;
      const tableName = this.page.PageConfig.processParmas.dowanloadDetail.tableName;
      const table = `${pageName}.${tableName}`;
      this.$store.dispatch(this.page.PageConfig.processParmas.dowanloadDetail.url).then(data => {
        if (!data) return;
        const url = window.URL.createObjectURL(new Blob([data]));
        const link = document.createElement('a');
        link.style.display = 'none';
        link.href = url;
        link.setAttribute('download', `${this.$t(tranSlateName)} ${this.$t(table)} ${this.$t('fConfig.excel')}.xls`);
        document.body.appendChild(link);
        link.click();
      });
    },
    // ------------------------------- 主表自动赋值 -------------------------
    // 项目赋值
    setPorjcetData() {
      const project = this.pageConfig.mainFormConfig.formList.find(v => v.formType === 'project' && v.inputStatus !== 'disable');
      if (!project) return;
      const data = {
        pageNo: 1,
        pageSize: 10,
        beginTimeFrom: '',
        beginTimeTo: '',
        orgId: '',
        projectName: '',
        projectStatus: [1, 2, 3],
        projectTypeCode: [],
        projectManagerName: ''
      };
      const url = project.isNoAutn ? 'publicApi/getProjectAllPublicApi' : 'publicApi/getProjectPermissionPage';
      if (project.isNoAutn) {
        data.projectStatus = [1, 2, 3]; // 查询已启用且未竣工的项目
      }
      this.$store.dispatch(url, data).then(res => {
        const records = res.results.records;
        if (records.length === 0 || records.length > 1) return;
        const params = {
          paramsConfig: this.$clone(project),
          selectList: [records[0]]
        };
        this.handleSelectProject(params);
      });
    },
    // 所属组织赋值
    setOrgData() {
      const org = this.pageConfig.mainFormConfig.formList.find(v => v.formType === 'orgName' && v.inputStatus !== 'disable' && !v.isShowDepartName);
      if (!org) return;
      const { isShowDepartName, isOnlyCheckDepartName } = org;
      const authorityOrgIdList = this.$utils.Auth.hasUserInfo().data || [];
      this.$store.dispatch('publicApi/getEffectiveOrgTree').then(res => {
        if (res.results.length === 0 || authorityOrgIdList.length > 1 || authorityOrgIdList.length === 0) return;
        if (!isShowDepartName) {
          this.filterOgr(res.results);
        }
        const firstOrg = this.getSignleOrg(res.results, authorityOrgIdList[0]);
        firstOrg[org.prop] = firstOrg.orgName;
        const params = {
          paramsConfig: this.$clone(org),
          selectList: [firstOrg]
        };
        this.handleSelectOrg(params);
      });
    },
    filterOgr(targetList) { // 遍历后台传来的路由字符串，转换为组件对象
      const filterList = targetList.filter(v => {
        if (v.children && v.children.length) {
          v.children = this.filterOgr(v.children);
        }
        return v.orgAttributeCode !== '04';
      });
      return filterList;
    },
    // 获取单个组织
    getSignleOrg(data, id) {
      let hasFound = false; // 表示是否有找到id值
      let result = null;
      const fn = function (data) {
        if (Array.isArray(data) && !hasFound) { // 判断是否是数组并且没有的情况下，
          data.forEach(item => {
            if (item.id === id) { // 数据循环每个子项，并且判断子项下边是否有id值
              result = item; // 返回的结果等于每一项
              hasFound = true; // 并且找到id值
            } else if (item.children) {
              fn(item.children); // 递归调用下边的子项
            }
          });
        }
      };
      fn(data); // 调用一下
      return result;
    },
    // 字段变化后
    changeStyle(row, item) {
      const relationKeyIds = item.relationKeyIds || [];
      if (!relationKeyIds.length) return;
      if (relationKeyIds.length > 1) {
        if ((row[relationKeyIds[0]] || row[relationKeyIds[1]]) && row[item.prop] !== row[item.originProp]) {
          return 'afterStatus';
        }
      }
      if (relationKeyIds.length === 1) {
        if (row[relationKeyIds[0]] && row[item.prop] !== row[item.originProp]) {
          return 'afterStatus';
        }
      }
    },
    // 是否显示变更前
    showChangeProp(row, item) {
      const relationKeyIds = item.relationKeyIds || [];
      if (!relationKeyIds.length) return false;
      if (relationKeyIds.length > 1) {
        if ((row[relationKeyIds[0]] || row[relationKeyIds[1]]) && row[item.prop] !== row[item.originProp]) {
          return true;
        }
      }
      if (relationKeyIds.length === 1) {
        if (row[relationKeyIds[0]] && row[item.prop] !== row[item.originProp]) {
          return true;
        }
      }
    },
    // 变更前数据
    setChangeContent(row, item) {
      return row[item.originProp] ? item.filterName === 'setMoney' ? this.$utils.commonUtil.toQfw(row[item.originProp], item.precision) : row[item.originProp] : '';
    },
    // 获取固定子系统菜单及页面权限
    getsubSystemMenus(subSystemCode, pageCode, closeCallback) {
      const loadingSubmit = this.$loading({
        lock: true,
        background: 'rgba(0,0,0,0.7)',
        spinner: 'el-icon-loading'
      });
      this.$store.dispatch('publicApi/getsubSystemMenusPublic', { subSystemCode }).then(res => {
        let getRouter = [];
        if (res.results && res.results.length > 0) {
          getRouter = res.results;
        }
        let ifEmpower = false;
        if (pageCode) {
          const empowerMenu = [];
          this.getEmpowerMenuList(getRouter, pageCode, empowerMenu);
          if (empowerMenu && empowerMenu.length) {
            closeCallback && closeCallback();
            const href = `${this.$utils.config.jumpUrl}/contract/#/contractExpendInvoice`;
            window.open(href, '_blank');
            loadingSubmit.close();
          } else {
            // 您还没有被授权 收票登记功能，您可以联系管理员进行授权。
            this.$message.warning(this.$t('tips.functionUnauthorizedTips'));
            loadingSubmit.close();
          }
        } else {
          ifEmpower = getRouter.length > 0;
        }
      }).catch(e => {
        // 您还没有被授权 收票登记功能，您可以联系管理员进行授权。
        this.$message.warning(this.$t('tips.functionUnauthorizedTips'));
        loadingSubmit.close();
      });
    },
    getEmpowerMenuList(menuList, pageCode, result) {
      for (const item of menuList) {
        if (item.path === pageCode && item.flg === '1') {
          result.push(item);
        } else {
          if (item.children && item.children.length) {
            this.getEmpowerMenuList(item.children, pageCode, result);
          }
        }
      }
    },

    // 初始化页面翻译
    handleAddLanguageInit() {
      const data = {
        Language: 'zh',
        subSystemCode: this.$utils.config.subSystemCode,
        pageCode: this.translateName
      };
      this.$store.dispatch('publicApi/languageValuesPublicApi', data).then(res => {
        if (res.status === 0 && res.results && res.results.length > 0) {
          this.$confirm('当前页面已存在翻译，是否继续进行初始化？', '提示', {
            cancelButtonClass: 'button-close',
            confirmButtonText: this.$t('button.determine'),
            cancelButtonText: this.$t('button.close'),
            dangerouslyUseHTMLString: true,
            type: 'warning'
          }).then(() => {
            this.initLanguage();
          }).catch((e) => {
          });
        } else {
          this.$confirm('确定进行翻译初始化吗？', '提示', {
            cancelButtonClass: 'button-close',
            confirmButtonText: this.$t('button.determine'),
            cancelButtonText: this.$t('button.close'),
            dangerouslyUseHTMLString: true,
            type: 'warning'
          }).then(() => {
            this.initLanguage();
          }).catch((e) => {
          });
        }
      });
    },
    initLanguage() {
      // 通用
      const currencyList = ['button', 'tips', 'dialog', 'time', 'fConfig', 'tagsView', 'subSystemType', 'subSystem',
        'print', 'exception', 'login', 'supplierLogin', 'app'];
      const pageConfig = this.pageConfig;
      const details = [];
      const mainFormConfig = pageConfig.mainFormConfig.formList;
      const subTableConfig = pageConfig.subTableConfig;
      const subTableMatch = pageConfig.subTableMatch;
      // 主表
      for (const item of mainFormConfig) {
        const prop = item.label.split('.')[1];
        const index = details.findIndex(v => v.columnCode === prop);
        const key = currencyList.findIndex(v => v === item.label.split('.')[0]);
        const isInit = item.isInit !== false;
        index < 0 && key < 0 && isInit && prop && item.name && details.push({
          columnCode: prop,
          columnName: item.name
        });
        if (item.children && item.children.length) {
          for (const val of item.children) {
            const key = currencyList.findIndex(v => v === val.label.split('.')[0]);
            const prop = val.label.split('.')[1];
            key < 0 && prop && val.name && details.push({
              columnCode: prop,
              columnName: val.name
            });
          }
        }
      }
      // 字表
      if (subTableMatch && subTableMatch.length) {
        for (const item of subTableMatch) {
          for (const row of subTableConfig[item.assignment].tableList.slaveColumns) {
            const prop = row.label.split('.')[1];
            const isInit = row.isInit !== false;
            const index = details.findIndex(v => v.columnCode === prop);
            const key = currencyList.findIndex(v => v === row.label.split('.')[0]);
            index < 0 && key < 0 && isInit && prop && row.name && details.push({
              columnCode: prop,
              columnName: row.name
            });
            if (row.children && row.children.length) {
              for (const val of row.children) {
                const key = currencyList.findIndex(v => v === val.label.split('.')[0]);
                const prop = val.label.split('.')[1];
                key < 0 && prop && val.name && details.push({
                  columnCode: prop,
                  columnName: val.name
                });
              }
            }
          }
          if (subTableConfig[item.assignment].tableList.childrenSlaveColumns) {
            for (const row of subTableConfig[item.assignment].tableList.childrenSlaveColumns) {
              const prop = row.label.split('.')[1];
              const isInit = row.isInit !== false;
              const index = details.findIndex(v => v.columnCode === prop);
              const key = currencyList.findIndex(v => v === row.label.split('.')[0]);
              index < 0 && key < 0 && isInit && prop && row.name && details.push({
                columnCode: prop,
                columnName: row.name
              });
              if (row.children && row.children.length) {
                for (const val of row.children) {
                  const key = currencyList.findIndex(v => v === val.label.split('.')[0]);
                  const prop = val.label.split('.')[1];
                  key < 0 && prop && val.name && details.push({
                    columnCode: prop,
                    columnName: val.name
                  });
                }
              }
            }
          }
        }
      }
      const data = {
        subSystemCode: this.$utils.config.subSystemCode,
        pageCode: this.translateName,
        details
      };
      // console.log(data, 'data');
      this.$store.dispatch('publicApi/initLanguagePublicApi', data).then(res => {
        if (res.status === 0) {
          this.$message.success('初始化成功');
          this.languageClear();
        } else {
          this.$message.error('初始化失败');
        }
      });
    },
    languageClear() {
      this.$store.dispatch('publicApi/languageClearPublicApi').then(res => {
        if (res.status === 0) {
          this.$message.success('清除缓存成功');
        } else {
          this.$message.error('清除缓存失败');
        }
      });
    },
    // 页面打印
    handleLogPage() {
      const formList = [];
      for (const item of this.pageConfig.mainFormConfig.formList) {
        const row = {};
        for (const i in item) {
          this.$set(row, 'label', this.$t(item.label));
          this.$set(row, 'name', item.label);
          this.$set(row, 'prop', item.printIdName || item.prop);
          item.isRule && this.$set(row, 'isRule', item.isRule);
          (item.formType === 'date' || item.filterName) && this.$set(row, 'filterName', item.formType === 'date' ? 'date' : item.filterName);
          (item.prop === 'taxRate' || item.filterName === 'taxRate') && this.$set(row, 'filterName', 'taxRate');
          item.formType === 'upload' && this.$set(row, 'isAttachment', true);
          if (item.formType === 'dicSelect' && item.selectList.length > 0 && item.prop !== 'taxRate' && item.filterName === 'taxRate') {
            this.$set(row, 'prop', item.prop);
            this.$set(row, 'customSelect', true);
            this.$set(row, 'customSelectList', item.selectList);
          }
          item.isMultiple && item.slotName && this.$set(row, 'slotName', item.slotName);
        }
        formList.push(row);
      }
      console.log(JSON.stringify(formList));
      console.log('----------------------------------');
      const formDetailedList = {};
      for (const i in this.pageConfig.subTableConfig) {
        this.$set(formDetailedList, i, []);
        const item = this.pageConfig.subTableConfig[i];
        const tableList = item.tableList.slaveColumns;
        for (const detail of tableList) {
          const row = {};
          for (const i in detail) {
            this.$set(row, 'label', this.$t(detail.label));
            this.$set(row, 'name', detail.label);
            this.$set(row, 'prop', detail.printIdName || detail.prop);
            detail.isRule && this.$set(row, 'isRule', detail.isRule);
            (item.prop === 'taxRate' || item.filterName === 'taxRate') && this.$set(row, 'filterName', 'taxRate');
            (detail.formType === 'date' || detail.filterName) && this.$set(row, 'filterName', detail.formType === 'date' ? 'date' : detail.filterName);
            detail.formType === 'attachment' && this.$set(row, 'isAttachment', true);
            if (detail.formType === 'dicSelect' && detail.selectList.length > 0 && item.prop !== 'taxRate' && item.filterName === 'taxRate') {
              this.$set(row, 'customSelect', true);
              this.$set(row, 'prop', item.prop);
              this.$set(row, 'customSelectList', item.selectList);
            }
            detail.isMultiple && detail.slotName && this.$set(row, 'slotName', detail.slotName);
          }
          formDetailedList[i].push(row);
        }
      }
      console.log(JSON.stringify(formDetailedList));
    },
    // 子表选择明细后判断唯一值
    sysSetSubTable(tableName, arr, rowKey, callback) {
      const tableData = this.$clone(this.pageConfig.subTableConfig[tableName].tableData);
      const selectTableList = [];
      if (!tableData.length || !arr.length) {
        this.$set(this.pageConfig.subTableConfig[tableName], 'tableData', arr);
      }
      if (tableData.length) {
        for (const item of tableData) {
          for (const val of arr) {
            if (item[rowKey] === val[rowKey]) {
              selectTableList.push(item);
            }
          }
        }
        for (const item of arr) {
          const index = tableData.findIndex(v => v[rowKey] === item[rowKey]);
          if (index < 0) {
            selectTableList.push(item);
          }
        }
        this.$set(this.pageConfig.subTableConfig[tableName], 'tableData', selectTableList);
      }
      callback && callback();
    },
    guid() {
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        const r = Math.random() * 16 | 0; const v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
      });
    }
  }
};
