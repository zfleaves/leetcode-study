
// 根据菜单名称查找 formCode
export default {
    // 安全管理
    safetyPlan: {
        formCode: 'safetyPlan'
    },
    // 属地划分
    safetyTerritoryPartition: {
        formCode: 'safetyTerritoryPartition'
    },
    // 属地规划列表
    safetyTerritoryPlan: {
        formCode: 'safetyTerritoryPlan'
    },
    // 安全培训纪录列表
    safetyTrain: {
        formCode: 'safetyTrain'
    },
    // 投资资料管理
    investData: {
        formCode: 'investData'
    },
    // 投资资料查阅
    investDataBorrowing: {
        formCode: 'investDataBorrowing'
    },
    // 政府验收
    checkUnite: {
        formCode: 'checkUnite'
    },
    // 交付验收
    checkDeliver: {
        formCode: 'checkDeliver'
    },
    // 全景计划编制
    planPanorama: {
        formCode: 'planPanorama'
    },
    // 全景计划编制变更
    planPanoramaChange: {
        formCode: 'planPanoramaChange'
    },
    // 全景计划销项
    planPanoramaOutput: {
        formCode: 'planPanoramaOutput'
    },
    // 专项计划编制
    planSpecial: {
        formCode: 'planSpecial'
    },
    // 专项计划编制变更
    planSpecialChange: {
        formCode: 'planSpecialChange'
    },
    // 专项计划销项
    planSpecialOutput: {
        formCode: 'planSpecialOutput'
    },
    // 危大工程管控
    safetyEngineeringControl: {
        formCode: 'safetyEngineeringControl'
    },
    // 特种设备入场审查
    safetyDeviceInspect: {
        formCode: 'safetyDeviceInspect'
    },
    // 联合巡检报告
    inspectUniteReport: {
        formCode: 'inspectUniteReport'
    },
    // 安环中心巡检报告
    inspectSafetyReport: {
        formCode: 'inspectSafetyReport'
    },
    // 项目中心巡检报告
    paymentWithoutContract: {
        formCode: 'paymentWithoutContract'
    },
    // 赋能学习资料
    qualityEmpoweringLearningEdit: {
        formCode: 'qualityEmpoweringLearningEdit'
    },
    // 下发学习资料
    qualityDistributeLearningEdit: {
        formCode: 'qualityDistributeLearningEdit'
    },
    // 监理日志
    qualitySupervisorDaily: {
        formCode: 'qualitySupervisorDaily'
    },
    // 监理月报
    qualitySupervisorMonthly: {
        formCode: 'qualitySupervisorMonthly'
    },
    // 监理通知单/回复单
    qualitySupervisorNotice: {
        formCode: 'qualitySupervisorNotice'
    },
    // ----------------------------奖惩管理---------------------
    // 安环中心奖惩管理
    bonusPenaltySafety: {
        formCode: 'bonusPenaltySafety'
    },
    // 项目建设中心奖惩管理
    bonusPenaltyConstruction: {
        formCode: 'bonusPenaltyConstruction'
    },
    // 承包商列表
    contractorManage: {
        formCode: 'contractorManage'
    },
    // 评分列表
    contractorScore: {
        formCode: 'contractorScore'
    },
    // 项目预立项
    proProjectPreApproval: {
        formCode: 'proProjectPreApproval'
    },
    // 项目立项
    proProjectApprovalApply: {
        formCode: 'proProjectApprovalApply'
    },
    // 危大工程管控销项
    safetyEngineeringOutput: {
        translateName: 'safetyHiddenDangerOutput'
    },
    // 隐患追踪
    safetyHiddenDangerOutput: {
        translateName: 'safetyHiddenDangerOutput'
    },
    // 项目中心巡检报告
    inspectConstructReport: {
        translateName: 'inspectConstructReport'
    }
};
