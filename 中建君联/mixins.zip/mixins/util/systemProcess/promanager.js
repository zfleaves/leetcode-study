
import config from 'util/config';

export default {
    //  -----------邦普循环工作平台 -promanager ---------------------
    // --------------------------------------------投资管理--------------------------------------------
    // 投资资料管理
    investData: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'investData'
    },
    // 投资资料查阅
    investDataBorrowing: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'investDataBorrowing'
    },
    //  -----------安全管理 ---------------------
    // 安全策划
    safetyPlan: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'safetyPlan'
    },
    // 属地划分
    safetyTerritoryPartition: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'safetyTerritoryPartition'
    },
    // 属地规划列表
    safetyTerritoryPlan: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'safetyTerritoryPlan'
    },
    // 安全培训纪录列表
    safetyTrain: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'safetyTrain'
    },

    // 政府验收
    checkUnite: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'checkUnite'
    },
    // 交付验收
    checkDeliver: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'checkDeliver'
    },
    // --------------------------------------------计划管理--------------------
    // 全景计划编制
    planPanorama: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'planPanorama'
    },
    // 全景计划编制变更
    planPanoramaChange: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'planPanoramaChange'
    },
    // 全景计划销项
    planPanoramaOutput: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'planPanoramaOutputPersonal'
    },
    // 专项计划编制
    planSpecial: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'planSpecial'
    },
    // 专项计划编制变更
    planSpecialChange: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'planSpecialChange'
    },
    // 专项计划销项
    planSpecialOutput: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'planSpecialOutputPersonal'
    },
    // 危大工程管控
    safetyEngineeringControl: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'safetyEngineeringControl'
    },
    // 特种设备入场审查
    safetyDeviceInspect: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'safetyDeviceInspect'
    },
    // 特种作业人员管理
    safetySpecialUserInspect: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'safetySpecialUserInspect'
    },
    // 联合巡检报告
    inspectUniteReport: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'inspectUniteReport'
    },
    // 安环中心巡检报告
    inspectSafetyReport: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'inspectSafetyReport'
    },
    // 项目中心巡检报告
    inspectConstructReport: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'inspectConstructReport'
    },
    // ----------------------------质量管理---------------------
    // 赋能学习资料
    qualityEmpoweringLearning: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'qualityEmpoweringLearning'
    },
    // 下发学习资料
    qualityDistributeLearning: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'qualityDistributeLearning'
    },
    // 监理日志
    qualitySupervisorDaily: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'qualitySupervisorDaily'
    },
    // 监理周报
    qualitySupervisorWeekly: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'qualitySupervisorWeekly'
    },
    // 监理月报
    qualitySupervisorMonthly: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'qualitySupervisorMonthly'
    },
    // 监理通知单/回复单
    qualitySupervisorNotice: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'qualitySupervisorNotice'
    },
    // ----------------------------奖惩管理---------------------
    // 安环中心奖惩管理
    bonusPenaltySafety: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'bonusPenaltySafety'
    },
    // 项目建设中心奖惩管理
    bonusPenaltyConstruction: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'bonusPenaltyConstruction'
    },
    // 项目预立项
    proProjectPreApproval: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'proProjectPreApproval'
    },
    // 项目立项
    proProjectApprovalApply: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'proProjectApprovalApply'
    },
    // 承包商列表
    contractorManage: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'contractorManage'
    },
    // 评分列表
    contractorScore: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'contractorScore'
    },
    // 危大工程管控销项(个人)
    safetyEngineeringOutput: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'safetyEngineeringOutputPersonal'
    },
    // 隐患追踪
    safetyHiddenDangerOutput: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'safetyHiddenDangerOutputPersonal'
    },
    // 我的任务
    qualityTaskDistributeOutput: {
        jumpUrl: `${config.jumpUrl}/#/processApprovalPage`,
        translateName: 'qualityTaskDistributeOutput'
    }
};
