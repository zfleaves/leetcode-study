/*
 * @Author: your name
 * @Date: 2020-07-01 14:45:03
 * @LastEditTime: 2022-09-13 16:37:47
 * @LastEditors: zengqin 1058574586@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_portal\src\util\auth.js
 */
import config from './config';
import Storage from './storage';

const storage = new Storage();

const authToken = {
    // 设置登录状态
    setLoginStatus() {
      // 设置超时登录时间，在该时间范围内没有任何请求操作则自动删除
      // let maxAge = new Date(new Date().getTime() + 30 * 60 * 1000);
      localStorage.setItem('loginStatus', 'true');
    },
    // 当前是否是登录状态
    isLogin() {
      return localStorage.getItem('loginStatus');
    },
    // 当前页面刷新状态
    getIsRefresh: () => {
      return localStorage.getItem('isRefresh');
    },
    // Token
    hasToken: () => {
      return localStorage.getItem('token') || '';
    },
    // 设置模拟登录Token
    setToken: (token) => {
      localStorage.setItem('token', token);
    },
    // 移除Token
    removeToken: () => {
      localStorage.removeItem('token');
    },
    // 移除Api
    removeApi: () => {
      localStorage.removeItem('api');
    },
    // 个人信息
    hasUserInfo: () => {
      return localStorage.getItem('userInfo') ? JSON.parse(localStorage.getItem('userInfo')) : '';
    },
    // 设置个人信息资料
    setUserInfo: (data) => {
      localStorage.setItem('userInfo', JSON.stringify(data));
    },
    // 移除个人信息资料
    removeUserInfo: () => {
      localStorage.removeItem('userInfo');
    },
    // 自定义登录页面
    hasLoginTitle: () => {
      return localStorage.getItem('loginTitle') ? localStorage.getItem('loginTitle') : 'login';
    },
    // 设置自定义登录页面
    setLoginTitle: (data) => {
      localStorage.setItem('loginTitle', data || 'login');
    },
    // 当前显示菜单
    hasCurrentMenuRouter: () => {
      return localStorage.getItem('current-menu') ? JSON.parse(localStorage.getItem('current-menu')) : [];
    },
    setCurrentMenuRouter: (menu) => {
      localStorage.setItem('current-menu', JSON.stringify(menu));
    },
    removeCurrentMenuRouter: () => {
      localStorage.removeItem('current-menu');
    },
    // 全部菜单
    hasViewMenuRouter: () => {
      return localStorage.getItem('menu') ? JSON.parse(localStorage.getItem('menu')) : [];
    },
    setViewMenuRouter: (menu) => {
      localStorage.setItem('menu', JSON.stringify(menu));
    },
    removeViewMenuRouter: () => {
      localStorage.removeItem('menu');
    },
    // 菜单
    hasMenuRouter: () => {
      return localStorage.getItem(`${config.subSystemCode}-menu`) ? JSON.parse(localStorage.getItem(`${config.subSystemCode}-menu`)) : [];
    },
    setMenuRouter: (menu) => {
      localStorage.setItem(`${config.subSystemCode}-menu`, JSON.stringify(menu));
    },
    removeMenuRouter: () => {
      localStorage.removeItem(`${config.subSystemCode}-menu`);
    },
    // 语言设置
    hasLanguage: () => {
      return localStorage.getItem('language') || 'zh';
    },
    setLanguage: (language) => {
      localStorage.setItem('language', language);
    },
    removeLanguage: () => {
      localStorage.removeItem('language');
    },
    // 标签打印
    setLabelPrint(data) {
      localStorage.setItem('LabelPrint', JSON.stringify(data));
    },
    hasLabelPrint() {
      return localStorage.getItem('LabelPrint') ? JSON.parse(localStorage.getItem('LabelPrint')) : '';
    },
    removeLabelPrint() {
      localStorage.removeItem('LabelPrint');
    },
    removeRouteTitle() {
      localStorage.removeItem('RouteTitle');
    },
    // 重新登录
    reLogin() {
      // userName language
      const language = localStorage.getItem('language') || 'zh';
      const userName = localStorage.getItem('userName') || '';
      const loginTitle = localStorage.getItem('loginTitle') || 'login';
      // 供方
      const sTtoken = localStorage.getItem('sTtoken') || '';
      const sUserInfo = localStorage.getItem('sUserInfo') || '';
      const sUserName = localStorage.getItem('sUserName') || '';
      const sLanguage = localStorage.getItem('sLanguage') || '';
      const sRouteTitle = localStorage.getItem('sRouteTitle') || '';
      localStorage.clear();
      localStorage.setItem('language', language);
      localStorage.setItem('userName', userName);
      localStorage.setItem('loginTitle', loginTitle);
      localStorage.setItem('sTtoken', sTtoken);
      localStorage.setItem('sUserInfo', sUserInfo);
      localStorage.setItem('sUserName', sUserName);
      localStorage.setItem('sLanguage', sLanguage);
      localStorage.setItem('sRouteTitle', sRouteTitle);
    }
};
export default authToken;
