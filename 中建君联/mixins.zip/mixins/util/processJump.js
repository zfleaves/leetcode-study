/*
 * @Author: your name
 * @Date: 2021-12-29 16:32:18
 * @LastEditTime: 2022-06-16 17:31:25
 * @LastEditors: zengqin 1058574586@qq.com
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \web_projectprocess\src\mixins\util\processJump.js
 */

// 邦普循环工作平台
import promanager from './systemProcess/promanager';

export default {
    // ----------- 邦普循环工作平台 -promanager ---------------------
    ...promanager
};
