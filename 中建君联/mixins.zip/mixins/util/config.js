/*
 * @Author: your name
 * @Date: 2020-06-28 09:08:48
 * @LastEditTime: 2022-07-12 10:05:40
 * @LastEditors: zengqin 1058574586@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_basicconfiguration-企业信息及配置\src\util\config.js
 */

let baseIP = 'http://47.98.181.117';
let testUrl = `${baseIP}:1060`;
let jumpUrl = `${baseIP}:8811`; // 建设方跳转地址
let supJumpUrl = `${baseIP}:8812`; // 合作方跳转地址
let jxyLoginUrl = `${baseIP}:8811/#/login`; // 建设方登录地址
let imageUrl = `${baseIP}:8811`; // 图片预览路径
const baseUrl = window.location.href;
if (baseUrl) {
  if (baseUrl.indexOf('http://localhost') !== -1) {
    // 测试
    baseIP = 'http://47.98.181.117';
    testUrl = `${baseIP}:1060`;
    jumpUrl = `${baseIP}:8811`;
    supJumpUrl = `${baseIP}:8812`;
    imageUrl = `${baseIP}:8811`;
    const hashIndex = baseUrl.indexOf('#'); // 查找 # 号位置
    if (hashIndex !== -1) {
      const contentBeforeHash = baseUrl.substring(0, hashIndex); // 提取 # 号之前的内容
      jxyLoginUrl = `${contentBeforeHash}#/login`;
    } else {
      console.log('该链接没有 # 号或者不存在');
    }
  } else if (baseUrl.indexOf('http://47.98.181.117') !== -1) {
    // 测试
    baseIP = 'http://47.98.181.117';
    testUrl = `${baseIP}:1060`;
    jumpUrl = `${baseIP}:8811`;
    supJumpUrl = `${baseIP}:8812`;
    imageUrl = `${baseIP}:8811`;
    jxyLoginUrl = `${baseIP}:8811/#/login`;
  }
}

const releaseUrl = testUrl; // 发布
const Config = {
  url: releaseUrl,
  jumpUrl,
  supJumpUrl,
  jxyLoginUrl,
  // 后台文件上传 用户logo 用户头像 签名
  fileUrl: `${releaseUrl}/basic/file/backstage/upload`,
  // 租户文件上传 用于业务
  fileTenantUrl: `${releaseUrl}/basic/file/tenant/upload`,
  // 文件下载
  fileCmsUrl: `${releaseUrl}/basic/file/api/local/download?fileId=`,
  // 文件预览
  fileViewUrl: `${releaseUrl}/basic/file/api/view?fileId=`,
  // 图片预览
  imageUrl: `${imageUrl}/file/`,
  // 系统名称
  subSystemCode: 'promanager',
  // 基础系统
  basicSystemCode: 'basic',
  // 菜单
  pageMenuCode: 'menu',
  // 数据字典
  dataList: [
    { name: '税率', id: 25, code: 'taxRate' },
    { name: '通知类型', id: 28, code: 'noticeTypeCode' },
    { name: '任职状态', id: 2, code: 'officeStatusCode' },
    { name: '业态', id: 33, code: 'businessFormatCode' },
    { name: '建设性质', id: 6, code: 'constructionNatureCode' },
    { name: '数据权限', id: 7, code: 'dataPermissionCode' },
    { name: '项目状态', id: 4, code: 'projectStatus' },
    { name: '发票类型', id: 35, code: 'invoiceTypeCode' },
    { name: '变更等级', id: 40, code: 'changeLevelCode' },
    { name: '单位性质', id: 41, code: 'propertyCode' },
    { name: '是否合格', id: 42, code: 'appraiseStatus' },
    { name: '标签', id: 43, code: 'tagCode' },
    { name: '计税方式', id: 44, code: 'taxMethodCode' },
    { name: '纳税人类型', id: 45, code: 'taxPayerTypeCode' },
    { name: '往来性质', id: 46, code: 'dealingsPropertyCode' },
    { name: '节点身份', id: 48, code: 'nodeIdentifyCode' },
    { name: '操作类型', id: 49, code: 'operateType' },
    { name: '上传文件所属模块', id: 50, code: 'fileType' },
    { name: '性别', id: 51, code: 'sex' },
    { name: '提交状态', id: 81, code: 'flowStatus' },
    { name: '所属工程', id: 82, code: 'belongEngineeringCode' },
    { name: '文件类型', id: 83, code: 'dataTypeCode' },
    { name: '模板类型', id: 84, code: 'planTemplateCode' },
    { name: '阶段', id: 85, code: 'planStageCode' },
    { name: '级别', id: 86, code: 'planLevelsCode' },
    { name: '完成状态', id: 87, code: 'completeStatusCode' },
    { name: '模板分类', id: 88, code: 'safetyTemplateCode' },
    { name: '专项计划类型', id: 89, code: 'planSpecialTypeCode' },
    { name: '报告类型', id: 90, code: 'safetyReportCode' },
    { name: '工种', id: 91, code: 'jobTypeCode' },
    { name: '培训类型', id: 92, code: 'trainTypeCode' },
    { name: '培训状态', id: 93, code: 'trainStatusCode' },
    { name: '阶段类型', id: 94, code: 'stageTypeCode' },
    { name: '颗粒度', id: 95, code: 'particleTypeCode' },
    { name: '行为类别', id: 96, code: 'behaviorTypeCode' },
    { name: '特种设备分类', id: 97, code: 'deviceTypeCode' },
    { name: '进场状态', id: 98, code: 'entryStatus' },
    { name: '完成状态(危大工程管控销项)', id: 101, code: 's_completeStatusCode' },
    { name: '证件状态', id: 99, code: 'certificatesStatus' },
    { name: '证件名称', id: 100, code: 'certificatesCode' },
    { name: '风险等级', id: 102, code: 'dangerLevelCode' },
    { name: '奖惩类型', id: 103, code: 'bonusPenaltyTypeCode' },
    { name: '奖惩形式', id: 104, code: 'bonusPenaltyFormCode' },
    { name: '部门类型', id: 105, code: 'deptTypeCode' },
    { name: '工程预立项基本情况', id: 106, code: 'preBaseSituationCode' },
    { name: '排序规则', id: 107, code: 'orderSort' },
    { name: '排序字段', id: 108, code: 'orderBy' },
    { name: '承包商类型', id: 109, code: 'contractorTypeCode' },
    { name: '检查类型', id: 110, code: 'checkTypeCode' },
    { name: '隐患检查类型', id: 111, code: 'safetyCheckTypeCode' },
    { name: '问题类型', id: 112, code: 'problemTypeCode' },
    { name: '问题程度', id: 113, code: 'problemSeverityCode' },
    { name: '隐患状态', id: 114, code: 'hiddenStatusCode' },
    { name: '季度', id: 115, code: 'quarter' },
    { name: '类别', id: 116, code: 'subjectCategoryCode' },
    { name: '分摊指标', id: 117, code: 'shareTargetCode' },
    { name: '成本类型', id: 118, code: 'costTypeCode' },
    { name: '资产类别', id: 119, code: 'companyAssetsCode' },
    { name: '承包方式', id: 120, code: 'contractMethodCode' },
    { name: '招标方式', id: 121, code: 'bidMethodCode' },
    { name: '结构类型', id: 122, code: 'buildTypeCode' },
    { name: '抗震等级', id: 123, code: 'seismicGradeCode' },
    { name: '防火等级', id: 124, code: 'fireRatingCode' },
    { name: '成本版本', id: 125, code: 'costTarget_costTypeCode' }
  ]
};

export default Config;


