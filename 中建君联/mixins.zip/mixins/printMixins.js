/*
 * @Author: your name
 * @Date: 2020-08-24 09:28:25
 * @LastEditTime: 2023-02-24 09:49:16
 * @LastEditors: zengqin 1058574586@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_projectmaterial\src\mixins\printMixins.js
 */

import Sortable from 'sortablejs';// 拖拽排序文件
import i18n from '@/mixins/i18n/index.js';


// 打印模板设计
export const printTemplate = {
  inject: ['reload', 'reloadPage'],
  data () {
    return {
      isPortrait: false, // 默认为纵向打印  false 为横向打印
      typeArr: ['taxRate'],
      mainFormStyle: 'display: flex;flex-wrap: wrap;border: 1px solid rgb(51, 51, 51);overflow: hidden;border-bottom: none !important;',
      mainItemStyle: 'float: left;border-bottom:1px solid rgb(51, 51, 51);border-right:1px solid rgb(51, 51, 51);position: relative;box-sizing: border-box;',
      h4Style: 'color: #ff4a4a;text-align: center;font-size: 18px;',
      h4StylePay: 'color: #ff4a4a;font-size: 18px;display: inline-block;font-weight: bold;',
      h4StylePayTitle: 'color: #ff4a4a;text-align: left;padding-left: 10px;font-size: 18px;font-weight: bold;border-right: 1px solid #000;',
      h3Style: 'width: 33%;text-align: left;font-weight: bold;float: left;text-indent: 10px;position: relative;',
      h3Style1:
        'width: 100%;height: 40px;line-height: 40px;text-align: left;font-weight: bold;float: left;text-indent: 10px;position: relative;vertical-align: middle;',
      h3Style1Transverse:
        `width: 45%;height: 80px;line-height: 80px;text-align: left;
        font-weight: bold;float: left;text-indent: 0;position: relative;vertical-align: middle;display: inline-block`,
      h3Style2: 'width: 100%;text-align: center;font-weight: bold;float: left;text-indent: 10px;position: relative;',
      pStyle: 'font-weight: bold;padding-left: 15px;text-align: left; color: #333333;',
      tableTdStyle: 'padding: 5px 0;text-align: center;word-break: break-all;border: 1px solid #333333;border-collapse:collapse;',
      tableTdStyle1: 'padding: 5px 0;text-align: center;vertical-align: middle;',
      tableConsStyle: 'width: 100%;padding: 0;color: #606266;',
      printContentStyle: 'width: 100%;padding: 0px 1%;margin: 10px 0;border: 1px solid #ebeef5;',
      tablePstyle: 'font-weight: bold;width: 100%;text-indent: 5px;border: 1px solid #333333;border-bottom: 0;',
      customTable1: 'width: 100%;display:inline-block;float: left;border-top: 1px solid #333333;border-bottom: 1px solid #333333;margin-top: -1px;',
      signPicStyle: 'height: 40px;position: absolute;top:5px;vertical-align: middle;',
      processTitleStyle: 'width: 100%;min- height: 30px;',
      processTitlSpanIndexStyle: 'width: 5%;padding: 5px 0;text-align: center;',
      processTitlSpanNameStyle: 'width: 15%;padding: 5px 0;',
      processTitlSpanPersonStyle: 'width: 10%;padding: 5px 0;',
      processTitlSpanSignStyle: 'width: 15%;padding: 5px 0;',
      processTitlSpanTimeStyle: 'width: 15%;padding: 5px 0;',
      processTitlSpanCommentStyle: 'width: 40%;padding: 5px 0;',
      processNodeStyle:
        'width: 100% !important;min-height: 40px;display: flex;align-items: center;display: flex;flex-wrap: wrap;',
      processNodepanIndexStyle: 'width: 5%;padding: 5px 0;text-align: center;line-height: 40px;',
      processNodepanNameStyle: 'width: 15%;padding: 5px 0;line-height: 40px;',
      processNodepanPersonStyle: 'width: 10%;padding: 5px 0;line-height: 40px;',
      processNodepanSignStyle: 'width: 15%;padding: 5px 0;',
      processNodepanSignImgStyle: 'max-width: 150px;max-height: 40px;',
      processNodepanTimeStyle: 'width: 15%;padding: 5px 0;line-height: 40px;',
      processNodepanCommentStyle: 'width: 40%;padding: 5px 0;',
      noBorderStyle: 'border-color: white !important;',
      // noBorderStyle: 'border: none',
      hasBorderStyle: 'border-color: rgb(51, 51, 51); !important;',
      isBoder: 'border-color: rgb(51, 51, 51); !important;',
      lastDate: 'border-bottom-color: rgb(51, 51, 51);',
      borderList: ['01', '02', '03', '04'],
      sortable: null,
      printShow: false,
      logoUrl: require('assets/images/logoHeader.png'),
      logoStyle: 'height: 40px;position: absolute;top: 0px;left: 0px;vertical-align: middle;',
      printForm: {
        columnName: '',
        columnValue: '',
        status: 1,
        flag: true,
        columnCode: '',
        isAdd: 0
      },
      printCloneForm: {},
      rules: {
        columnName: [
          // 表尾字段名称不能为空
          { required: true, message: this.$t('print.tableFooterNotNull'), trigger: 'blur' }
        ]
      },
      printFooterList: [],
      showButtons: false,
      tableList: [],
      currentIndex: '',
      finishListData: false,
      sortListFlag: false,
      imageUrl: this.$utils.config.imageUrl,
      pageConfig: {}, // 页面配置
      filterSubTable: {}, // 子表数据格式化
      approvalRecordShow: true, // 是否显示审批记录
      isPaperNumber: true, // 启用页码
      fontSize: '14', // 字体大小
      isTableShow: true, // 是否打印子表
      printDataInfo: {}
    };
  },
  props: {
    formCode: {
      type: String,
      default: ''
    },
    id: {
      type: String,
      default: 0
    },
    printModelId: {
      default: ''
    },
    taskId: {
      type: String,
      default: 0
    },
    isPrint: {
      type: Boolean,
      default: false
    },
    flowStatus: {
      type: String,
      default: null
    }
  },
  computed: {
    mainDateBorder () {
      return this.borderList.indexOf('01') >= 0 ? this.hasBorderStyle : this.noBorderStyle;
    },
    detailDataBorder () {
      // border-bottom-color: rgb(51, 51, 51);
      return this.borderList.indexOf('02') >= 0 ? 'border-color: rgb(51, 51, 51);' : 'border-color: white;';
    },
    approvalBorder () {
      return this.borderList.indexOf('03') >= 0 ? this.hasBorderStyle : this.noBorderStyle;
    },
    noFooterBorder () {
      if (this.borderList.indexOf('03') >= 0 && this.borderList.indexOf('04') < 0) {
        return 'border-top-color: rgb(51, 51, 51);';
      }
      if (this.borderList.indexOf('04') >= 0) {
        return 'border-color: rgb(51, 51, 51);';
      }
      return 'border-color: white;border-style: initial;';
    },
    tableFooterBorder () {
      return this.borderList.indexOf('04') >= 0 ? 'border-color: rgb(51, 51, 51);' : 'border-color: white;';
    }
  },
  mounted () {
    // this.getFileInfoPublicApi();
    this._getPrintDetail();
  },
  watch: {
    sortListFlag () {
      if (this.DetailList.length === 0 && !this.finishListData && !this.sortListFlag) return;
      this.$nextTick(() => {
        this.setPrintList(this.DetailList);
      });
    },
    finishListData () {
      if (this.DetailList.length === 0 && !this.finishListData && !this.sortListFlag) return;
      this.$nextTick(() => {
        this.setPrintList(this.DetailList);
      });
    },
    DetailList () {
      if (this.DetailList.length === 0 && !this.finishListData && !this.sortListFlag) return;
      this.$nextTick(() => {
        this.setPrintList(this.DetailList);
      });
    },
    // 监听主表数据，审批记录的显示雨隐藏
    printMainList: {
      handler () {
        for (const i in this.printMainList) {
          const item = this.printMainList[i];
          if (item.columnCode === 'approvalRecord') {
            this.approvalRecordShow = item.flag;
          }
        }
      },
      deep: true
    }
  },
  methods: {
    // 点击按钮时判断是否能打印
    handleExcessive (event) {
      // if (!this.LODOP) {
      //   this.LODOP = getLodop();
      // }
      // if (this.LODOP === undefined) {
      //   const arr = [
      //     {
      //       // Web打印服务CLodop未安装启动，点击这里
      //       title: this.$t('print.clodopNotInstalled'),
      //       url: 'https://static.junnysoft.cn/CLodop_Setup_for_Win32NT_https_3.083Extend.zip',
      //       tips: this.$t('print.downloadForInstallation') // '下载执行安装'
      //     },
      //     {
      //       // Web打印服务CLodop需升级!点击这里
      //       title: `${this.$t('print.clodopNotInstalled')}!${this.$t('print.clickHere')}`,
      //       url: 'https://static.junnysoft.cn/CLodop_Setup_for_Win32NT_https_3.083Extend.zip',
      //       tips: this.$t('print.strCLodopInstall_2Tips_2') // '点这里直接再次启动'
      //     }
      //   ];
      //   this.$store.commit('diaLog/SET_PRINT_STR', arr);
      //   return;
      // }
      this.printCloneForm = JSON.parse(JSON.stringify(this.printForm));
      // console.log(this.isBoder, 'isBoder');
      this[event]();
    },
    // 系统字段 自定义字段
    setStatus (val) {
      return val === 0 ? this.$t('print.statusSysTips') : this.$t('print.statusCustomTips');
    },
    // 获取数据
    handleGetInfoData (isPrint, callback) {
      const infoUrl = this.pageConfig.processParmas.infoUrl;
      this.DetailList = [];
      this.setMainConfig();
      if (!isPrint || (this.formCode !== 'inquiryBidReport' && this.formCode !== 'inquireCalibra')) {
        this.setSubTableConfig();
      }
      if (!isPrint) return;
      this.$store.dispatch(infoUrl.url, { [infoUrl.params]: this.id }).then(res => {
        const results = this.$clone(res.results);
        // 变更后的金额大写字段重新赋值
        const formList = this.$clone(this.pageConfig.mainFormConfig.formList);
        for (const item of formList) {
          if (item.filterName === 'amountInWords') {
            this.$set(results, `${item.prop}AmountWords`, results[item.prop]);
          }
        }
        const tendersList = [
          'tendersReview', 'tendersPublish', 'tendersEvaluatePerson', 'tendersRefund',
          'tendersAppeal', 'tendersEvaluate', 'tendersConfirm'
        ];
        // 招标云特例
        if (this.formCode === 'tenders') {
          results.isAppoint = results.isAppoint === 0 ? this.$t('attractTenders.noAppoint') : this.$t('attractTenders.yesAppoint');
        }
        if (tendersList.indexOf(this.formCode) >= 0) {
          this.handleSetForm(results);
        }
        const personnelList = ['personnelRecruitInterviewRecord'];
        // 招标云特例
        if (personnelList.indexOf(this.formCode) >= 0) {
          this.handleSetPersonalForm(results);
        }
        // 人力资源云特例
        if (this.formCode === 'contractExpendRegister' || this.formCode === 'contractExpendSettlement') {
          this.handleRelationTable(results);
        }
        // 资证作废特例
        if (this.formCode === 'personnelCertificaCancel') {
          results.archivesRelations = results.certificaName ? results.certificaName : results.archivesRelations.map(v => v.certificaName).join(',');
        }
        // 人力资源云特例
        if (this.formCode === 'personnelPerformanceAppraisal') {
          this.setApplyPeriod(results);
        }
        if (results.continent) {
          const continent = results.continent && results.continent.split('-')[0];
          const country = results.country && results.country.split('-')[0];
          const province = results.province && results.province.split('-')[0];
          const city = results.city && results.city.split('-')[0];
          const area = results.area && results.area.split('-')[0];
          results.areas = `${continent}${country}${province}${city}${area}`;
        }
        // 招标云地址特例
        if (this.formCode === 'tendersPublish') {
          if (results.continent) {
            const continent = results.continent && results.continent.split('-')[0];
            const country = results.country && results.country.split('-')[0];
            const province = results.province && results.province.split('-')[0];
            const city = results.city && results.city.split('-')[0];
            const area = results.area && results.area.split('-')[0];
            results.subjectAddress = `${continent}${country}${province}${city}${area}`;
          }
          if (results.actualBidContinent) {
            const continent = results.actualBidContinent && results.actualBidContinent.split('-')[0];
            const country = results.actualBidCountry && results.actualBidCountry.split('-')[0];
            const province = results.actualBidProvince && results.actualBidProvince.split('-')[0];
            const city = results.actualBidCity && results.actualBidCity.split('-')[0];
            const area = results.actualBidArea && results.actualBidArea.split('-')[0];
            results.areas = `${continent}${country}${province}${city}${area}`;
          }
        }
        if (this.formCode === 'tendersEvaluatePerson') {
          for (const i in results.tenders) {
            const val = results.tenders[i];
            this.$set(results, `tenders-${i}`, val);
          }
          const tenders = results.tenders;
          const tendersCode = ['actualBidOpeningMethodCode', 'actualBidOpeningTime', 'actualBidOpeningMethodValue',
            'actualBidContinent', 'actualBidCountry', 'actualBidProvince', 'actualBidCity',
            'actualBidArea', 'actualBidAddress', 'bidOpeningMethodDescription'];
          for (const item of tendersCode) {
            this.$set(results, item, tenders[item]);
          }
          const actualBidOpeningMethodCode = results.actualBidOpeningMethodCode;
          if (actualBidOpeningMethodCode === '01') {
            if (results.actualBidContinent) {
              // 获取详细地址
              let address = '';
              if (results.length > 0) {
                const actualBidContinent = results.actualBidContinent && results.actualBidContinent.split('-')[0];
                const actualBidCountry = results.actualBidCountry && results.actualBidCountry.split('-')[0];
                const actualBidProvince = results.actualBidProvince && results.actualBidProvince.split('-')[0];
                const actualBidCity = results.actualBidCity && results.actualBidCity.split('-')[0];
                const actualBidArea = results.actualBidArea && results.actualBidArea.split('-')[0];
                const actualBidAddress = results.actualBidAddress;
                address = `${actualBidContinent}${actualBidCountry}${actualBidProvince}${actualBidCity}${actualBidArea}${actualBidAddress}`;
              }
              this.$set(results, 'customAddress', address);
            }
          } else if (actualBidOpeningMethodCode === '02') {
            this.$set(results, 'customAddress', results.bidOpeningMethodDescription);
          }
        }
        // 寻源询价单内审
        if (this.formCode === 'inquiryBid') {
          if (results.supplyContinent) {
            const continent = results.supplyContinent && results.supplyContinent.split('-')[0];
            const country = results.supplyCountry && results.supplyCountry.split('-')[0];
            const province = results.supplyProvince && results.supplyProvince.split('-')[0];
            const city = results.supplyCity && results.supplyCity.split('-')[0];
            const area = results.supplyArea && results.supplyArea.split('-')[0];
            results.areas = `${continent}${country}${province}${city}${area}`;
          }
        }
        // 询价单内审
        if (this.formCode === 'inquiryBidReport' || this.formCode === 'inquireCalibra') {
          const evaluateUsers = this.$clone(results.evaluateUsers);
          const bidEvaluateUsers = evaluateUsers.length ? evaluateUsers.map(v => v.specialistName).join(', ') : '';
          this.$set(results, 'bidEvaluateUsers', bidEvaluateUsers);
        }
        if (!results.orgName && results.orgId && this.$utils.config.subSystemCode !== 'administrative') {
          this.$store.dispatch('publicApi/getOrginfoPublicApi', { orgId: results.orgId }).then(r => {
            results.printOrgName = r.results.orgName;
            this.setProssList(results);
          });
        } else {
          results.printOrgName = results.orgName;
          this.setProssList(results);
        }
        if (this.pageConfig.subTableMatch) {
          for (const subTable of this.pageConfig.subTableMatch) {
            if (this.formCode === 'inquiryBidReport' || this.formCode === 'inquireCalibra') {
              const obj = {};
              for (const item of results[subTable.value]) {
                item.ifInstallationRequired = item.ifInstallationRequired === 1 ? this.$t('tips.yes') : item.ifInstallationRequired === 0 ? this.$t('tips.no') : '';
                for (const row of item.details) {
                  // 金额
                  this.$set(item, `includeUnitPrice${row.supplierId}`, row.includeUnitPrice);
                  this.$set(item, `includeTaxAmount${row.supplierId}`, row.includeTaxAmount);
                  let amount = obj[`includeTaxAmount${row.supplierId}`] || 0;
                  amount += Number(row.includeTaxAmount);
                  this.$set(obj, `supplierName${row.supplierId}`, row.supplierName);
                  this.$set(obj, `includeTaxAmount${row.supplierId}`, Number(Number(amount).toFixed(2)));
                }
              }
              this.$set(obj, 'materialCode', '合计');
              results[subTable.value].unshift(obj);
              this.DetailList = results[subTable.value];
            } else {
              this.DetailList = results[this.pageConfig.subTableMatch[0].value];
            }
          }
          if (this.formCode === 'inquiryBidReport' || this.formCode === 'inquireCalibra') {
            this.setSubTableConfig();
          }
          // this.DetailList = results[this.pageConfig.subTableMatch[0].value];
        }
        // 获取打印次数
        const data = {
          formCode: this.formCode,
          sid: this.id
        };
        this.$store.dispatch('publicApi/getPrintCountsPublicApi', data).then(res => {
          if (res.status === 0) {
            results.printTimes = (res.results || 0) + 1;
            this.setProssList(results);
          }
        });
        this.dataInfo = results;
        callback && callback();
      });
    },
    // 资审结果通知设置值
    handleSetForm (results) {
      for (const i in results.tenders) {
        const val = results.tenders[i];
        this.$set(results, `tenders-${i}`, val);
      }
      if (this.formCode !== 'tendersReview') return;
      const isSelectedList = [
        { dataCode: '1', dataName: '已入围' },
        { dataCode: '0', dataName: '未入围' }
      ];
      for (const item of results.details) {
        const index = isSelectedList.findIndex(v => Number(v.dataCode) === item.isSelected);
        item.isSelected = index >= 0 ? isSelectedList[index].dataName : item.isSelected;
      }
      // console.log(results, 'results');
    },
    // 面试记录设置
    handleSetPersonalForm (results) {
      const details = results.details[0];
      for (const i in details) {
        const val = details[i];
        this.$set(results, i, val);
      }
      // console.log(results, 'results');
    },
    // 切换合同类型
    handleRelationTable (results) {
      const contractClassifyCode = results.contractClassifyCode;
      this.contractClassifyCode = contractClassifyCode || 'tableList';
      let code = '';
      if (this.formCode === 'contractExpendRegister') {
        code = 'contractExpendRegisterDetail';
      } else if (this.formCode === 'contractExpendSettlement') {
        code = 'contractExpendSettlementDetail';
      }
      const tableObjList = this.pageConfig.subTableConfig[code][this.contractClassifyCode];
      this.$set(this.pageConfig.subTableConfig[code], 'tableList', this.$clone(tableObjList));
      this.setSubTableConfig();
    },
    // 设置期别
    setApplyPeriod (results) {
      if (results.applyPeriod && results.appraisalTypeCode === '02') {
        const selectList = [
          { dataName: '第一季度', dataCode: '01' },
          { dataName: '第二季度', dataCode: '02' },
          { dataName: '第三季度', dataCode: '03' },
          { dataName: '第四季度', dataCode: '04' }
        ];
        const li = results.applyPeriod.substring(4, 6);
        const index = selectList.findIndex(v => v.dataCode === li);
        let pe = '';
        if (index > -1) {
          pe = selectList[index].dataName;
        }
        // console.log(pe);
        results.applyPeriod = `${results.applyPeriod.substring(0, 4)}/ ${pe}`;
      }
    },
    // 设置主表配置数据
    setMainConfig () {
      const processList = [];
      // console.log(this.pageConfig, 'this.pageConfig');
      const formList = this.$clone(this.pageConfig.mainFormConfig.formList);
      formList.unshift({
        // 打印次数
        label: 'print.printTimes', prop: 'printTimes', span: 8, formType: 'input', inputStatus: 'disable',
        printWidth: 8, printFlag: false, defaultFlag: false, printStatus: 0
      });
      formList.forEach((item, index) => {
        if (item.prop === 'isSignContract') {
          // console.log(item, ' itemisSignContract');
        }
        // if (item.prop === 'applyPeriod') {
        //   console.log(item, ' applyPeriod');
        // }
        if (item.formType !== 'upload' && item.formType !== 'downloadTemplate') {
          const flag = item.formType !== 'divisionTitle' && item.formType !== 'title';
          // 金额大写字段变更
          if (item.filterName === 'amountInWords') {
            item.prop = `${item.prop}AmountWords`;
          }
          processList.push(
            {
              id: index,
              flag: item.printFlag || (item.defaultFlag === false ? false : flag),
              defaultFlag: item.defaultFlag,
              columnName: this.$t(item.label),
              columnCode: item.pintIdName ? item.pintIdName : (item.printProp || item.prop),
              columnValue: `<${this.$t(item.label)}>`,
              status: item.printStatus,
              width: item.printWidth || 8,
              oldWidth: item.printWidth || 8,
              printValue: item.printValue,
              relationList: item.relationList,
              formType: item.formType,
              nameCode: item.nameCode || '',
              valueCode: item.valueCode || '',
              propStart: item.propStart || '',
              propEnd: item.propEnd || '',
              selectList: item.selectList || [],
              isTranslate: item.isTranslate || false,
              multiple: item.multiple || false,
              filterName: item.pintIdName ? '' : (item.formType === 'dicSelect' && item.prop.toLowerCase().indexOf('taxrate') !== -1) ? 'taxRate' : item.filterName ? item.filterName : item.formType
            }
          );
        }
      });
      this.processList = processList;
      if (this.$utils.config.subSystemCode !== 'administrative' && this.formCode !== 'receiptTracking') {
        this.processList.unshift({
          columnCode: 'printOrgName',
          columnName: this.$t('dialog.orgName'),
          columnValue: `<${this.$t('dialog.orgName')}>`,
          defaultFlag: true,
          filterName: 'text',
          flag: true,
          id: -1,
          oldWidth: 24,
          printValue: undefined,
          status: 0,
          width: 24
        });
      }
    },
    // 设置子表配置数据
    setSubTableConfig () {
      if (this.isPrint && (this.formCode === 'inquiryBidReport' || this.formCode === 'inquireCalibra')) {
        this.setTransSourcingRegisterPrintConfig();
      } else {
        const list = [];
        this.pageConfig.subTableMatch && this.pageConfig.subTableMatch.forEach((item, index) => {
          if (index > 0) return;
          const subTable = this.pageConfig.subTableConfig[item.assignment];
          subTable.tableList.slaveColumns.forEach((item, index) => {
            if (item.formType !== 'attachment' && item.formType !== 'downloadTemplate') {
              const filterName = (item.formType === 'dicSelect' && item.prop.toLowerCase().indexOf('taxrate') !== -1)
                ? 'taxRate' : item.formType === 'text' ? item.filterName : item.filterName ? item.filterName : item.formType;
              list.push(
                {
                  id: index,
                  flag: item.printFlag || (item.printFlag !== false ? true : item.printFlag),
                  defaultFlag: item.defaultFlag,
                  columnName: this.$t(item.label),
                  columnCode: item.pintIdName ? item.pintIdName : (item.printProp || item.prop),
                  columnValue: `<${this.$t(item.label)}>`,
                  status: item.printStatus,
                  width: item.printWidth || 5,
                  oldWidth: item.printWidth || 5,
                  printValue: item.printValue,
                  relationList: item.relationList,
                  formType: item.formType,
                  nameCode: item.nameCode || '',
                  valueCode: item.valueCode || '',
                  selectList: item.selectList || [],
                  isTranslate: item.isTranslate || false,
                  filterName: item.pintIdName ? '' : filterName
                }
              );
              // console.log(list, 'list');
            }
          });
        });
        this.list = list;
      }
    },
    setTransSourcingRegisterPrintConfig () {
      const customList = {
        firstHead: [],
        twoHead: []
      };
      const firstHead = [];
      const colspan = 2;
      const obj = this.$clone(this.DetailList[0]);
      const amount = [];
      for (const i in obj) {
        const str = i.replace('includeTaxAmount', '');
        Number(str) && amount.push({ amount: obj[`includeTaxAmount${str}`], supplierId: Number(str), supplierName: obj[`supplierName${str}`] });
      }
      const list = amount.sort((a, b) => {
        return a.amount - b.amount;
      }).splice(0, 3);

      if (list.length) {
        for (const i in list) {
          const item = list[i];
          firstHead.push(
            {
              label: `${item.supplierName}`, prop: `supplierName${item.supplierId}`, formType: 'text',
              colspan, rowspan: 1,
              printWidth: 8, printFlag: true, defaultFlag: true, printStatus: 0
            }
          );
        }
      }
      this.pageConfig.subTableMatch && this.pageConfig.subTableMatch.forEach(item => {
        const subTable = this.pageConfig.subTableConfig[item.assignment];
        const slaveColumns = this.$clone(subTable.tableList.slaveColumns);
        const childrenSlaveColumns = this.$clone(subTable.tableList.childrenSlaveColumns);
        const slaveColumnsData = slaveColumns.concat(firstHead);
        slaveColumnsData.forEach((item, index) => {
          if (item.formType !== 'attachment' && item.formType !== 'downloadTemplate') {
            const filterName =
              (item.formType === 'dicSelect' && item.prop.toLowerCase().indexOf('taxrate') !== -1)
                ? 'taxRate' : item.formType === 'dicSelect' ? 'text' : item.formType === 'text' ? item.filterName : item.formType || '';
            customList.firstHead.push(
              {
                id: index,
                flag: item.printFlag || (item.printFlag !== false ? true : item.printFlag),
                defaultFlag: item.defaultFlag,
                columnName: this.$t(item.label),
                columnCode: item.pintIdName ? item.pintIdName : item.prop,
                columnValue: `<${this.$t(item.label)}>`,
                status: item.printStatus,
                width: item.printWidth,
                oldWidth: item.printWidth,
                printValue: item.printValue,
                relationList: item.relationList,
                filterName,
                colspan: item.colspan || 1,
                rowspan: item.rowspan || 2
              }
            );
          }
        });
        if (list.length) {
          for (const i in list) {
            const row = list[i];
            for (const j in childrenSlaveColumns) {
              const child = childrenSlaveColumns[j];
              if (item.formType !== 'attachment' && item.formType !== 'downloadTemplate') {
                const filterName =
                  (item.formType === 'dicSelect' && item.prop.toLowerCase().indexOf('taxrate') !== -1)
                    ? 'taxRate' : item.formType === 'dicSelect' ? 'text' : item.formType === 'text' ? item.filterName : item.formType || '';
                customList.twoHead.push(
                  {
                    id: Number(j),
                    flag: child.printFlag || (child.printFlag !== false ? true : child.printFlag),
                    defaultFlag: child.defaultFlag,
                    columnName: this.$t(child.label),
                    columnCode: child.pintIdName ? child.pintIdName : `${child.prop}${row.supplierId}`,
                    columnValue: `<${this.$t(child.label)}>`,
                    status: child.printStatus,
                    width: child.printWidth,
                    oldWidth: child.printWidth,
                    printValue: child.printValue,
                    relationList: child.relationList,
                    filterName,
                    colspan: child.colspan || 1
                  }
                );
              }
            }
          }
        }
      });
      this.customList = customList;
      this.setPrintList(this.DetailList);
    },
    // 获取表单字段
    _getPrintDetail () {
      if (this.formCode === 'receiptTracking') {
        // 盖章
        this.printFooterList = [
          // '购方(盖章)'
          {
            flag: true,
            columnName: this.$t('receiptTracking.purchaserSeal'),
            columnValue: ''
          },
          // '供方(盖章)'
          {
            flag: true,
            columnName: this.$t('receiptTracking.supplierSeal'),
            columnValue: ''
          }
        ];
        this.borderList = ['01', '02'];
        this.isPortraitArray = false;
      }
      const taskId = this.taskId > 0 ? this.taskId : 0;
      this.showButtons = true;
      if (taskId) {
        this.$store.dispatch('processApi/getTasksQueryLogs', { taskId }).then(data => {
          this.printBottomList = this.setCodeList(data.results);
          this.$store.dispatch('publicApi/getTenantPrintModelInfo', { printModelId: this.printModelId }).then(res => {
            this._getPrintSort();
            if (!res.results || !res.results.details) return;
            this.printDataInfo = res.results;
            const results = res.results.details;
            for (const i in results) {
              const item = results[i];
              if (item.isAdd === 0) {
                item.flag = item.isShow === 0;
                item.columnValue = item.columnDefaultValue || '';
                this.printFooterList.push(item);
              }
            }
            this.setIsShowList(results, this.printMainList, 'title');
            this.setIsShowList(results, this.processList, 'head');
            this.setIsShowList(results, this.printFooterList, 'foot');
            if (this.isPrint && (this.formCode === 'inquiryBidReport' || this.formCode === 'inquireCalibra')) {
              this.setIsShowList(results, this.customList.firstHead, 'body');
              this.setIsShowList(results, this.customList.twoHead, 'body');
            } else {
              this.setIsShowList(results, this.list, 'body');
            }
            this.finishListData = true;
          });
        });
      } else {
        this.$store.dispatch('printApi/getPrintFoot', { printModelCode: this.formCode }).then(data => {
          this.printBottomList = this.setCodeList(data.results);
          this.$store.dispatch('publicApi/getTenantPrintModelInfo', { printModelId: this.printModelId }).then(res => {
            this._getPrintSort();
            if (!res.results || !res.results.details) return;
            this.printDataInfo = res.results;
            const results = res.results.details;
            for (const i in results) {
              const item = results[i];
              if (item.isAdd === 0) {
                item.flag = item.isShow === 0;
                item.columnValue = item.columnDefaultValue || '';
                this.printFooterList.push(item);
              }
            }
            this.setIsShowList(results, this.printMainList, 'title');
            this.setIsShowList(results, this.list, 'body');
            this.setIsShowList(results, this.processList, 'head');
            this.setIsShowList(results, this.printFooterList, 'foot');
            this.finishListData = true;
          });
        });
      }
    },
    getFileInfoPublicApi () {
      this.$store.dispatch('publicApi/getOrganizationCompanyInfoPublicApi').then(companyInfo => {
        if (companyInfo.status === 0) {
          if (!companyInfo.results.attachLogo) {
            this.logoUrl = '';
            return;
          }
          this.$store.dispatch('publicApi/getFileInfoPublicApi', { fileId: companyInfo.results.attachLogo }).then(res => {
            if (res.status === 0) {
              this.logoUrl = `${this.$utils.config.imageUrl}${res.results.filePath}`;
            }
          });
        }
      });
    },
    // 获取字段排序
    _getPrintSort () {
      this.$store.dispatch('printApi/getPrintSort', { printModelId: this.printModelId }).then(res => {
        this.showButtons = true;
        if (res.results.length) {
          const results = res.results.filter(v => v.printModelCode === this.formCode);
          this.setSortList(results, this.list, 'body');
          this.setSortList(results, this.processList, 'head');
          this.setSortList(results, this.printFooterList, 'foot');
          if (this.processList.length > 13 && this.isPrint) {
            this.processList.splice(13, 0, {pageBreakAfter: true, sort: this.processList[12].sort + 1});
          }
        }
        this.sortListFlag = true;
        if (this.isPrint) return;
        this.handleSortTable();
      });
    },
    // 拖拽排序
    handleSortTable () {
      this.$nextTick(() => {
        this.setSort('printHeadTable', 'processList');
        this.setSort('printListTable', 'list');
        this.setSort('printBottomTable', 'printBottomList');
        this.setSort('printFooterTable', 'printFooterList');
      });
    },
    setSort (className, getArr) {
      const el = document.querySelectorAll(`.${className}>.el-table__body-wrapper > table > tbody`)[0];
      if (!el) return;
      this.sortable = Sortable.create(el, {
        ghostClass: 'sortable-ghost', // Class name for the drop placeholder,
        setData (dataTransfer) {
          dataTransfer.setData('Text', '');
        },
        onEnd: evt => {
          const targetRow = this[getArr].splice(evt.oldIndex, 1)[0];
          this[getArr].splice(evt.newIndex, 0, targetRow);
        }
      });
    },
    // 获取表尾字段数据
    setCodeList (arr) {
      const data = [];
      for (const i in arr) {
        const item = arr[i];
        if (item.nodeName !== '结束') {
          item.flag = true;
          item.columnCode = item.processNodeCode;
          item.columnName = item.nodeName;
          item.columnValue = item.assigneeName;
          item.comment = item.comment;
          item.url = '';
          item.status = 0;
          item.isAdd = 1;
          data.push(item);
        }
      }
      return data;
    },
    // 是否显示还是隐藏
    setIsShowList (arr, setArr, part) {
      const list = arr.filter(v => v.printModelPartCode === part);
      for (const i in setArr) {
        const item = setArr[i];
        const index = list.findIndex(v => v.columnCode === item.columnCode);
        if (index >= 0) {
          item.flag = list[index].isShow === 0;
          item.width = list[index].width;
          if (part === 'title') {
            item.columnValue = list[index].columnDefaultValue;
            if (item.columnCode === 'approvalRecord') {
              this.approvalRecordShow = item.flag;
            }
          }
        }
      }
    },
    // 自定义合并行
    customListColspan (customList) {
      const firstHead = customList.firstHead.filter(v => v.flag);
      return firstHead.length + customList.twoHead.length + 1;
    },
    // 排序
    setSortList (arr, setArr, part) {
      const list = arr.filter(v => v.printModelPartCode === part);
      for (const i in setArr) {
        for (const i in setArr) {
          const item = setArr[i];
          const index = list.findIndex(v => v.columnCode === item.columnCode);
          if (index >= 0) {
            item.sort = list[index].sort;
          }
        }
      }
      setArr = setArr.sort(this.compare);
    },
    // 排序 比较大小
    compare (obj1, obj2) {
      const val1 = obj1.sort || 0;
      const val2 = obj2.sort || 0;
      if (val1 > val2) {
        return 1;
      } else if (val1 < val2) {
        return -1;
      } else {
        return 0;
      }
    },
    // 点击换行
    handleChangeRole (row) {
      this.currentIndex = row.columnCode;
    },
    tableRowClassName ({ row, rowIndex }) {
      if (row.columnCode === this.currentIndex) {
        return 'active';
      } else {
        return '';
      }
    },
    // 模板删除表尾节点
    handleDelete () {
      if (!this.currentIndex) {
        // 请选择你要删除的数据
        this.$message({
          message: this.$t('print.pleaseSelectDeleteData'),
          type: 'error'
        });
        return;
      }
      const index = this.printFooterList.findIndex(v => v.columnCode === this.currentIndex);
      if (this.printFooterList[index].isAdd === 1) {
        // 系统字段不能删除
        this.$message({
          message: this.$t('print.sysNoDalete'),
          type: 'error'
        });
        return;
      }
      // 您确定删除 该自定义字段吗
      this.$confirm(`${this.$t('print.areYouSureToDelete')}${this.printFooterList[index].columnName}${this.$t('print.customFields')}`, {
        cancelButtonClass: 'button-close',
        distinguishCancelAndClose: true,
        confirmButtonText: this.$t('button.determine'),
        cancelButtonText: this.$t('button.close')
      }).then(() => {
        this.printFooterList.splice(index, 1);
      });
    },
    // 添加表尾节点
    submitLoginPass (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.isDisable = true; // 开始可以点击
          this.printForm.columnCode = `P${(new Date()).getTime()}`;
          this.printFooterList.push(this.printForm);
          this.exitProcessForm();
        }
      });
    },
    exitProcessForm () {
      this.isDisable = false; // 执行请求后就能再次点击了
      this.printShow = false;
      this.printForm = JSON.parse(JSON.stringify(this.printCloneForm));
    },
    // 信息保存
    PersonFormSave () {
      const printModelSortCreateDtos = [];
      const printModelDetailShowCreateDtos = [];
      this.saveDataArr(this.printMainList, printModelSortCreateDtos, printModelDetailShowCreateDtos, 'title');
      this.saveDataArr(this.list, printModelSortCreateDtos, printModelDetailShowCreateDtos, 'body');
      this.saveDataArr(this.processList, printModelSortCreateDtos, printModelDetailShowCreateDtos, 'head');
      for (const i in this.printFooterList) {
        const item = this.printFooterList[i];
        printModelSortCreateDtos.push({
          printColumnCode: item.columnCode,
          sortPart: 'foot',
          columnCode: item.columnCode,
          columnName: item.columnName,
          columnValue: item.columnValue,
          width: item.width,
          isAdd: 0,
          isShow: item.flag ? 0 : 1
        });
        printModelDetailShowCreateDtos.push({
          columnCode: item.columnCode,
          columnName: item.columnName,
          columnValue: item.columnValue,
          columnDefaultValue: item.columnValue,
          width: item.width,
          isAdd: 0,
          isShow: item.flag ? 0 : 1
        });
      }
      this.saveDataArr(this.printFooterList, printModelSortCreateDtos, printModelDetailShowCreateDtos, 'body');
      const createPrintInfo = JSON.parse(localStorage.getItem('createPrintInfo'));
      if (this.printDataInfo && this.printDataInfo.details) {
        for (const item of printModelDetailShowCreateDtos) {
          const index = this.printDataInfo.details.findIndex(v => `${v.columnCode}-${v.printModelPartCode || ''}` === `${item.columnCode}-${item.sortPart || ''}`);
          if (index >= 0) {
            this.$set(item, 'id', this.printDataInfo.details[index].id);
          }
        }
      }
      if (this.printDataInfo && this.printDataInfo.sorts) {
        for (const item of printModelSortCreateDtos) {
          const index = this.printDataInfo.sorts.findIndex(v => `${v.columnCode}-${v.printModelPartCode || ''}` === `${item.printColumnCode}-${item.sortPart || ''}`);
          if (index >= 0) {
            this.$set(item, 'id', this.printDataInfo.sorts[index].id);
          }
        }
      }
      const data = {
        id: createPrintInfo.id,
        printModelCode: createPrintInfo.printModelCode,
        printModelName: createPrintInfo.printModelName,
        subSystemCode: createPrintInfo.subSystemCode,
        subSystemName: createPrintInfo.subSystemName,
        organizations: createPrintInfo.organizations,
        printModelDetailShowCreateDtos,
        printModelSortCreateDtos
      };
      this.$store.dispatch('printApi/createPrint', data).then(res => {
        if (res.status === 0) {
          // 打印模板配置保存成功
          this.$message({
            message: this.$t('print.printTempSaveSuccess'),
            type: 'success'
          });
          this.setRoute();
        }
      });
    },
    saveDataArr (arr, getArr1, getArr2, sortPart) {
      for (const i in arr) {
        const item = arr[i];
        getArr1.push({
          printColumnCode: item.columnCode,
          width: item.width,
          sortPart
        });
        if (sortPart === 'title') {
          getArr2.push({
            columnCode: item.columnCode,
            columnName: item.columnName,
            columnValue: item.columnValue,
            isAdd: 1,
            width: item.width,
            isShow: item.flag ? 0 : 1,
            sortPart
          });
        } else if (!item.flag || !item.defaultFlag || item.oldWidth !== item.width) {
          getArr2.push({
            columnCode: item.columnCode,
            columnName: '',
            columnValue: '',
            isAdd: 1,
            width: item.width,
            isShow: item.flag ? 0 : 1,
            sortPart
          });
        }
      }
    },
    // 恢复默认
    handlePrintReset () {
      this.$store.dispatch('printApi/resetPrint', { printModelId: this.printModelId }).then(res => {
        if (res.status === 0) {
          this.reload();
        }
      });
    },
    // 处理表头数据
    setProssList (res) {
      for (const i in this.processList) {
        const item = this.processList[i];
        if (item.filterName === 'dicSelect') {
          if (item.relationList && item.relationList.length) {
            const printKey = item.relationList[0].receive;
            item.columnValue = res[printKey] !== null ? res[printKey] : '';
          } else {
            item.columnValue = res[item.columnCode] !== null ? res[item.columnCode] : '';
          }
        } else if (item.filterName === 'whether') {
          const val = res[item.columnCode];
          item.columnValue = val && Number(val) === 1 ? i18n.t('tips.yes') : i18n.t('tips.no');
        } if (item.filterName === 'sex') {
          const val = res[item.columnCode];
          item.columnValue = val && Number(val) === 0 ? i18n.t('fConfig.man') : i18n.t('fConfig.female');
        } else if (item.filterName === 'otherSelect') {
          const val = res[item.columnCode];
          const selectList = this.pageConfig[`${item.columnCode}List`] || item.selectList;
          if (item.formType === 'dicSelect') {
            // eslint-disable-next-line eqeqeq
            const index = selectList.findIndex(v => v.dataCode == val);
            const value = index >= 0 ? selectList[index].dataName : val;
            item.columnValue = item.isTranslate ? this.$t(value) : value;
          } else if (item.formType === 'select') {
            if (item.multiple) {
              // eslint-disable-next-line eqeqeq
              const index = selectList.findIndex(v => v[item.valueCode] == val);
              const value = index >= 0 ? selectList[index][item.nameCode] : val;
              const columnValue = value.map(v => v[item.nameCode]).join(', ');
              item.columnValue = columnValue;
            } else {
              // eslint-disable-next-line eqeqeq
              const index = selectList.findIndex(v => v[item.valueCode] == val);
              const value = index >= 0 ? selectList[index][item.nameCode] : val;
              item.columnValue = item.isTranslate ? this.$t(value) : value;
            }
          } else if (item.formType === 'radio') {
            // eslint-disable-next-line eqeqeq
            const index = selectList.findIndex(v => v.value == val);
            const value = index >= 0 ? selectList[index].label : val;
            item.columnValue = item.isTranslate ? this.$t(value) : value;
          } else {
            item.columnValue = val;
          }
        } else if (item.filterName === 'daterange') {
          const propStart = res[item.propStart];
          const propEnd = res[item.propEnd];
          item.columnValue = [propStart, propEnd].join('-');
        } else {
          item.columnValue = res[item.columnCode] !== null ? res[item.columnCode] : '';
        }
      }
    },
    // 处理明细数据
    setPrintList (arr) {
      if (this.isPrint && (this.formCode === 'inquiryBidReport' || this.formCode === 'inquireCalibra')) {
        this.setTransSourcingRegisterPrintList(arr);
      } else {
        const tendersList = [
          'labourWorkSchedule', 'labourCultivate', 'labourWorkerLeave', 'labourSettlement'
        ]; // 劳务云特例
        if (tendersList.indexOf(this.formCode) >= 0) {
          arr = this.handleSetLabourList(arr);
        }
        const prolabourList = ['labourBudget'];
        // 劳务策划
        if (this.formCode === 'labourBudget') {
          for (const item of arr) {
            if (item.sourceType === '01') {
              item.sourceType = '';
            } else if (item.sourceType === '02') {
              item.sourceType = '目标成本分解';
            } else if (item.sourceType === '03') {
              item.sourceType = '施工签证';
            }
          }
        }
        this.filterSubTable = {};
        const tableData = [];
        for (const j in arr) {
          const child = arr[j];
          const obj = {};
          for (const i in this.list) {
            const item = this.list[i];
            for (const subObj in item) {
              this.filterSubTable[item.columnCode] = item.filterName;
            }
            if (item.flag && obj[item.columnCode] !== false) {
              if (item.filterName === 'dicSelect') {
                if (item.relationList && item.relationList.length) {
                  const printKey = item.relationList[0].receive;
                  obj[item.columnValue] = child[printKey] !== null ? child[printKey] : '';
                } else {
                  obj[item.columnCode] = child[item.columnCode] !== null ? child[item.columnCode] : '';
                }
              } else if (item.filterName === 'whether') {
                const val = child[item.columnCode];
                obj[item.columnCode] = val && Number(val) === 1 ? i18n.t('tips.yes') : i18n.t('tips.no');
              } else if (item.filterName === 'otherSelect') {
                const val = child[item.columnCode];
                const selectList = this.pageConfig[`${item.columnCode}List`] || item.selectList;
                if (item.formType === 'dicSelect') {
                  // eslint-disable-next-line eqeqeq
                  const index = selectList.findIndex(v => v.dataCode == val);
                  const value = index >= 0 ? selectList[index].dataName : val;
                  this.$set(obj, 'columnValue', item.isTranslate ? this.$t(value) : value);
                } else if (item.formType === 'select') {
                  // eslint-disable-next-line eqeqeq
                  const index = selectList.findIndex(v => v[item.valueCode] == val);
                  const value = index >= 0 ? selectList[index][item.nameCode] : val;
                  this.$set(obj, 'columnValue', item.isTranslate ? this.$t(value) : value);
                } else {
                  obj.columnValue = val;
                }
              } else {
                obj[item.columnCode] = child[item.columnCode] !== null ? child[item.columnCode] : '';
              }
            }
          }
          tableData.push(obj);
        }
        this.tableList = tableData;
      }
    },
    setTransSourcingRegisterPrintList (arr) {
      this.filterSubTable = {};
      if (!this.customList.firstHead) return;
      this.tfootColspan = this.customList.firstHead.length + (this.customList.twoHead ? this.customList.twoHead.length : 0);
      let firstHead = [];
      if (this.formCode === 'inquiryBidReport' || this.formCode === 'inquireCalibra') {
        // firstHead = this.$clone(this.customList.firstHead).splice(0, 1);
        firstHead = this.$clone(this.customList.firstHead);
      }
      const customList = firstHead.concat(this.customList.twoHead);
      const tableData = [];
      for (const j in arr) {
        const child = arr[j];
        const obj = {};
        for (const i in customList) {
          const item = customList[i];
          for (const subObj in item) {
            this.filterSubTable[item.columnCode] = item.filterName;
          }
          if (item.flag && obj[item.columnCode] !== false && item.columnCode.indexOf('supplierName') < 0) {
            if (item.filterName === 'dicSelect') {
              if (item.relationList && item.relationList.length) {
                const printKey = item.relationList[0].receive;
                obj[item.columnValue] = child[printKey] !== null ? child[printKey] : '';
              } else {
                obj[item.columnCode] = child[item.columnCode] !== null ? child[item.columnCode] : '';
              }
            } else {
              obj[item.columnCode] = child[item.columnCode] !== null ? child[item.columnCode] : '';
            }
          }
        }
        tableData.push(obj);
      }
      this.tableList = tableData;
    },
    // 劳务云特例
    handleSetLabourList (arr) {
      const data = [];
      for (const item of arr) {
        let v = this.$clone(item);
        if (item.worker) {
          v.workId = v.worker.id;
          delete v.worker;
          v.isEdit = true;
          v = {
            ...item.worker,
            ...v
          };
        }
        data.push(v);
      }
      return data;
    },
    // 金钱千分位
    KilobitConversion (num) {
      if (!num) return num;
      if (typeof num === 'number') {
        const c = num.toFixed(2).toString().replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
        return c;
      } else {
        const b = num.toFixed(2).toString().replace(/\.$/, '');
        return b;
      }
    },

    //  打印
    async handlePrintPreview () {
      const ids = this.id.split(',');
      let flags = true;
      if (ids && ids.length > 1) {
        for (const item of ids) {
          if (item) {
            const data = {
              formCode: this.formCode,
              sid: item,
              tenantId: this.$utils.Auth.hasUserInfo().tenantId,
              createBy: this.$utils.Auth.hasUserInfo().userId,
              createByName: this.$utils.Auth.hasUserInfo().userName,
              createTime: this.$utils.commonUtil.formatTime(new Date())
            };
            // eslint-disable-next-line no-loop-func
            await this.$store.dispatch('publicApi/setPrintCountsPublicApi', data).then(res => {
              if (res.status === 0) {
                if (!res.results) {
                  flags = false;
                }
              }
            });
          }
        }
        if (flags) {
          this.PrintSetting();
        }
      } else {
        const data = {
          formCode: this.formCode,
          sid: this.id,
          tenantId: this.$utils.Auth.hasUserInfo().tenantId,
          createBy: this.$utils.Auth.hasUserInfo().userId,
          createByName: this.$utils.Auth.hasUserInfo().userName,
          createTime: this.$utils.commonUtil.formatTime(new Date())
        };
        this.$store.dispatch('publicApi/setPrintCountsPublicApi', data).then(res => {
          if (res.status === 0) {
            this.PrintSetting();
          }
        });
      }
    },
    // 打印预览
    handlePrintDesign () {
      this.PrintSetting();
      // this.LODOP.PRINT_DESIGN();
      // this.LODOP.PREVIEW();
    },
    getApprovalSignature () {
      if (this.taskId === 'null') {
        // 该数据还没有进行流程审批，获取审批签名为空
        this.$message({
          message: this.$t('print.noProcessApproval'),
          type: 'error'
        });
        return;
      }
      const columnCode = this.printBottomList.map(item => item.columnCode);
      const data = {
        columnCode,
        taskId: this.taskId
      };
      // 批量获取文件路径
      this.$store.dispatch('printApi/getPrintFootAssignees', data).then(res => {
        if (res.results.length === 0) return;
        // 已获取审批签名
        this.$message.success(this.$t('print.approvalSignatureObtained'));
        for (const i in this.printBottomList) {
          const item = this.printBottomList[i];
          const index = res.results.findIndex(v => v.columnCode === item.columnCode);
          if (index >= 0) {
            // item.columnValue = res.results[index].columnValue;
            item.signPic = res.results[index].signPic;
            // item.comment = res.results[index].comment;
            // item.executeDate = res.results[index].executeDate;
            if (item.signPic) {
              this.$set(item, 'url', '');
              item.signPic && this.$store.dispatch('publicApi/getFileInfo', { fileId: item.signPic }).then(r => {
                this.$set(item, 'url', this.imageUrl + r.results.filePath);
              });
            }
          }
        }
        this.$nextTick(() => {
          this.$forceUpdate();
        });
      });
    },
    // // 打印配置
    // PrintSetting() {
    //   const print = this.$refs.table;
    //   const cons = this.$refs.cons;
    //   const consHeight = cons.offsetHeight;
    //   // 打印控件功能演示_Lodop功能_预览打印表格
    //   this.LODOP.PRINT_INIT(this.$t('print.functionDemonstration'));
    //   this.LODOP.SET_PRINT_PAGESIZE(2, 0, 0, 'A4');
    //   this.LODOP.ADD_PRINT_HTM('2%', '2%', '96%', '96%', cons.innerHTML);
    //   this.LODOP.ADD_PRINT_TABLE(`${consHeight + 40}px`, '2%', '96%', '96%', print.innerHTML);
    //   this.LODOP.SET_PRINT_STYLEA(2, 'Offset2Top', `${-consHeight + 20}px`);
    // }
    // 打印配置
    PrintSetting (type) {
      // eslint-disable-next-line no-undef
      const hiprintTemplate = new hiprint.PrintTemplate({
        // template: customPrintJson,
        settingContainer: '#app',
        paginationContainer: '.hiprint-printPagination'
      });
      const head = this.$refs['print-head'];
      const table = this.$refs.table;
      const cons = this.$refs.cons;
      const consHeight = cons.offsetHeight;

      const isPortrait = this.isPortrait;
      // 纵向
      const portraitConfig = {
        width: 210,
        height: 297,
        paperFooter: 750,
        paperHeader: 10,
        paperType: 'A4',
        topOffset: 20,
        // paperNumberDisabled: !this.isPaperNumber,
        paperNumberLeft: 280, // 页码 放入中减
        paperNumberTop: 800 // 页码 放入中减
      };
      // 横向
      const transverseConfig = {
        width: 297,
        height: 210,
        paperFooter: 540,
        paperHeader: 10,
        paperType: 'A4',
        topOffset: 20,
        rotate: true,
        // paperNumberDisabled: !this.isPaperNumber,
        paperNumberLeft: 400, // 页码 放入中减
        paperNumberTop: 550 // 页码 放入中减
      };
      const config = isPortrait ? portraitConfig : transverseConfig; // 默认为纵向
      const consWidth = isPortrait ? 500 : 720;
      const left = isPortrait ? 46 : 50;
      const panel = hiprintTemplate.addPrintPanel(
        {
          ...config
        }
      );
      panel.addPrintHtml({
        options: {
          width: consWidth + 10,
          height: 35,
          top: 10,
          'left': left,
          content: head.innerHTML
        }
      });
      panel.addPrintTable({
        options: {
          width: consWidth + 10,
          height: 38,
          top: this.list.length ? 65 : 45,
          'left': left,
          'textAlign': 'center',
          content: cons.innerHTML
        }
      });
      panel.addPrintTable({
        options: {
          'left': left,
          'top': 38 + (this.list.length ? 65 : 45),
          'height': 38,
          'width': consWidth + 10,
          'textAlign': 'center',
          'content': table.innerHTML
        }
      });
      if (type === 'downloadPdf') {
        const loading = this.getLoading(this.$t('print.downloadPdf'));
        const translateName = this.formCode === 'receiptTracking' ? this.$t('print.receiptTracking') : this.$t(`menu.${this.$route.params.translateName}`);
        const dataCode = this.dataInfo[this.dataCode] || translateName;
        hiprintTemplate.toPdf(panel, `${dataCode}.pdf`, { scale: 2 }, () => {
          loading.close();
          this.$message.success(`${this.$t('print.downloadPdf')} ${this.$t('tips.success')}!`);
        });
      } else if (type === 'uploadPdf') {
        this.uploadPdf(hiprintTemplate, panel);
      } else {
        hiprintTemplate.print();
        hiprintTemplate.clear();
      }
    },
    // 下载pdf
    handleDownloadPdf () {
      this.PrintSetting('downloadPdf');
    },
    // 上传pdf
    handleUploadPdf () {
      this.PrintSetting('uploadPdf');
    },
    // 上传pdf
    uploadPdf (hiprintTemplate, panel) {
      const loading = this.getLoading(this.$t('print.uploadPdf'));
      const dataCode = this.dataInfo[this.dataCode];
      hiprintTemplate.toPdfTest(panel, dataCode, { scale: 2 }, (blob) => {
        // 创建formData对象
        const formData = new FormData();
        const blobBin = blob;
        formData.append('file', blobBin);
        const menuId = this.$utils.menu.getMenuId(this.$route.params.translateName);
        if (menuId) {
          formData.append('fileName', `${dataCode}.pdf`);
          formData.append('menuId', menuId);
          formData.append('formCode', this.formCode);
          formData.append('recordId', this.id);
          formData.append('subSystemCode', this.$utils.config.subSystemCode);
        } else {
          // 当前打印页面存在配置错误，请联系管理员；
          this.$message.error(this.$t('print.'));
          return;
        }
        this.$store.dispatch('publicApi/tenantPdfUploadPublicApi', formData).then(res => {
          if (res.status === 1) {
            this.$message.error(this.$t(`exception.${res.errorCode}`));
          } else {
            this.$message.success(`${this.$t('print.uploadPdf')} ${this.$t('tips.success')}!`);
          }
          loading.close();
        }).catch(e => {
          loading.close();
        });
      });
    }
  }
};
