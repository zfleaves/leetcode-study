/*
 * @Author: your name
 * @Date: 2020-07-24 18:12:37
 * @LastEditTime: 2023-02-23 10:24:00
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_contract-合同管理\src\views\task\contract.js
 */
import config from 'util/config';

export default {
    // ----------- 出入库管理 ---------------------
    // 材料入库
    warIncoming: {
        printConfigUrl: 'generalWarehouseManagement/warManagement/warIncoming/configEdit.js',
        translateName: 'warIncoming'
    },
    // 材料出库
    warOutbound: {
        printConfigUrl: 'generalWarehouseManagement/warManagement/warOutbound/configEdit.js',
        translateName: 'warOutbound'
    },
    // 领料退回
    warReturn: {
        printConfigUrl: 'generalWarehouseManagement/warManagement/warReturn/configEdit.js',
        translateName: 'warReturn'
    },
    // 材料退货
    warReturngoods: {
        printConfigUrl: 'generalWarehouseManagement/warManagement/warReturngoods/configEdit.js',
        translateName: 'warReturngoods'
    },
    // 材料报损
    warReportloss: {
        printConfigUrl: 'generalWarehouseManagement/warManagement/warReportloss/configEdit.js',
        translateName: 'warReportloss'
    },
    // 盘点
    warInventory: {
        printConfigUrl: 'generalWarehouseManagement/warManagement/warInventory/configEdit.js',
        translateName: 'warInventory'
    },
    // 项目材料成本核算
    warProjectCostAccount: {
        printConfigUrl: 'generalWarehouseManagement/warehouseStatistics/costAccountingSheet/configEdit.js',
        translateName: 'costAccountingSheet'
    },

    // ----------- 加工管理 ---------------------
    // BOM设置
    proBom: {
        printConfigUrl: 'processManagement/BOMSet/configEdit.js',
        translateName: 'BOMSet'
    },
     // 加工任务下达
    proTaskRelease: {
        printConfigUrl: 'processManagement/taskRelease/configEdit.js',
        translateName: 'taskRelease'
    },
    // 加工任务完成上报
    proTaskFinished: {
        printConfigUrl: 'processManagement/taskFinished/configEdit.js',
        translateName: 'taskFinished'
    },
    // 加工任务发货
    proDeliverGoods: {
        printConfigUrl: 'processManagement/deliverGoods/configEdit.js',
        translateName: 'deliverGoods'
    },
    // 项目加工核算单
    proProjectAccount: {
        printConfigUrl: 'processManagement/processingAccountingDocument/configEdit.js',
        translateName: 'processingAccountingDocument'
    },
    // ------------------------- 周转料租赁管理 ------------------------
    // 需求申请
    purDemandPlan: {
        printConfigUrl: 'promaterial/purDemandPlan/configEdit.js',
        translateName: 'purDemandPlan'
    },
    // 采购方案报审
    purSchemeApproval: {
        printConfigUrl: 'promaterial/promaterialPurchaseApply/configEdit.js',
        translateName: 'promaterialPurchaseApply'
    },

    // 采购合同结算
    purSettlement: {
        printConfigUrl: 'promaterial/purchaseSettlement/configEdit.js',
        translateName: 'purchaseSettlement'
    },
    // 采购合同支付
    purPaymentApply: {
        printConfigUrl: 'promaterial/paymentApply/configEdit.js',
        translateName: 'paymentApply'
    },

    // 退货登记
    purReturngoods: {
        printConfigUrl: 'promaterial/purReturngoods/configEdit.js',
        translateName: 'purReturngoods'
    },

    // 零星采购申请
    purSporadicPurchase: {
        printConfigUrl: 'promaterial/sporadicPurchase/configEdit.js',
        translateName: 'sporadicPurchase'
    },
    // 零星采购报销
    purSporadicReimburse: {
        printConfigUrl: 'promaterial/sporadicReimburse/configEdit.js',
        translateName: 'sporadicReimburse'
    },
    // -------------------------机械设备登记 ------------------------
    // 机械设备登记
    machApproach: {
        printConfigUrl: 'MechanicalEquipmentSupply/machApproach/configEdit.js',
        translateName: 'machApproach'
    },

    // 机械设备出场
    machExit: {
        printConfigUrl: 'MechanicalEquipmentSupply/machExit/configEdit.js',
        translateName: 'machExit'
    },

    // 机械设备返场
    machReturn: {
        printConfigUrl: 'MechanicalEquipmentSupply/machReturn/configEdit.js',
        translateName: 'machReturn'
    },

    // 机械设备保养
    machMaintain: {
        printConfigUrl: 'MechanicalEquipmentSupply/machMaintain/configEdit.js',
        translateName: 'machMaintain'
    },

    // 机械设备维修
    machRepair: {
        printConfigUrl: 'MechanicalEquipmentSupply/machRepair/configEdit.js',
        translateName: 'machRepair'
    },
    // 机械成本核算
    machProjectAccount: {
        printConfigUrl: 'MechanicalEquipmentSupply/machProjectAccount/configEdit.js',
        translateName: 'machProjectAccount'
    }
};
