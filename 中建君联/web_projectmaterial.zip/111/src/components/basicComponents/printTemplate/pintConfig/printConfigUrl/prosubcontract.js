/*
 * @Author: your name
 * @Date: 2021-08-31 13:47:09
 * @LastEditTime: 2022-06-08 11:06:17
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_projectsubcontract-项目分包云\src\components\basicComponents\printTemplate\pintConfig\printConfigUrl\prosubcontract.js
 */
export default {
    // 分包执行策划
    scMasterPlan: {
        printConfigUrl: 'prosubcontract/scMasterPlan/configEdit.js',
        translateName: 'scMasterPlan'
    },
    // 实施申请
    scImplementApply: {
        printConfigUrl: 'prosubcontract/scImplementApply/configEdit.js',
        translateName: 'scImplementApply'
    },
    // 分包计划
    scSubcontract: {
        printConfigUrl: 'prosubcontract/scSubcontract/configEdit.js',
        translateName: 'scSubcontract'
    },
    // 进度填报
    scSchedule: {
        printConfigUrl: 'prosubcontract/scSchedule/configEdit.js',
        translateName: 'scSchedule'
    },
    // 违规管理
    scViolations: {
        printConfigUrl: 'prosubcontract/scViolations/configEdit.js',
        translateName: 'scViolations'
    },
    // 竣工验收
    scAcceptance: {
        printConfigUrl: 'prosubcontract/scAcceptance/configEdit.js',
        translateName: 'scAcceptance'
    },
    // 分包结算
    scSettlement: {
        printConfigUrl: 'prosubcontract/scSettlement/configEdit.js',
        translateName: 'scSettlement'
    },
    // 分包报销
    scSubcontractReimburse: { // labourWorkScheduleDetail
        printConfigUrl: 'prosubcontract/scReimburse/configEdit.js',
        translateName: 'scReimburse'
    },
    // 分包支付
    scPayment: {
        printConfigUrl: 'prosubcontract/scPayment/configEdit.js',
        translateName: 'scPayment'
    }
};
