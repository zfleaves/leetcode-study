/*
 * @Author: your name
 * @Date: 2020-08-25 11:58:42
 * @LastEditTime: 2022-12-02 14:11:43
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_projectmachinery\src\components\basicComponents\printTemplate\pintConfig\printConfigUrl.js
 */
// 项目材料管理
import promaterial from './printConfigUrl/promaterial';
// 机械租赁
import promachinery from './printConfigUrl/promachinery';
// 机械租赁
import protmaterials from './printConfigUrl/protmaterials';
// 综合
import proover from './printConfigUrl/proover';
// 行政
import administrative from './printConfigUrl/administrative';
// 合同
import contract from './printConfigUrl/contract';
// 招标云
import tenders from './printConfigUrl/tenders';
// 人力云
import personnel from './printConfigUrl/personnel';
// 投标云
import bid from './printConfigUrl/bid';
// 询价云
import inquire from './printConfigUrl/inquire';
// 劳务云
import prolabour from './printConfigUrl/prolabour';
// 分包云
import prosubcontract from './printConfigUrl/prosubcontract';
// 资产云
import assets from './printConfigUrl/assets';
// 资金云
import capital from './printConfigUrl/capital';
// 过程云
import proprocess from './printConfigUrl/proprocess';
// 供应中心
import supply from './printConfigUrl/supply';
// 成本云
import procost from './printConfigUrl/procost';

export default {
    // ----------- 项目材料管理 -promaterial ---------------------
    ...promaterial,
    // ----------- 机械租赁 -promachinery ---------------------
    ...promachinery,
    // ----------- 周转材 -protmaterials ---------------------
    ...protmaterials,
    // ----------- 综合云 -----------
    ...proover,
    // ----------- 行政 -----------
    ...administrative,
    // ----------- 合同 -----------
    ...contract,
    // ----------- 招标云 -----------
    ...tenders,
    // ----------- 人力云 -----------
    ...personnel,
    // ----------- 投标云 -----------
    ...bid,
    // ----------- 询价云 -----------
    ...inquire,
    // ----------- 询价云 -----------
    ...prolabour,
    // ----------- 劳务云 -----------
    ...prosubcontract,
    // ----------- 资产云 -----------
    ...assets,
    // ------------ 资金云 ----------
    ...capital,
    // ------------ 过程云 ----------
    ...proprocess,
    // ------------ 供应中心 ----------
    ...supply,
    // ------------ 成本云 ----------
    ...procost
};
