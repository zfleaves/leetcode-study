/*
 * @Author: your name
 * @Date: 2021-08-30 15:38:19
 * @LastEditTime: 2023-02-09 16:17:25
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_bid-投标云\src\components\basicComponents\printTemplate\pintConfig\printConfigUrl\bid.js
 */
export default {
    // 投标项目登记
    bidRegister: {
        printConfigUrl: 'biddingManagement/biddingProjectRegistration/configEdit.js',
        translateName: 'biddingProjectRegistration'
    },
    // 投标费用缴纳
    bidCostPay: {
        printConfigUrl: 'biddingManagement/biddingPayment/configEdit.js',
        translateName: 'biddingPayment'
    },
    // 投标费用退回
    bidReturn: {
        printConfigUrl: 'biddingManagement/biddingReturn/configEdit.js',
        translateName: 'biddingReturn'
    },
    // 投标文件编制
    bidFile: {
        printConfigUrl: 'biddingManagement/biddingDocuments/configEdit.js',
        translateName: 'biddingDocuments'
    },
    // 项目开标情况
    bidOpen: {
        printConfigUrl: 'biddingManagement/projectBidOpening/configEdit.js',
        translateName: 'projectBidOpening'
    },
    // 投标资料移交
    bidTransfer: {
        printConfigUrl: 'biddingManagement/tenderDataTransfer/configEdit.js',
        translateName: 'tenderDataTransfer'
    },
    // 新开工联系单
    bidStartWork: {
        printConfigUrl: 'biddingManagement/newConstructionContact/configEdit.js',
        translateName: 'newConstructionContact'
    },
    // 商机登记报审
    customerBusinessRegister: {
        printConfigUrl: 'opportunityManagement/customersBusinessRegister/configEdit.js',
        translateName: 'customersBusinessRegister'
    }
};
