/*
 * @Author: your name
 * @Date: 2021-08-23 11:00:59
 * @LastEditTime: 2021-08-24 13:59:56
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web_tenders-施工云招标管理前端\src\components\basicComponents\printTemplate\pintConfig\printConfigUrl\tenders.js
 */
export default {
    //  ----------- 招标云 -tenders ---------------------
    // 招标立项
    tBiddingInitiation: {
        printConfigUrl: 'biddingInitiation/configEdit.js',
        translateName: 'biddingInitiation'
    },
    // 招标内容与清单
    tenders: {
        printConfigUrl: 'appointTenders/attractTenders/configEdit.js',
        translateName: 'attractTenders'
    },
    // 资审结果通知
    tendersReview: {
        printConfigUrl: 'appointTenders/reviewTenders/configEdit.js',
        translateName: 'reviewTenders'
    },
    // 发标
    tendersPublish: {
        printConfigUrl: 'sendTenders/publishTenders/configEdit.js',
        translateName: 'publishTenders'
    },
    // 设置评标人
    tendersEvaluatePerson: {
        printConfigUrl: 'assessTenders/evaluateTenders/configEdit.js',
        translateName: 'evaluateTenders'
    },
    // 定标报告
    tendersEvaluate: {
        printConfigUrl: 'decideTenders/confirmTenders/configEdit.js',
        translateName: 'confirmTenders'
    },
    // 定标结果
    tendersConfirm: {
        printConfigUrl: 'decideTenders/resultTenders/configEdit.js',
        translateName: 'resultTenders'
    },
    // 退款查看及办理
    tendersRefund: {
        printConfigUrl: 'cashTenders/refundTenders/configEdit.js',
        translateName: 'refundTenders'
    },
    // 申诉
    tendersAppeal: {
        printConfigUrl: 'cashTenders/appealTenders/configEdit.js',
        translateName: 'appealTenders'
    },
    // 线下定标报告
    tCalibra: {
        printConfigUrl: 'offlineBiddingRegistration/calibrationRegistration/configEdit.js',
        translateName: 'calibrationRegistration'
    },
    // 线下定标结果
    tWin: {
        printConfigUrl: 'offlineBiddingRegistration/calibrationResults/configEdit.js',
        translateName: 'calibrationResults'
    }
};
