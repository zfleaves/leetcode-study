/*
 * @Author: your name
 * @Date: 2021-07-02 17:04:02
 * @LastEditTime: 2022-08-19 13:45:26
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_projectmaterial\src\components\basicComponents\printTemplate\pintConfig\printConfigUrl\proover.js
 */
export default {
    // 其他策划
    otherMasterPlan: {
        printConfigUrl: 'projectover/otherMasterPlan/configEdit.js',
        translateName: 'otherMasterPlan'
    },
    // 直接策划
    otherMasterPlanOther: {
        printConfigUrl: 'projectover/otherMasterPlanOther/configEdit.js',
        translateName: 'otherMasterPlanOther'
    },
    // 其他合同支付
    oPayment: {
        printConfigUrl: 'projectover/otherContractPay/configEdit.js',
        translateName: 'otherContractPay'
    },
    // 其他合同结算
    oContractSettlement: {
        printConfigUrl: 'projectover/otherContractSettlement/configEdit.js',
        translateName: 'otherContractSettlement'
    },
    // 其他费用结算
    oOtherSettlement: {
        printConfigUrl: 'projectover/otherCostSettlement/configEdit.js',
        translateName: 'otherCostSettlement'
    },
    // 其他费用报销
    otherCostReimburse: {
        printConfigUrl: 'projectover/otherCostReimburse/configEdit.js',
        translateName: 'otherCostReimburse'
    },
    // 其他费用报销
    oReimburse: {
        printConfigUrl: 'projectover/otherCostReimburse/configEdit.js',
        translateName: 'otherCostReimburse'
    },
    // 备用金申请
    oFundApply: {
        printConfigUrl: 'projectover/fundApply/configEdit.js',
        translateName: 'fundApply'
    },
    // 备用金报销抵扣
    oFundReimburse: {
        printConfigUrl: 'projectover/fundReimburse/configEdit.js',
        translateName: 'fundReimburse'
    },
    // 直接报销
    oReimburseOther: {
        printConfigUrl: 'otherDirectFeeManagement/otherCostReimburseDirectFree/configEdit.js',
        translateName: 'otherCostReimburseDirectFree'
    },
    // 其他直接费申请
    directExpensesApply: {
        printConfigUrl: 'otherDirectFeeManagement/directExpensesApply/configEdit.js',
        translateName: 'directExpensesApply'
    },
    // 合同支付
    oPaymentOther: {
        printConfigUrl: 'otherDirectFeeManagement/otherContractPayDirectFree/configEdit.js',
        translateName: 'otherContractPayDirectFree'
    },
    // 合同结算
    oContractSettlementOther: {
        printConfigUrl: 'otherDirectFeeManagement/otherContractSettlementDirectFree/configEdit.js',
        translateName: 'otherContractSettlementDirectFree'
    }
};
