/*
 * @Author: your name
 * @Date: 2021-08-30 16:53:34
 * @LastEditTime: 2022-07-14 11:06:33
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_inquire-询价管理\src\components\basicComponents\printTemplate\pintConfig\printConfigUrl\inquire.js
 */
export default {
    // 询价内容
    inquiryBid: {
        printConfigUrl: 'inquiry/inquiryContent/configEdit.js',
        translateName: 'inquiryContent'
    },
    // 定标报告
    inquiryBidReport: {
        printConfigUrl: 'inquiry/biddingConfirm/configPrint.js',
        translateName: 'biddingConfirm'
    },
    // 定标结果
    inquiryBidResult: {
        printConfigUrl: 'inquiry/report/configEdit.js',
        translateName: 'report'
    },
    // 询价记录/物资表
    inquireMaterial: {
        printConfigUrl: 'offLineInquiryManagement/inquiryRecordAndMaterialList/configEdit.js',
        translateName: 'inquiryRecordAndMaterialList'
    },
    // 询价记录/供应商表
    inquireVendor: {
        printConfigUrl: 'offLineInquiryManagement/inquiryRecordSupplierList/configEdit.js',
        translateName: 'inquiryRecordSupplierList'
    },
    // 询价定标登记
    inquireCalibra: {
        printConfigUrl: 'offLineInquiryManagement/inquiryAndCalibrationRegistration/configPrint.js',
        translateName: 'inquiryAndCalibrationRegistration'
    },
    // 询价定标结果
    inquireWin: {
        printConfigUrl: 'offLineInquiryManagement/inquiryAndCalibrationResults/configEdit.js',
        translateName: 'inquiryAndCalibrationResults'
    }
};
