/*
 * @Author: your name
 * @Date: 2021-08-30 10:36:20
 * @LastEditTime: 2021-08-30 10:43:59
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web_personnel-人力资源云\src\components\basicComponents\printTemplate\pintConfig\printConfigUrl\personnel.js
 */
export default {
    // 年度招聘计划
    personnelRecruitYearPlan: {
        printConfigUrl: 'recruit/recruitYearPlan/configEdit.js',
        translateName: 'recruitYearPlan'
    },
    // 招聘管理临时招聘计划
    personnelRecruitTempPlan: {
        printConfigUrl: 'recruit/recruitTempPlan/configEdit.js',
        translateName: 'recruitTempPlan'
    },
    // 招聘管理面试信息
    personnelRecruitInterviewRecord: {
        printConfigUrl: 'recruit/recruitInterviewRecord/configEdit.js',
        translateName: 'recruitInterviewRecord'
    },
    // 人事管理录用审批
    personnelEmployRegister: {
        printConfigUrl: 'personnelManagement/employmentApproval/configEdit.js',
        translateName: 'employmentApproval'
    },
    // 人事管理入职登记
    personnelEntryRegister: {
        printConfigUrl: 'personnelManagement/personnelEntryRegister/configEdit.js',
        translateName: 'personnelEntryRegister'
    },
    // 人事管理合同签订
    personnelContract: {
        printConfigUrl: 'personnelManagement/personnelContract/configEdit.js',
        translateName: 'personnelContract'
    },
    // 人事管理合同解除
    personnelContractRelieve: {
        printConfigUrl: 'personnelManagement/personnelContractRelieve/configEdit.js',
        translateName: 'personnelContractRelieve'
    },
    // 人事管理转正申请
    personnelRegular: {
        printConfigUrl: 'personnelManagement/personnelRegular/configEdit.js',
        translateName: 'personnelRegular'
    },
    // 人事管理离职申请
    personnelQuit: {
        printConfigUrl: 'personnelManagement/personnelQuit/configEdit.js',
        translateName: 'personnelQuit'
    },
    // 人事管理调岗申请
    personnelPositionAdjust: {
        printConfigUrl: 'personnelManagement/personnelPositionAdjust/configEdit.js',
        translateName: 'personnelPositionAdjust'
    },
    // 薪资登记
    personnelSalaryRegister: {
        printConfigUrl: 'personnelManagement/salaryRegistration/configEdit.js',
        translateName: 'salaryRegistration'
    },
    // 人员资证资证登记
    personnelCertificaRegister: {
        printConfigUrl: 'certifica/certificaRegister/configEdit.js',
        translateName: 'certificaRegister'
    },
    // 人员资证资证借用
    personnelCertificaUse: {
        printConfigUrl: 'certifica/certificaUse/configEdit.js',
        translateName: 'certificaUse'
    },
    // 人员资证资证归还
    personnelCertificaReturn: {
        printConfigUrl: 'certifica/certificaReturn/configEdit.js',
        translateName: 'certificaReturn'
    },
    // 人员资证资证年审
    personnelCertificaAnnual: {
        printConfigUrl: 'certifica/certificaAnnual/configEdit.js',
        translateName: 'certificaAnnual'
    },
    // 人员资证资证作废
    personnelCertificaCancel: {
        printConfigUrl: 'certifica/certificaCancel/configEdit.js',
        translateName: 'certificaCancel'
    },
    // 培训管理培训计划
    personnelTrainPlan: {
        printConfigUrl: 'train/trainPlan/configEdit.js',
        translateName: 'trainPlan'
    },
    // 培训管理培训记录
    personnelTrainRecord: {
        printConfigUrl: 'train/trainRecord/configEdit.js',
        translateName: 'trainRecord'
    },
    // 培训管理培训反馈
    personnelTrainFeedback: {
        printConfigUrl: 'train/trainFeedback/configEdit.js',
        translateName: 'trainFeedback'
    },
    // 补卡申请
    personnelReplenishCardApply: {
        printConfigUrl: 'attendanceManagement/cardReplenishmentApplication/configEdit.js',
        translateName: 'cardReplenishmentApplication'
    },
    // 请假申请
    personnelVacationApply: {
        printConfigUrl: 'attendanceManagement/leaveApplication/configEdit.js',
        translateName: 'leaveApplication'
    },
    // 绩效考核
    personnelPerformanceAppraisal: {
        printConfigUrl: 'personnelManagement/performanceAppraisal/configEdit.js',
        translateName: 'performanceAppraisal'
    },
    // 社保公积金
    personnelSocialInsurance: {
        printConfigUrl: 'personnelManagement/securityAndProvidentApplication/configEdit.js',
        translateName: 'securityAndProvidentApplication'
    },
    // 工作日志
    personnelWorkLog: {
        printConfigUrl: 'dailyReportManagement/dailyReportSummary/configEdit.js',
        translateName: 'dailyReportSummary'
    }
};
