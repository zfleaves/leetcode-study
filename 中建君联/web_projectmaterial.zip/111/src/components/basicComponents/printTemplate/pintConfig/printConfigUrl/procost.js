/*
 * @Author: wumaoxia 1805428335@qq.com
 * @Date: 2022-12-02 14:09:56
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @LastEditTime: 2023-01-06 10:41:15
 * @FilePath: \web_projectcost\src\components\basicComponents\printTemplate\pintConfig\printConfigUrl\procost.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
export default {
    // 认质认价表
    enterpriseIdentifyPrice: {
        printConfigUrl: 'enterpriseQuotaManagement/enterpriseIdentifyPrice/configEdit.js',
        translateName: 'enterpriseIdentifyPrice'
    },
    // 待分摊费管理
    shareCostManage: {
        printConfigUrl: 'costSharManagement/costShareManager/configEdit.js',
        translateName: 'costShareManager'
    },
    // 管理费分摊
    shareCostExecute: {
        printConfigUrl: 'costSharManagement/costShareExecute/configEdit.js',
        translateName: 'costShareExecute'
    },
    // 其他直接费分摊
    oContractShare: {
        printConfigUrl: 'costSharManagement/otherContractShare/configEdit.js',
        translateName: 'otherContractShare'
    }
};
