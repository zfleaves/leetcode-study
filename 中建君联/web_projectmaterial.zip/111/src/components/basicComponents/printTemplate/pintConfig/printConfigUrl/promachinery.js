/*
 * @Author: your name
 * @Date: 2020-08-28 16:45:04
 * @LastEditTime: 2021-08-31 11:07:08
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web_projectmachinery\src\components\basicComponents\printTemplate\pintConfig\printConfigUrl\promachinery.js
 */
export default {
    //  ----------- 项目材料管理 -promachinery ---------------------
    //  ----------- 材料 ---------------------
    // 施工总预算
    zlDemandMasterPlan: {
        printConfigUrl: 'demandPlan/masterPlan/configEdit.js',
        translateName: 'masterPlan'
    },
    // 调整
    zlDemandMasterPlanAdjust: {
        printConfigUrl: 'demandPlan/masterPlanAdjust/configEdit.js',
        translateName: 'masterPlanAdjust'
    },
    // 月
    zlDemandMonthPlan: {
        printConfigUrl: 'demandPlan/monthPlan/configEdit.js',
        translateName: 'monthPlan'
    },
    // 临时
    zlDemandTempPlan: {
        printConfigUrl: 'demandPlan/tempPlan/configEdit.js',
        translateName: 'tempPlan'
    },
    // 周
    zlDemandWeekPlan: {
        printConfigUrl: 'demandPlan/weekPlan/configEdit.js',
        translateName: 'weekPlan'
    },
    // ----------- 机械管理 ---------------------
    // 租赁申请
    machineryLeaseApply: {
        printConfigUrl: 'promachinery/promachineryPurchaseApply/configEdit.js',
        translateName: 'promachineryPurchaseApply'
    },
    // 临时租赁
    machineryTempLease: {
        printConfigUrl: 'promachinery/sporadicPurchase/configEdit.js',
        translateName: 'sporadicPurchase'
    },
    // 合同结算
    machineryLeaseSettlement: {
        printConfigUrl: 'promachinery/purchaseSettlement/configEdit.js',
        translateName: 'purchaseSettlement'
    },
    // 付款申请
    machineryLeasePayment: {
        printConfigUrl: 'promachinery/paymentApply/configEdit.js',
        translateName: 'paymentApply'
    },
    // 零星采购报销
    machineryLeaseReimburse: {
        printConfigUrl: 'promachinery/sporadicReimburse/configEdit.js',
        translateName: 'sporadicReimburse'
    },
    // ----------- 现场机械管理 ---------------------
    // 进场
    machineryApproachApply: {
        printConfigUrl: 'fieldMachinery/approach/configEdit.js',
        translateName: 'approach'
    },
    // 安装验收
    machineryInstallAccepter: {
        printConfigUrl: 'fieldMachinery/installation/configEdit.js',
        translateName: 'installation'
    },
    // 维修
    machineryMaintenance: {
        printConfigUrl: 'fieldMachinery/repair/configEdit.js',
        translateName: 'repair'
    },
    // 保养
    machineryMaintain: {
        printConfigUrl: 'fieldMachinery/maintain/configEdit.js',
        translateName: 'maintain'
    },
    // 退场
    machineryExitApply: {
        printConfigUrl: 'fieldMachinery/exit/configEdit.js',
        translateName: 'exit'
    },
    // 运行登记
    machineryRunningRegister: {
        printConfigUrl: 'siteManagement/runningRegister/configEdit.js',
        translateName: 'runningRegister'
    },
    // 特种作业人员
    specialOperatorsRegister: {
        printConfigUrl: 'siteManagement/specialOperatorsRegister/configEdit.js',
        translateName: 'specialOperatorsRegister'
    },
    // 过程资料登记
    machineryProcessFiles: {
        printConfigUrl: 'siteManagement/processfiles/configEdit.js',
        translateName: 'processfiles'
    },
    // ----------- 分包方机械管理 ---------------------
    // 进场
    subcontractMachineryEnter: {
        printConfigUrl: 'subcontractorMachinery/mechanicalApproach/configEdit.js',
        translateName: 'mechanicalApproach'
    },
    // 退场
    subcontractMachineryExit: {
        printConfigUrl: 'subcontractorMachinery/mechanicalExits/configEdit.js',
        translateName: 'mechanicalExits'
    }
};
