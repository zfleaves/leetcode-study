/*
 * @Author: your name
 * @Date: 2021-08-31 16:40:14
 * @LastEditTime: 2021-08-31 16:47:42
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web_assets-资产云\src\components\basicComponents\printTemplate\pintConfig\printConfigUrl\assets.js
 */
export default {
    // 固定资产年度预算上报
    asBudget: {
        printConfigUrl: 'budgetManagement/annualBudgetReport/configEdit.js',
        translateName: 'annualBudgetReport'
    },
    // 固定资产年度预算调整
    asBudgetChange: {
        printConfigUrl: 'budgetManagement/annualBudgetAdjustment/configEdit.js',
        translateName: 'annualBudgetAdjustment'
    },
    // 固定资产年度预算汇总报批
    asBudgetSummary: {
        printConfigUrl: 'budgetManagement/annualBudgetSummary/configEdit.js',
        translateName: 'annualBudgetSummary'
    },
    // 固定资产购置申请
    asPurchase: {
        printConfigUrl: 'purchaseApplication/purchaseApplication/configEdit.js',
        translateName: 'purchaseApplication'
    },
    // 固定资产设备安装
    asPurchaseInstall: {
        printConfigUrl: 'purchasingManagement/equipmentInstallation/configEdit.js',
        translateName: 'equipmentInstallation'
    },
    // 固定资产采购付款
    asPurchasePayment: {
        printConfigUrl: 'purchasingManagement/contractPayment/configEdit.js',
        translateName: 'contractPayment'
    },
    // 固定资产零星采购
    asPurchaseSporadic: {
        printConfigUrl: 'purchasingManagement/sporadicPurchase/configEdit.js',
        translateName: 'sporadicPurchase'
    },
    // 固定资产零星采购报销
    asPurchaseSporadicReimburse: {
        printConfigUrl: 'purchasingManagement/sporadicReimbursement/configEdit.js',
        translateName: 'sporadicReimbursement'
    },
    // 固定资产到货验收
    asPurchaseArrival: {
        printConfigUrl: 'purchasingManagement/arrivalAcceptance/configEdit.js',
        translateName: 'arrivalAcceptance'
    },
    // 固定资产采购结算
    asPurchaseSettlement: {
        printConfigUrl: 'purchasingManagement/contractSettlement/configEdit.js',
        translateName: 'contractSettlement'
    },
    // 固定资产资产登记
    asManageIncrease: {
        printConfigUrl: 'assetGrowth/newlyPurchasedAssets/configEdit.js',
        translateName: 'newlyPurchasedAssets'
    },
    // 固定资产其他来源资产登记
    asManageIncreaseTarget: {
        printConfigUrl: 'assetGrowth/otherSourceAssets/configEdit.js',
        translateName: 'otherSourceAssets'
    },
    // 固定资产资产领用
    asManageReceive: {
        printConfigUrl: 'assetsUse/assetCollection/configEdit.js',
        translateName: 'assetCollection'
    },
    // 固定资产资产领用退回
    asManageReturned: {
        printConfigUrl: 'assetsUse/assetCollectionReturn/configEdit.js',
        translateName: 'assetCollectionReturn'
    },
    // 固定资产资产借用
    asManageBorrow: {
        printConfigUrl: 'assetsUse/assetBorrowing/configEdit.js',
        translateName: 'assetBorrowing'
    },
    // 固定资产资产归还
    asManageBack: {
        printConfigUrl: 'assetsUse/assetsReturn/configEdit.js',
        translateName: 'assetsReturn'
    },
    // 固定资产资产调出
    asManageTransferOut: {
        printConfigUrl: 'assetsUse/assetTransferOut/configEdit.js',
        translateName: 'assetTransferOut'
    },
    // 固定资产资产调入
    asManageTransferIn: {
        printConfigUrl: 'assetsUse/assetsTransferIn/configEdit.js',
        translateName: 'assetsTransferIn'
    },
    // 	固定资产维保变更
    asMaintenanceChange: {
        printConfigUrl: 'assetMaintenanceVerification/assetMaintenanceChange/configEdit.js',
        translateName: 'assetMaintenanceChange'
    },
    // 	固定资产维修
    asMaintenanceRepair: {
        printConfigUrl: 'assetMaintenanceVerification/assetRepair/configEdit.js',
        translateName: 'assetRepair'
    },
    // 	固定资产保养
    asMaintenanceMaintain: {
        printConfigUrl: 'assetMaintenanceVerification/assetMaintenance/configEdit.js',
        translateName: 'assetMaintenance'
    },
    // 	固定资产检定校准
    asMaintenanceCalibration: {
        printConfigUrl: 'assetMaintenanceVerification/assetVerification/configEdit.js',
        translateName: 'assetVerification'
    },
    // 	固定维保报销
    asMaintenanceReimburse: {
        printConfigUrl: 'assetMaintenanceVerification/assetExpenseReimbursement/configEdit.js',
        translateName: 'assetExpenseReimbursement'
    },
    // 固定资产常规资产盘点
    asManageInventory: {
        printConfigUrl: 'assetsInventory/assetsInventoryRelease/configEdit.js',
        translateName: 'assetsInventoryRelease'
    },
    // 固定资产特种资产盘点
    asManageInventorySpecial: {
        printConfigUrl: 'assetsInventory/assetSpecialInventory/configEdit.js',
        translateName: 'assetSpecialInventory'
    },
    // 固定资产盘点复核
    asManageInventoryReview: {
        printConfigUrl: 'assetsInventory/assetReviewReport/configEdit.js',
        translateName: 'assetReviewReport'
    },
    // 	固定资产使用信息变更
    asManageUseChange: {
        printConfigUrl: 'assetsChange/assetInfoChange/configEdit.js',
        translateName: 'assetInfoChange'
    },
    // 	固定资产财务信息变更
    asManageFinanceChange: {
        printConfigUrl: 'assetsChange/assetFinanceInfoChange/configEdit.js',
        translateName: 'assetFinanceInfoChange'
    },
    // 固定资产报废
    asManageScrap: {
        printConfigUrl: 'assetsDecrease/assetRetirement/configEdit.js',
        translateName: 'assetRetirement'
    },
    // 固定资产损毁
    asManageDamage: {
        printConfigUrl: 'assetsDecrease/assetDamage/configEdit.js',
        translateName: 'assetDamage'
    },
    // 固定资产处置
    asManageDispose: {
        printConfigUrl: 'assetsDecrease/assetDisposal/configEdit.js',
        translateName: 'assetDisposal'
    },
    // 固定资产转让
    asManageTransfer: {
        printConfigUrl: 'assetsDecrease/assetTransfer/configEdit.js',
        translateName: 'assetTransfer'
    }
};
