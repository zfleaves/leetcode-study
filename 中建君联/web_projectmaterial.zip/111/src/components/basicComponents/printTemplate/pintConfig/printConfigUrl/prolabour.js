/*
 * @Author: your name
 * @Date: 2021-08-31 14:22:36
 * @LastEditTime: 2021-12-03 10:36:08
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web_projectlabour-项目劳务\src\components\basicComponents\printTemplate\pintConfig\printConfigUrl\prolabour.js
 */
export default {
    // 人工预算清单
    labourBudget: {
        printConfigUrl: 'projectlabour/labourBudget/configEdit.js',
        translateName: 'labourBudget'
    },
    // 人工预算清单变更
    labourBudgetChange: {
        printConfigUrl: 'projectlabour/labourBudgetChange/configEdit.js',
        translateName: 'labourBudgetChange'
    },
    // 用工计划
    labourWorkerPlan: {
        printConfigUrl: 'projectlabour/labourWorkerPlan/configEdit.js',
        translateName: 'labourWorkerPlan'
    },
    // 用工申请
    labourWorkerApply: {
        printConfigUrl: 'projectlabour/labourWorkerApply/configEdit.js',
        translateName: 'labourWorkerApply'
    },
    // 点工计划
    labourPointworkPlan: { // labourPointworkPlanDetail
        printConfigUrl: 'projectlabour/labourPointworkPlan/configEdit.js',
        translateName: 'labourPointworkPlan'
    },
    // 点工计划
    labourPointWorkPlan: { // labourPointworkPlanDetail
        printConfigUrl: 'projectlabour/labourPointworkPlan/configEdit.js',
        translateName: 'labourPointworkPlan'
    },
    // 人员进场
    labourWorkerEntry: { // labourWorkerPlanDetail
        printConfigUrl: 'projectlabour/labourWorkerEntry/configEdit.js',
        translateName: 'labourWorkerEntry'
    },
    // 点工报销
    labourPointworkReimburse: { // labourSettlementDetail
        printConfigUrl: 'projectlabour/labourPointworkReimburse/configEdit.js',
        translateName: 'labourPointworkReimburse'
    },
    // 点工报销
    labourPointWorkReimburse: { // labourSettlementDetail
        printConfigUrl: 'projectlabour/labourPointworkReimburse/configEdit.js',
        translateName: 'labourPointworkReimburse'
    },
    // 班组排班
    labourWorkSchedule: {
        printConfigUrl: 'projectlabour/labourWorkSchedule/configEdit.js',
        translateName: 'labourWorkSchedule'
    },
    // 培训
    labourCultivate: {
        printConfigUrl: 'projectlabour/labourCultivate/configEdit.js',
        translateName: 'labourCultivate'
    },
    // 人员离场
    labourWorkerLeave: {
        printConfigUrl: 'projectlabour/labourWorkerLeave/configEdit.js',
        translateName: 'labourWorkerLeave'
    },
    // 请假
    labourWorkerVacation: {
        printConfigUrl: 'projectlabour/labourWorkerVacation/configEdit.js',
        translateName: 'labourWorkerVacation'
    },
    // 违规
    labourWorkerViolations: {
        printConfigUrl: 'projectlabour/labourWorkerViolations/configEdit.js',
        translateName: 'labourWorkerViolations'
    },
    // 劳务结算
    labourSettlement: {
        printConfigUrl: 'projectlabour/labourSettlement/configEdit.js',
        translateName: 'labourSettlement'
    },
    // 劳务支付
    labourPayment: {
        printConfigUrl: 'projectlabour/labourPayment/configEdit.js',
        translateName: 'labourPayment'
    }
};
