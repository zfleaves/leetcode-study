/*
 * @Author: your name
 * @Date: 2022-10-24 13:36:20
 * @LastEditTime: 2022-10-24 13:43:59
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web_personnel-过程云src\components\basicComponents\printTemplate\pintConfig\printConfigUrl\projectprocess.js
 */

export default {
    // 设计技术交底
    technicalDesignDisclosure: {
        printConfigUrl: 'designManagement/designTechnicalDisclosure/configEdit.js',
        translateName: 'designTechnicalDisclosure'
    },
    // 设计变更通知单
    technicalDesignDisclosureAdjust: {
        printConfigUrl: 'designManagement/designChangeNotice/configEdit.js',
        translateName: 'designChangeNotice'
    }
};
