/*
 * @Author: your name
 * @Date: 2021-12-10 11:35:13
 * @LastEditTime: 2021-12-10 17:09:24
 * @LastEditors: Please set LastEditors
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \web_capital\src\components\basicComponents\printTemplate\pintConfig\printConfigUrl\capital.js
 */
/*
 * @Author: your name
 * @Date: 2021-08-30 16:53:34
 * @LastEditTime: 2021-08-30 17:02:07
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web_inquire-询价管理\src\components\basicComponents\printTemplate\pintConfig\printConfigUrl\inquire.js
 */
export default {
    // 收入
    capitalBusinessIncome: {
        printConfigUrl: 'otherFundManagement/otherIncome/configEdit.js',
        translateName: 'otherIncome'
    },
    // 支出
    capitalBusinessExpenses: {
        printConfigUrl: 'otherFundManagement/otherExpenses/configEdit.js',
        translateName: 'otherExpenses'
    }
};
