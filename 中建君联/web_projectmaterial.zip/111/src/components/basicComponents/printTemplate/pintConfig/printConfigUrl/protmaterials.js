/*
 * @Author: your name
 * @Date: 2021-02-04 14:15:52
 * @LastEditTime: 2021-11-25 11:24:08
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web_projecttmaterials-项目周转材\src\components\basicComponents\printTemplate\pintConfig\printConfigUrl\protmaterials.js
 */
export default {
    //  ----------- 项目周转材管理 -promachinery ---------------------
    // 总需求
    zmcDemandMasterPlan: {
        printConfigUrl: 'demandPlan/masterPlan/configEdit.js',
        translateName: 'masterPlan'
    },
    // 月
    zmcDemandMonthPlan: {
        printConfigUrl: 'demandPlan/monthPlan/configEdit.js',
        translateName: 'monthPlan'
    },
    // 临时
    zmcDemandTempPlan: {
        printConfigUrl: 'demandPlan/tempPlan/configEdit.js',
        translateName: 'tempPlan'
    },
    // 周
    zmcDemandWeekPlan: {
        printConfigUrl: 'demandPlan/weekPlan/configEdit.js',
        translateName: 'weekPlan'
    },
    // ----------- 机械管理 ---------------------
    // 租赁申请
    leasePurchaseApply: {
        printConfigUrl: 'promaterial/promaterialPurchaseApply/configEdit.js',
        translateName: 'promaterialPurchaseApply'
    },
    // 临时租赁
    leaseSporadicPurchase: {
        printConfigUrl: 'promaterial/sporadicPurchase/configEdit.js',
        translateName: 'sporadicPurchase'
    },
    // 合同结算
    leaseSettlement: {
        printConfigUrl: 'promaterial/purchaseSettlement/configEdit.js',
        translateName: 'purchaseSettlement'
    },
    // 租赁合同付款
    leasePaymentApply: {
        printConfigUrl: 'promaterial/paymentApply/configEdit.js',
        translateName: 'paymentApply'
    },
    // 周转材临时租赁单报销
    leaseSporadicReimburse: {
        printConfigUrl: 'promaterial/sporadicReimburse/configEdit.js',
        translateName: 'sporadicReimburse'
    },
    // ----------- 现场机械管理 ---------------------
    // 进场
    zlcWarehouseApproach: {
        printConfigUrl: 'warManagement/warIncoming/configEdit.js',
        translateName: 'warIncoming'
    },
    // 领用
    zlcWarehouseOutbound: {
        printConfigUrl: 'warManagement/warOutbound/configEdit.js',
        translateName: 'warOutbound'
    },
    // 归还
    zlcWarehouseReturn: {
        printConfigUrl: 'warManagement/warReturn/configEdit.js',
        translateName: 'warReturn'
    },
    // 退场
    zlcWarehouseExit: {
        printConfigUrl: 'warManagement/warReturngoods/configEdit.js',
        translateName: 'warReturngoods'
    },
    // 报损
    zlcWarehouseScrap: {
        printConfigUrl: 'warManagement/warReportloss/configEdit.js',
        translateName: 'warReportloss'
    }
};
