/*
 * @Author: your name
 * @Date: 2020-07-24 18:12:37
 * @LastEditTime: 2023-02-22 15:53:50
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_contract-合同管理\src\views\task\contract.js
 */
import config from 'util/config';

export default {
    //  ----------- 公司收入合同 -contract ---------------------
    // 收入合同登记
    contractIncomeRegister: {
        printConfigUrl: 'contractIncome/contractIncomeRegister/configEdit.js',
        translateName: 'contractIncomeRegister'
    },
    // 收入合同登记更新
    contractIncomeRegisterAdjust: {
        printConfigUrl: 'contractIncome/contractIncomeRegisterAdjust/configEdit.js',
        translateName: 'contractIncomeRegisterAdjust'
    },
    // 合同变更/签证
    contractIncomeChange: {
        printConfigUrl: 'contractIncome/contractIncomeChange/configEdit.js',
        translateName: 'contractIncomeChange'
    },
    // 收入合同进度款申报
    contractIncomeProgressPayment: {
        printConfigUrl: 'contractIncome/contractIncomePayment/configEdit.js',
        translateName: 'contractIncomePayment'
    },
    // 内部产值报审
    contractIncomeInternalPayment: {
        printConfigUrl: 'contractIncome/contractIncomeInternalPayment/configEdit.js',
        translateName: 'contractIncomeInternalPayment'
    },
    // 收入合同开票
    contractIncomeInvoice: {
        printConfigUrl: 'contractIncome/contractIncomeInvoice/configEdit.js',
        translateName: 'contractIncomeInvoice'
    },
    // 收入合同签证
    contractIncomeVisa: {
        printConfigUrl: 'contractIncome/contractIncomeVisa/configEdit.js',
        translateName: 'contractIncomeVisa'
    },
    // 合同收款登记
    contractIncomeCollection: {
        printConfigUrl: 'contractIncome/contractIncomeCollection/configEdit.js',
        translateName: 'contractIncomeCollection'
    },
    // 支出合同内部评审
    contractExpendReview: {
        printConfigUrl: 'contractExpend/contractExpendInternalReview/configEdit.js',
        translateName: 'contractExpendInternalReview'
    },
    // 支出合同登记
    contractExpendRegister: {
        printConfigUrl: 'contractExpend/contractExpendRegister/configEdit.js',
        translateName: 'contractExpendRegister'
    },
    // 支出合同变更
    contractExpendChange: {
        printConfigUrl: 'contractExpend/contractExpendChange/configEdit.js',
        translateName: 'contractExpendChange'
    },
    // 支出合同收票
    contractExpendInvoice: {
        printConfigUrl: 'contractExpend/contractExpendInvoice/configEdit.js',
        translateName: 'contractExpendInvoice'
    },
    // 支出合同付款
    contractExpendPayment: {
        printConfigUrl: 'contractExpend/contractExpendPayment/configEdit.js',
        translateName: 'contractExpendPayment'
    },
    // 支出合同结算
    contractExpendSettlement: {
        printConfigUrl: 'contractExpend/contractExpendSettlement/configEdit.js',
        translateName: 'contractExpendSettlement'
    },
    // 支出合同签证
    contractExpendVisa: {
        printConfigUrl: 'contractExpend/contractExpenditureVisa/configEdit.js',
        translateName: 'contractExpenditureVisa'
    },
    // 已签合同更新
    contractExpendRegisterAdjust: {
        printConfigUrl: 'contractExpend/contractExpendRegisterAdjust/configEdit.js',
        translateName: 'contractExpendRegisterAdjust'
    }
};
