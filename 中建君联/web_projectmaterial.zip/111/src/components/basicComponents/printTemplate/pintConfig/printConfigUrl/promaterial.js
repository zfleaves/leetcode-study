export default {
    //  ----------- 项目材料管理 -promaterial ---------------------
    //  ----------- 材料 ---------------------
    // 施工总预算
    demandMasterPlan: {
        printConfigUrl: 'demandPlan/masterPlan/configEdit.js',
        translateName: 'masterPlan'
    },
    // 调整
    demandMasterPlanAdjust: {
        printConfigUrl: 'demandPlan/masterPlanAdjust/configEdit.js',
        translateName: 'masterPlanAdjust'
    },
    // 年
    demandYearPlan: {
        printConfigUrl: 'demandPlan/yearPlan/configEdit.js',
        translateName: 'yearPlan'
    },
    // 季
    demandQuarterPlan: {
        printConfigUrl: 'demandPlan/quarterPlan/configEdit.js',
        translateName: 'quarterPlan'
    },
    // 月
    demandMonthPlan: {
        printConfigUrl: 'demandPlan/monthPlan/configEdit.js',
        translateName: 'monthPlan'
    },
    // 临时
    demandTempPlan: {
        printConfigUrl: 'demandPlan/tempPlan/configEdit.js',
        translateName: 'tempPlan'
    },
    // 周
    demandWeekPlan: {
        printConfigUrl: 'demandPlan/weekPlan/configEdit.js',
        translateName: 'weekPlan'
    },
    // ----------- 采购管理 ---------------------
    // 采购计划
    purchasePurchaseApply: {
        printConfigUrl: 'promaterial/promaterialPurchaseApply/configEdit.js',
        translateName: 'promaterialPurchaseApply'
    },
    // 供货订单
    purchaseSupplyOrder: {
        printConfigUrl: 'promaterial/supplyOrder/configEdit.js',
        translateName: 'supplyOrder'
    },
    // 甲供订单
    purchaseSupplyPartyAOrder: {
        printConfigUrl: 'promaterial/supplyOrderA/configEdit.js',
        translateName: 'supplyOrderA'
    },
    // 到货验收
    purchaseCheckArrival: {
        printConfigUrl: 'promaterial/checkArrival/configEdit.js',
        translateName: 'checkArrival'
    },
    // 零星采购
    purchaseSporadicPurchase: {
        printConfigUrl: 'promaterial/sporadicPurchase/configEdit.js',
        translateName: 'sporadicPurchase'
    },
    // 合同结算
    purchaseSettlement: {
        printConfigUrl: 'promaterial/purchaseSettlement/configEdit.js',
        translateName: 'purchaseSettlement'
    },
    // 付款申请
    purchasePaymentApply: {
        printConfigUrl: 'promaterial/paymentApply/configEdit.js',
        translateName: 'paymentApply'
    },
    // 零星采购报销
    purchaseSporadicReimburse: {
        printConfigUrl: 'promaterial/sporadicReimburse/configEdit.js',
        translateName: 'sporadicReimburse'
    },
    // ----------- 出入库管理 ---------------------
    // 材料入库
    warehouseIncoming: {
        printConfigUrl: 'warManagement/warIncoming/configEdit.js',
        translateName: 'warIncoming'
    },
    // 材料出库
    warehouseOutbound: {
        printConfigUrl: 'warManagement/warOutbound/configEdit.js',
        translateName: 'warOutbound'
    },
    // 领料退回
    warehouseReturn: {
        printConfigUrl: 'warManagement/warReturn/configEdit.js',
        translateName: 'warReturn'
    },
    // 材料报损
    warehouseReportloss: {
        printConfigUrl: 'warManagement/warReportloss/configEdit.js',
        translateName: 'warReportloss'
    },
    // 材料退货
    warehouseReturngoods: {
        printConfigUrl: 'warManagement/warReturngoods/configEdit.js',
        translateName: 'warReturngoods'
    },
    // 材料调拨
    warehouseAllocation: {
        printConfigUrl: 'warManagement/warAllocation/configEdit.js',
        translateName: 'warAllocation'
    },
    // 盘点
    warehouseInventory: {
        printConfigUrl: 'warManagement/warInventory/configEdit.js',
        translateName: 'warInventory'
    },
    // 废旧物资处理
    warWasteMaterials: {
        printConfigUrl: 'warManagement/wasteMaterials/configEdit.js',
        translateName: 'wasteMaterials'
    },
    // ----------- 工程设备管理 ---------------------
    // 工程设备安装
    equipmentInstall: {
        printConfigUrl: 'equip/equipInstall/configEdit.js',
        translateName: 'equipInstall'
    },
    // 工程设备检测
    equipmentCheck: {
        printConfigUrl: 'equip/equipCheck/configEdit.js',
        translateName: 'equipCheck'
    },
    // ----------- 分包方材料管理 ---------------------
    // 材料进场
    subcontractMaterialEnter: {
        printConfigUrl: 'subcontractorMaterial/materialApproach/configEdit.js',
        translateName: 'materialApproach'
    },
    // 材料退场
    subcontractMaterialExit: {
        printConfigUrl: 'subcontractorMaterial/materialsBothered/configEdit.js',
        translateName: 'materialsBothered'
    },
    // 对账单
    receiptTracking: {
        printConfigUrl: 'processExecutionTracking/receiptTracking/printConfig.js',
        translateName: 'receiptTracking'
    }
};
