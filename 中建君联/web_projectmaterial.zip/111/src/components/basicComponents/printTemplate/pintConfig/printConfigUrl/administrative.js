/*
 * @Author: your name
 * @Date: 2021-03-15 13:51:41
 * @LastEditTime: 2021-12-10 14:49:15
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web_administrative\src\views\task\administrative.js
 */
import config from 'util/config';

export default {
    //  ----------- 行政事务云 -administrative ---------------------
    // 信息管理
    // 收文管理
    adDocReceive: {
        printConfigUrl: 'informationManagement/recordManagement/configEdit.js',
        translateName: 'recordManagement'
    },
    // 发文管理
    adDocSend: {
        printConfigUrl: 'informationManagement/postManagement/configEdit.js',
        translateName: 'postManagement'
    },
    // 消息通知
    adMessage: {
        printConfigUrl: 'informationManagement/announcement/configEdit.js',
        translateName: 'announcement'
    },
    // 新闻管理
    adNews: {
        printConfigUrl: 'informationManagement/newsManagement/configEdit.js',
        translateName: 'newsManagement'
    },
    // 印章管理
    // 刻印申请
    adSealEngrave: {
        printConfigUrl: 'sealManagement/printsBeforeApplying/configEdit.js',
        translateName: 'printsBeforeApplying'
    },
    // 印章登记
    adSealRegister: {
        printConfigUrl: 'sealManagement/sealRegistration/configEdit.js',
        translateName: 'sealRegistration'
    },
    // 借印申请
    adSealBorrow: {
        printConfigUrl: 'sealManagement/printApply/configEdit.js',
        translateName: 'printApply'
    },
    // 用印申请
    adSealUse: {
        printConfigUrl: 'sealManagement/usingApplication/configEdit.js',
        translateName: 'usingApplication'
    },
    // 印章销毁
    adSealDestroy: {
        printConfigUrl: 'sealManagement/sealDestruction/configEdit.js',
        translateName: 'sealDestruction'
    },
    // 文件管理
    // 文件登记
    adFileRegister: {
        printConfigUrl: 'documentBorrowingManagement/fileRegistration/configEdit.js',
        translateName: 'fileRegistration'
    },
    // 外借登记
    adFileBorrow: {
        printConfigUrl: 'documentBorrowingManagement/fileCheckRegistration/configEdit.js',
        translateName: 'fileCheckRegistration'
    },
    // 归还登记
    adFileBack: {
        printConfigUrl: 'documentBorrowingManagement/fileReturnRegistration/configEdit.js',
        translateName: 'fileReturnRegistration'
    },
    // 借阅登记
    adFileRead: {
        printConfigUrl: 'documentBorrowingManagement/referApply/configEdit.js',
        translateName: 'referApply'
    },
    // 车辆管理
    // 车辆登记
    adCarRegister: {
        printConfigUrl: 'vehicleManagement/vehicleRegistration/configEdit.js',
        translateName: 'vehicleRegistration'
    },
    adCarUseApply: {
        printConfigUrl: 'vehicleManagement/vehicleApplication/configEdit.js',
        translateName: 'vehicleApplication'
    },
    // 车辆外借
    adCarBorrow: {
        printConfigUrl: 'vehicleManagement/carCheckRegistration/configEdit.js',
        translateName: 'carCheckRegistration'
    },
    // 车辆归还
    adCarBack: {
        printConfigUrl: 'vehicleManagement/carReturnRegistration/configEdit.js',
        translateName: 'carReturnRegistration'
    },
    // 车辆保险
    adCarInsurance: {
        printConfigUrl: 'vehicleManagement/automobileInsurance/configEdit.js',
        translateName: 'automobileInsurance'
    },
    // 车辆维修
    adCarRepair: {
        printConfigUrl: 'vehicleManagement/maintenanceRequest/configEdit.js',
        translateName: 'maintenanceRequest'
    },
    // 车辆年审
    adCarAnnual: {
        printConfigUrl: 'vehicleManagement/annualVehicleInspection/configEdit.js',
        translateName: 'annualVehicleInspection'
    },
    // 费用登记
    adCarCost: {
        printConfigUrl: 'vehicleManagement/costRegistration/configEdit.js',
        translateName: 'costRegistration'
    },
    // 车辆保养
    adCarMaintain: {
        printConfigUrl: 'vehicleManagement/vehicleMaintenance/configEdit.js',
        translateName: 'vehicleMaintenance'
    },
    // 车辆转让
    adCarTransfer: {
        printConfigUrl: 'vehicleManagement/vehicleTransfer/configEdit.js',
        translateName: 'vehicleTransfer'
    },
    // 车辆报废
    adCarScrap: {
        printConfigUrl: 'vehicleManagement/vehicleScrapping/configEdit.js',
        translateName: 'vehicleScrapping'
    },
    // 办公用品管理
    // 采购申请
    adMaterialPurchase: {
        printConfigUrl: 'officeSuppliesManagement/purchaseRequest/configEdit.js',
        translateName: 'purchaseRequest'
    },
    // 新购物品登记
    adMaterialRegister: {
        printConfigUrl: 'officeSuppliesManagement/registerNewPurchases/configEdit.js',
        translateName: 'registerNewPurchases'
    },
    // 领用登记
    adMaterialConsume: {
        printConfigUrl: 'officeSuppliesManagement/recipientsRegister/configEdit.js',
        translateName: 'recipientsRegister'
    },
    // 报损登记
    adMaterialLoss: {
        printConfigUrl: 'officeSuppliesManagement/reportedLossRegistration/configEdit.js',
        translateName: 'reportedLossRegistration'
    },
    // 借用登记
    adMaterialBorrow: {
        printConfigUrl: 'officeSuppliesManagement/borrowRegistration/configEdit.js',
        translateName: 'borrowRegistration'
    },
    // 归还登记
    adMaterialBack: {
        printConfigUrl: 'officeSuppliesManagement/returnRegistration/configEdit.js',
        translateName: 'returnRegistration'
    },
    // 费用登记
    adMaterialCost: {
        printConfigUrl: 'officeSuppliesManagement/feeRegistration/configEdit.js',
        translateName: 'feeRegistration'
    },
    // 出差申请
    adBusinessTravel: {
        printConfigUrl: 'integratedManagement/syntheticBusinesstrave/configEdit.js',
        translateName: 'syntheticBusinesstrave'
    },
    // 差旅费报销
    travelExpensesReimburse: {
        printConfigUrl: 'costManagement/travelReimburse/configEdit.js',
        translateName: 'travelReimburse'
    },
    // 其他费用报销
    otherExpensesReimburse: {
        printConfigUrl: 'costManagement/otherReimburse/configEdit.js',
        translateName: 'otherReimburse'
    },
    // 借款申请
    adLoanApply: {
        printConfigUrl: 'loanRepaymentManagement/loan/configEdit.js',
        translateName: 'loan'
    },
    // 还款登记
    adRepaymentApply: {
        printConfigUrl: 'loanRepaymentManagement/repayment/configEdit.js',
        translateName: 'repayment'
    }
};
