<template>
  <div>
        <query-page
            :page-config="pageConfig"
            :loading.sync="loading"
            @searchData="getSearchData"
            @fnName="pageConfigBtnFnName"
            @resetTableConfigList="pageConfigResetTableConfigList"
            @onRefresh="pageConfigOnRefresh"
            @pages="pageConfigPages"
            @searchEvent="searchEvent"
            >
            <template slot="mainTable" slot-scope="config">
              <g-query-table
                :config="config.scope"
                :tableList.sync="tableSeleList"
                @fnName="pageConfigEmitQueryTableButtonFnName">
              </g-query-table>
            </template>
        </query-page>
        <!-- 使用帮助 -->
        <g-dialog v-if="dialogInstructionsForUse" :dialogConfig="dialogConfigInstructionsForUse" :isVisible.sync="dialogInstructionsForUse">
            <div slot="body" class="instructionsForUse">
              <!-- 1，打印模板是支持需要打印纸质资料进行存档的模板管理工作。
              2，您可以根据实际打印需要的字段进行配置，以输出您需要的关键信息。 -->
              <p>1，{{$t('print.instructionsForUseTips1')}}</p>
              <p>2，{{$t('print.instructionsForUseTips2')}}</p>
            </div>
        </g-dialog>
    </div>
</template>

<script>
  import Page from './config.js';
  import {search} from 'mixins/searchMixins';
  import Auth from 'util/auth';
  import printConfigUrl from './pintConfig/printConfigUrl.js';

  export default {
    name: 'processForm',
    mixins: [search],
    data () {
      const page = new Page();
      return {
        // 查询页面基础参数
        page: new Page(),
        pageConfig: {},
        loading: false,
        printConfigUrl,
        // =====================
        tableSeleList: [],
        // 合并列
        spanArr: [],
        spanArrAll: {},
        pos: 0,
        spanMethodArr: [2],
        searchData: {
          printModelCode: '',
          printModelName: '',
          remarks: '',
          subSystemCode: this.$utils.config.subSystemCode,
          updateByName: '',
          updateTimeFrom: '',
          updateTimeTo: ''
        },
        // 使用帮助
        dialogInstructionsForUse: false,
        dialogConfigInstructionsForUse: {
            title: this.$t('dialog.instructionsForUse'),
            appendBody: false,
            center: true,
            top: '20vh',
            width: '50%',
            span: '0.3'
        }
      };
    },
    async created () {
      // console.log('123456');
      await this._getTableDataList();
    },
    methods: {
      handleInstructionsForUse() {
        this.dialogInstructionsForUse = true;
      },
      // 获取表单
      _getTableDataList () {
        this.loading = true;
        const data = {
            pageNo: this.pageNo,
            pageSize: this.pageSize,
            ...this.pageConfig.searchControls.searchData
        };
        this.$store.dispatch('printApi/getPrintList', data).then(res => {
          if (res.status === 0) {
            this.pageConfig.mainTable.tableData = res.results.records;
            this.pageConfig.mainTable.total = res.results.total;
          } else {
            this.$message.error(res.errorMessage);
          }
          this.loading = false;
        }).catch(e => {
          this.loading = false;
        });
      },
      // 预览修改模板
      handleViewEditTemplate(row) {
        row.printModelCode = row.printModelCode.replace(/(^\s*)|(\s*$)/g, '');
        const formCode = this.$base64.encode(row.printModelCode);
        const taskId = this.$base64.encode('template');
        const id = this.$base64.encode(row.id || 0);
        const RouteTitleObj = {name: 'printDesign', loadRouteName: this.$route.name, translateType: 'print'};
        // printConfigUrl
        const translateName = this.printConfigUrl[row.printModelCode].translateName;
        localStorage.setItem('RouteTitle', JSON.stringify(RouteTitleObj));
        this.$router.push(`/printDesign/${formCode}/${taskId}/${id}/${translateName}`);
      }
    }
  };
</script>

<style scoped lang="scss">
.instructionsForUse{
  margin-top: 50px;
  p{
    padding: 10px 0;
  }
}
</style>
