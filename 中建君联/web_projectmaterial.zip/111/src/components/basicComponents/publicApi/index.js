/*
 * @Author: your name
 * @Date: 2020-09-08 15:40:13
 * @LastEditTime: 2020-09-18 09:53:56
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web_basicconfiguration\src\components\basicComponents\publicApi\publicApi.js
 */
import request from 'util/serve';

// 批量获取人员信息
export function getUserInfosList(data) {
    return request({
      url: '/basicconfiguration/organization/user/basic/infos',
      method: 'post',
      data
    });
}
// 任务通知状态
export function getTaskStatus() {
  return request({
    url: '/basic/message/api/user/count',
    method: 'post'
  });
}
// 消息通知状态
export function getMessageStatus() {
  return request({
    url: '/basic/message/api/count',
    method: 'get'
  });
}

