<!--
 * @Author: your name
 * @Date: 2020-07-17 14:55:27
 * @LastEditTime: 2022-10-12 17:43:06
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_unit\src\components\basicComponents\process\monitorDailog.vue
-->
<template>
  <div class="processDefineWrap" :style="{height: dailogHeight - 30 + 'px'}" style="position: relative;">
    <div class="fixed-scroll">
      <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
        <!-- 流程图 -->
        <el-tab-pane :label="$t('dialog.flowChart')" name="first" v-if="processType !== 'scenarioFlow'">
          <div class="process">
            <div>
                <h3 style="text-align: center;width: 100%;">
                  {{processName}}
                    <span style="float: right;">
                        <span
                        style="display:inline-block; height:12px; width:12px; background:#4fba4f; margin-left:6px; vertical-align:middle;">
                        </span>
                        <!-- 已完成步骤 -->
                        <label style="vertical-align:middle;">{{$t('dialog.stepCompleted')}}</label>
                        <span
                        style="display:inline-block; height:12px; width:12px; background:#ff9001; margin-left:6px; vertical-align:middle;">
                        </span>
                        <!-- 待处理步骤 -->
                        <label style="vertical-align:middle;">{{$t('dialog.pendingSteps')}}</label>
                        <span
                        style="display:inline-block; height:12px; width:12px; background:#7e7e7f; margin-left:6px; vertical-align:middle;">
                        </span>
                        <!-- 未经过步骤 -->
                        <label style="vertical-align:middle;">{{$t('dialog.noSteps')}}</label>
                    </span>
                </h3>
            </div>
            <div class="processCons">
              <!--流程画布栏-->
              <div id="myDisplayDiv" style="width: 100%;">
              </div>
            </div>
          </div>
        </el-tab-pane>
        <!-- 处理事项 -->
        <el-tab-pane class="scenarioFlow" v-if="processType === 'scenarioFlow'" :label="$t('dialog.eventChart')" name="first">
          <div class="process">
            <div class="processCons">
              <el-steps style="width:100%" finish-status="success" :active="activeProcess"  align-center>
                <el-step v-for="item of processNodeMasters" :key="item.id" :title="item.nodeName" :icon="item.icon">
                </el-step>
              </el-steps>
            </div>
          </div>
        </el-tab-pane>
        <!-- 审批记录 -->
        <el-tab-pane :label="processType === 'scenarioFlow' ? $t('dialog.mattersHandled') : $t('dialog.approvalRecord')" name="second">
          <div class="is-scrolling" :style="{height: dailogHeight - 86 + 'px'}">
              <el-table
                :data="tableData" ref="multipleTable" border stripes>
                <el-table-column type="index" :label="$t('fConfig.serialNumber')" key="2" width="50">
                </el-table-column>
                <!-- 节点名称 -->
                <el-table-column prop="nodeName" :label="$t('dialog.nodeName')" min-width="120" show-overflow-tooltip>
                </el-table-column>
                <!-- 处理类型 -->
                <el-table-column prop="approval" width="100" :label="$t('dialog.approval')" show-overflow-tooltip>
                </el-table-column>
                <!-- 处理意见 -->
                <el-table-column prop="comment" :label="$t('dialog.comment')" show-overflow-tooltip>
                </el-table-column>
                <!-- 处理人 -->
                <el-table-column prop="assigneeName" width="120" :label="$t('dialog.assigneeName')" show-overflow-tooltip>
                </el-table-column>
                <!-- 处理时间 -->
                <el-table-column :label="$t('dialog.executeDate')" width="160" show-overflow-tooltip>
                  <template slot-scope="scope">
                    <span class="midFont">{{scope.row.executeDate | setTime}}</span>
                  </template>
                </el-table-column>
             </el-table>
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script>
  import {FlowDisplay} from './flow-display';

  export default {
    name: 'monitorDialog',
    data() {
      return {
        activeName: 'first',
        taskLogShow: false,
        processName: '',
        nodeObj: {
          class: 'go.GraphLinksModel',
          modelData: {'position': '-5 -5'},
          nodeDataArray: [],
          linkDataArray: []
        },
        flag: false,
        myDisplay: '',
        text: '',
        formCode: '',
        processCode: '',
        typeList: [
          {nodeCode: 'BEGIN', figure: 'Circle', fill: '#4fba4f'},
          {nodeCode: 'APPROVAL', figure: 'Rectangle', fill: '#7e7e7f'},
          {nodeCode: 'COUNTERSIGN', figure: 'RoundedRectangle', fill: '#7e7e7f'},
          {nodeCode: 'DECIDE', figure: 'Diamond', fill: '#7e7e7f'},
          {nodeCode: 'TOLERANCE', figure: 'Diamond', fill: '#7e7e7f'},
          {nodeCode: 'EXCLUSION', figure: 'Diamond', fill: '#7e7e7f'},
          {nodeCode: 'PARALLEL', figure: 'Diamond', fill: '#7e7e7f'},
          {nodeCode: 'MERGE', figure: 'Diamond', fill: '#7e7e7f'},
          {nodeCode: 'END', figure: 'Circle', fill: '#7e7e7f'}
        ],
        nodeForm: '',
        nodeInfo: '',
        linkList: [],
        tableData: [],
        finishNode: [],
        finishLinkNode: [],
        approvalArr: [],
        currentProcessNodeCode: '',
        processType: '',
        processExecutionDiagram: [],
        activeProcess: 0,
        stepProcessCode: '',
        processNodeMasters: []
      };
    },
    computed: {
      taskId() {
        return this.$store.state.diaLog.taskId;
      },
      dailogHeight() {
        return document.body.offsetHeight * 0.84 - 44 - 55;
      }
    },
    created() {
      this.processType = localStorage.getItem('processType');
    },
    beforeDestroy() {
      localStorage.removeItem('processType');
    },
    mounted() {
      if (this.processType === 'scenarioFlow') {
        this.getStepTaskInfo();
      } else {
        this.myDisplay = new FlowDisplay('myDisplayDiv');
        this._getCompanyTasksInfo();
      }
    },
    methods: {
      // 获取任务详情
      getStepTaskInfo() {
        this.$store.dispatch('publicApi/getStepTaskQueryInfoPublicApi', {taskId: this.taskId}).then(res => {
          if (res.status === 0) {
            this.stepProcessCode = res.results.processCode;
            this.getStepPublishProcessWin();
          }
        });
      },
      // 查询流程实例详细信息及其节点和连线信息
      getStepPublishProcessWin() {
        this.$store.dispatch('publicApi/getStepPublishProcessWinPublicApi', {processCode: this.stepProcessCode}).then(res => {
          if (res.status === 0 && res.results) {
            this.processNodeMasters = res.results.processNodeMasters;
            this.getStepTaskLogListPublicApi();
          }
        });
      },
      // 获取右侧信息列表
      getStepTaskLogListPublicApi() {
        this.$store.dispatch('publicApi/getStepTaskLogListPublicApi', {taskId: this.taskId}).then(res => {
          this.tableData = res.results;
          this.activeProcess = 0;
          for (const item of res.results) {
            const index = this.processNodeMasters.findIndex(v => v.processNodeCode === item.processNodeCode);
            if (index >= 0) {
              this.$set(this.processNodeMasters[index], 'status', item.status);
            }
          }
          this.activeProcess = this.processNodeMasters.filter(v => v.status === 0).length;
        });
      },
      handleClick() {

      },
      _getCompanyTasksInfo() {
        this.$store.dispatch('processApi/getTaskInfo', {taskId: this.taskId}).then(res => {
          const params = res.results;
          this.currentProcessNodeCode = params.currentProcessNodeCode;
          this.processCode = params.processCode;
          this.processName = `${params.taskName}-${this.$t('dialog.monitor')}`; // 监控
          this.flag = params.status === 0;
          this._getProcessNodeList();
        });
      },
      // 查询流程模版的节点和连接信息
      _getProcessNodeList() {
        this.$store.dispatch('processApi/getProcessNodeList', {processCode: this.processCode}).then(res => {
          const nodeObj = res.results;
          this.nodeObj.nodeDataArray = this.setNodeDataArray(nodeObj.processNodes);
          this.nodeObj.linkDataArray = this.setLinkDataArray(nodeObj.processNodeConnects);
          this.myDisplay.loadFlow(this.nodeObj);
          this._findWorkflowLogs();
        });
      },
      // 获取右侧信息列表
      _findWorkflowLogs() {
        this.$store.dispatch('processApi/getTasksQueryLogs', {taskId: this.taskId}).then(res => {
          this.tableData = res.results;
          this.showFlowPath();
        });
      },
      showFlowPath() {
        this.getNodeData1();
        const approvalArr = this.tableData.filter(v => v.status === 1);
        const handleNode1 = this.tableData.filter(v => v.status === 0 && v.nodeName !== '开始' && v.approval !== '驳回');
        this.finishNode = this.finishNode.concat(approvalArr);
        this.finishNode = this.finishNode.concat(handleNode1);
        this.myDisplay.animateFlowPath(this.finishNode, this.flag, this.finishLinkNode);
      },
      // 处理流程节点
      setNodeDataArray(arr) {
        const list = [];
        for (const i in arr) {
          const item = arr[i];
          item.key = item.processNodeCode;
          item.text = item.nodeName;
          item.width = 50;
          item.height = 50;
          const index = this.typeList.findIndex(v => v.nodeCode === item.nodeCode);
          item.figure = this.typeList[index].figure || '';
          item.fill = this.typeList[index].fill || '';
          item.loc = `${item.indexX} ${item.indexY}`;
          if (item.nodeCode !== 'BEGIN') {
            item.stepType = 1;
          }
          if (item.nodeCode !== 'END') {
            item.stepType = 4;
          }
          list.push(item);
        }
        return list;
      },
      // 处理连线
      setLinkDataArray(arr) {
        // {"from": "4", "to": "6", "key": "1001", "text": "小于5天 ", "remark": "", "condition": "Days<5"},
        const list = [];
        for (const i in arr) {
          const item = arr[i];
          item.text = item.tips;
          item.from = item.processNodeCode;
          item.to = item.nextProcessNodeCode;
          list.push(item);
        }
        return list;
      },

      // 获取连线节点
      getNodeData() {
        const arr = [];
        const linkList = [];
        const linkDataArray = this.nodeObj.linkDataArray;
        const nodeDataArray = this.nodeObj.nodeDataArray;
        const handleNode = this.tableData.filter(v => v.status === 0 && v.nodeName !== '开始' && v.approval !== '驳回');
        for (const i in handleNode) {
          const item = handleNode[i];
          const index = linkDataArray.findIndex(v => v.to === item.processNodeCode);
          const index2 = linkDataArray.findIndex(v => v.from === item.processNodeCode);
          if (item.status === 0) {
            arr.push(item);
          }
          if (index2 >= 0 && item.status === 0) {
            linkList.push(linkDataArray[index2]);
          }
          if (index >= 0) {
            const form = linkDataArray[index].from;
            linkList.push(linkDataArray[index]);
            const index1 = nodeDataArray.findIndex(v => v.processNodeCode === form);
            if (index1 >= 0) {
              arr.push(nodeDataArray[index1]);
            }
          }
        }
        let list = arr.filter(v => v.nodeCode !== 'BEGIN');
        const handleProcess = this.tableData.filter(v => v.status === 1);
        list = list.concat(handleProcess);
        this.linkList = [];
        for (const i in linkList) {
          const item = linkList[i];
          const index = handleProcess.findIndex(v => v.processNodeCode === item.from);
          if (index < 0) {
            this.linkList.push(item);
          }
        }
        if (handleNode.length) {
          const startIndex = nodeDataArray.findIndex(v => v.nodeCode === 'BEGIN');
          const startNode = nodeDataArray[startIndex];
          const [startLink] = linkDataArray.filter(v => v.from === startNode.processNodeCode);
          this.linkList.push(startLink);
        }
        return list;
      },
      getNodeData1() {
        const arr = [];
        const linkList = [];
        const linkDataArray = this.nodeObj.linkDataArray;
        const nodeDataArray = this.nodeObj.nodeDataArray;
        this.approvalArr = this.tableData.filter(v => v.status === 0);
        let handleNode = [];
        if (this.flag) {
          const finishIndex = nodeDataArray.findIndex(v => v.nodeCode === 'END');
          handleNode.push(nodeDataArray[finishIndex]);
        } else {
          handleNode = this.tableData.filter(v => v.status === 1);
        }
        this.findPrevNode(handleNode);
        // 包容 并行是，一边审批通过，一边待审批
        const handleNode1 = this.tableData.filter(v => v.status === 0 && v.nodeName !== '开始' && v.approval !== '驳回');
        this.findPrevNode(handleNode1);
      },
      findPrevNode(currentNode) {
        const linkDataArray = this.nodeObj.linkDataArray;
        const nodeDataArray = this.nodeObj.nodeDataArray;
        const prevLink = [];
        const prevNode = [];
        for (let i = 0; i < currentNode.length; i++) {
          const item = currentNode[i];
          if (item.nodeCode === 'BEGIN') return;
          // 找到连线
          const prevLink = linkDataArray.filter(v => v.to === item.processNodeCode);
          for (let j = 0; j < prevLink.length; j++) {
            const child = prevLink[j];
            const from = child.from;
            const nodeIndex = nodeDataArray.findIndex(v => v.processNodeCode === from);
            if (nodeIndex >= 0) {
              const tempNode = nodeDataArray[nodeIndex];
              if (tempNode.nodeCode === 'APPROVAL' || tempNode.nodeCode === 'COUNTERSIGN') {
                if (this.approvalArr.some(v => v.processNodeCode === tempNode.processNodeCode)) {
                  prevNode.push(tempNode);
                  this.finishNode.push(tempNode);
                  this.finishLinkNode.push(child);
                }
              } else {
                prevNode.push(tempNode);
                this.finishNode.push(tempNode);
                this.finishLinkNode.push(child);
              }
            }
          }
        }
        if (prevNode.length) {
          this.findPrevNode(prevNode);
        }
      },
      handleOpen() {
      }
    }
  };
</script>

<style scoped lang="scss">
  /deep/ .el-tabs__content{
    width: 100%;
    height: calc(100% - 60px);
  }
  /deep/ .el-tabs{
    width: 100%;
    height: 100%;
  }
  .is-scrolling {
    overflow: auto;
  }
.scenarioFlow{
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  /deep/ .el-tabs__content{
    width: 100%;
    height: calc(100% - 60px);
    display: flex;
    align-items: center;
  }
  /deep/ .el-tab-pane {
    width: 100%;
    background: #ffffff;
  }
  /deep/ .el-tabs{
    width: 100%;
    height: 100%;
  }
  /deep/ .el-step:first-child{
    .el-step__title{
      width: 40px !important;
      height: 40px !important;
      border-radius: 50%;
      margin: 10px;
      padding: 10px !important;
      line-height: 38px;
    }
  }
  /deep/ .el-step:last-child{
    .el-step__title{
      width: 40px !important;
      height: 40px !important;
      border-radius: 50%;
      margin: 10px;
      padding: 10px !important;
      line-height: 38px;
    }
  }
  /deep/ .el-step__title.is-success{
    color: rgb(255, 255, 255);
    margin: 25px 10px 10px 10px;
    background: rgb(103, 194, 58);
    border-radius: 5px;
    padding: 5px 20px;
    display: inline-block;
    line-height: 25px;
  }
  /deep/ .el-step__title.is-process{
    color: rgb(255, 255, 255);
    margin: 25px 10px 10px 10px;
    background: #FFB001;
    border-radius: 5px;
    padding: 5px 20px;
    display: inline-block;
    line-height: 25px;
  }
  /deep/ .el-step__title.is-wait{
    color: rgb(255, 255, 255);
    margin: 25px 10px 10px 10px;
    background: rgb(192, 196, 204);
    border-radius: 5px;
    padding: 5px 20px;
    display: inline-block;
    line-height: 25px;
  }
  .process {
    height: auto !important;
  }
}
  .processDefineWrap {
    display: flex;
    width: 100%;
    /*height: 550px;*/
    flex-direction: column;
    .process {
      display: flex;
      width: 100%;
      height: 500px;
      /*height: 100%;*/
      flex-direction: column;
    }
    .processCons {
      flex: auto;
      display: flex;
      padding-bottom: 30px;
      #myPaletteDiv {
        width: 160px;
        background: #f4f6f8;
        border: 1px solid #dedede;
        padding: 20px 10px;
        margin-right: 20px;
        text-align: center;
        box-sizing: border-box;
        canvas {
          padding: 40px 0;
        }
      }
      #myFlowDesignerDiv {
        flex: 1;
        border: 1px solid #dedede;
      }
    }
    .diagnosticPointInput:focus {
      border: 1px #3e75ff solid !important;
      background-color: red !important;
    }
    .flowLogs {
      height: 500px;
      width: 100%;
      position: relative;
      .flowLogs_fix {
        top: 0;
        width: 100%;
        position: absolute;
        bottom: 0;
        overflow-y: auto;
        &::-webkit-scrollbar {
          display: none;
        }
      }
    }
  }
</style>
