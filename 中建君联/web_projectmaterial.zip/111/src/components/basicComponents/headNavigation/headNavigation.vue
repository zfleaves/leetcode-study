<template>
  <div>
    <div class="header" @click="handleCloseMenu" @mousemove="handleCloseMenu">
      <div class="logo">
        <img :src="logoImage" v-if="logoImage" alt="">
        <img :src="require('assets/images/logoHeader.png')" v-else alt="">
        <span></span>
      </div>
      <div class="header-left">
        <div class="menu">
          <p>{{userInfo.tenantName}}</p>
        </div>
        <div class="public">
          <!-- 快速上手 -->
          <div class="exitLogon midFont"
           @click="jumpPath('getStartedQuickly')">
            {{$t('dialog.getStartedQuickly')}}
             <img class="imgHot" :src="require('../images/hot.gif')" alt />
          </div>
          <!-- 角色菜单 -->
           <!-- <div class="exitLogon midFont"  @mousemove.stop.prevent="mouseoverUseNavigation"
            @mouseleave.stop.prevent="mouseLeaveUseNavigation">
            {{$t('dialog.useNavigation')}}
          </div> -->
          <!-- 系统导航 -->
          <div class="exitLogon midFont"  @mousemove.stop.prevent="mouseoverNavigation" @mouseLeave="mouseLeaveNavigation">
            <!-- {{$t('dialog.navigation')}} -->
            {{$t('dialog.systemNavigation')}}
          </div>
          <!-- <div class="exitLogon midFont" @click="jumpPageProtal('home')">
            {{$t('menu.home')}}
          </div> -->
          <!-- <div class="exitLogon midFont" @click="jumpPageProtal('helpDocument')">
            {{$t('menu.helpDocument')}}
          </div> -->
          <!-- <div class="exitLogon midFont" @mousemove.stop.prevent="() => {
            subsystemNavigationFlag = false,
            useNavigationFlag = false
            }">
            <IMNoticeItems></IMNoticeItems>
          </div> -->
          <!-- 流程办理 -->
          <div class="exitLogon midFont" @click="jumpPageProtal('task')">
            <span v-if="taskStatus > 0">
              <el-badge
                id="notice"
                :value="taskStatus"
                :max="99"
                class="item"
              >
                  {{$t('dialog.processHandle')}}
              </el-badge>
            </span>
            <span v-else>{{$t('dialog.processHandle')}}</span>
          </div>
          <!-- 任务指派 -->
          <div class="exitLogon midFont" @click="jumpPageProtal('taskCenter')">
            <el-badge
              v-if="taskCenterTotal > 0"
              id="notice"
              :value="taskCenterTotal"
              :max="99"
              class="item"
            >
              <span>
                {{$t('dialog.taskCenter')}}
                </span>
            </el-badge>
            <span v-else>{{$t('dialog.taskCenter')}}</span>
          </div>
          <!-- 多方协同 -->
          <div class="exitLogon midFont" @click="jumpPageProtal('interactionCenter')">
            <el-badge
              v-if="interactionCenterStatus > 0"
              id="notice"
              :value="interactionCenterStatus"
              :max="99"
              class="item"
            >
              <span>
                {{$t('dialog.interactionCenter')}}
                </span>
            </el-badge>
            <span v-else>{{$t('dialog.interactionCenter')}}</span>
          </div>

          <!-- <div class="exitLogon midFont" @click="jumpPageProtal('news')">
            {{$t('menu.news')}}
            <span v-if="messageStatus" class="status-notice"></span>
          </div> -->
          <!-- <div class="exitLogon midFont">
            <el-dropdown>
              <span style="color:#fff">
                {{$t('menu.support')}}<i class="el-icon-arrow-down el-icon--right"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item icon="el-icon-plus" @click.native="jumpPageProtal('help')">{{$t('menu.help')}}</el-dropdown-item>
                <el-dropdown-item icon="el-icon-video-camera" @click.native="jumpPageProtal('video')">{{$t('menu.video')}}</el-dropdown-item>
                <el-dropdown-item icon="el-icon-circle-plus-outline" @click.native="jumpPageProtal('proposal')">{{$t('menu.proposal')}}</el-dropdown-item>
                <el-dropdown-item icon="el-icon-check" @click.native="jumpPageProtal('contactUs')">{{$t('menu.contactUs')}}</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </div> -->
          <div class="exitLogon midFont">
            <language>
            </language>
          </div>
          <div class="user-info-list" style="cursor: pointer; padding-left: 30px;position:relative;top:12px;">
            <el-popover
              placement="bottom"
              width="300"
              trigger="hover">
              <div slot="reference" style="cursor: pointer;display: flex;align-items: center;">
                <div class="reference-user-img">
                  <img style="max-width: 100%; max-height: 100%;" class="midFont"
                    :src="userHead ? userHead : require('assets/images/public/nav_user.png')">
                </div>
              </div>
              <div class="userInfo_list">
                <div class="user-info">
                  <div class="user-userHead">
                    <img style="max-width: 100%; max-height: 100%;" class="midFont"
                    :src="userHead ? userHead : require('assets/images/public/nav_user.png')">
                  </div>
                  <div class="user-infos">
                    <tooltips :value="userInfo.tenantName"></tooltips>
                    <span>{{userInfo.userName}}</span>
                  </div>
                </div>
                <div v-for="item in userInfoList" :key="item.callBack"
                    class="list_li"
                    @click="jumpPageProtal(item.path)">
                  <i :class="item.icon"></i>
                  <p style="margin: 0 10px;">{{$t(`menu.${item.path}`)}}</p>
                </div>
                <div class="list_footer" @click="exitLogon">
                  <i class="el-icon-switch-button"></i>
                  <p>{{$t('dialog.exitTheSystem')}}</p>
                </div>
              </div>
            </el-popover>
          </div>
        </div>
      </div>
    </div>
    <el-dialog
      v-dialogDrag
      :visible.sync="dialogVisible"
      style="top:25%"
      width="30%">
      <div slot="title" class="out-header"><i class="el-icon-warning-outline"></i><span>{{$t('globalData.tips')}}</span></div>
      <span style="line-height: 80px;margin-bottom: 80px;text-indent: 1em;display: flex;">{{$t('dialog.exitTheSystemTips')}}?</span>
      <span slot="footer" class="dialog-footer">
        <el-button
          v-fast-click
          icon="el-icon-circle-close"
          class="urgent" type="primary"
          size="small" @click="dialogVisible = false">{{$t('button.close')}}
        </el-button>
        <el-button
          size="small"
          v-fast-click
          icon="el-icon-circle-check"
          type="primary"
          @click="submitForm">{{$t('button.determine')}}
        </el-button>
    </span>
    </el-dialog>

    <transition name="el-zoom-in-top">
      <subsystemNavigation v-if="subsystemNavigationFlag" @close='subsystemNavigationFlag = false'></subsystemNavigation>
    </transition>
    <transition name="fade-menuTransform">
      <menuNavigation v-if="menuNavigationFlag" @close='menuNavigationFlag = false'></menuNavigation>
    </transition>
    <!-- @mousemove="mousemoveMenuModal" -->
    <div class="menuModal" v-show="menuNavigationFlag"  @click="mousemoveMenuModal"></div>

    <div class="navigationModal" v-show="subsystemNavigationFlag"
       @mousemove="subsystemNavigationFlag = false" @click="subsystemNavigationFlag = false"></div>
    <transition name="el-zoom-in-top">
      <useNavigation v-if="useNavigationFlag" @close='() => useNavigationFlag = false'></useNavigation>
    </transition>
    <div class="navigationModal" v-show="useNavigationFlag"
       @mousemove="useNavigationFlag = false" @click="useNavigationFlag = false"></div>
    </div>
</template>

<script>
  import Auth from 'util/auth';
  import Utils from 'util/index.js';
  import config from 'util/config';
 import { getTaskStatus, getMessageStatus } from 'components/basicComponents/publicApi';

  export default {
    name: 'headNavigation',
    inject: ['reload'],
    data () {
      return {
        dialogVisible: false,
        userHead: '',
        userInfoList: [
          {
            name: '基本资料', icon: 'el-icon-user', path: 'personalInfo'
          },
          {
            name: '安全设置', icon: 'el-icon-lock', path: 'setSecurity'
          }
          // {
          //   name: '修改密码', icon: 'el-icon-office-building', path: 'authentication'
          // }
        ],
        types: '',
        userName: '',
        logoImage: '',
        headPic: '',
        isProbation: 0,
        userInfo: {},
        messageStatus: false,
        taskStatus: 0,
        taskCenterTotal: 0,
        interactionCenterStatus: 0,
        taskTimer: null,
        messageTimer: null,
        clickHanlder: null,
        closeHanlder: null,
        menuNavigationFlag: false,
        subsystemNavigationFlag: false,
        useNavigationFlag: false,
        time: 0,
        outTime: 0,
        timeout: 0,
        clickHanlderLeave: null,
        clickmouseout: null
      };
    },
    components: {
      language (resolve) {
        require(['./language.vue'], resolve);
      },
      menuNavigation (resolve) {
        require(['./menuNavigation.vue'], resolve);
      },
      subsystemNavigation (resolve) {
        require(['./subsystemNavigation.vue'], resolve);
      },
      // IMNoticeItems(resolve) {
      //   require(['components/basicComponents/IMNotice/IMNoticeItems.vue'], resolve);
      // },
      useNavigation(resolve) {
        require(['./useNavigation.vue'], resolve);
      }
    },
    computed: {
      stateUserInfo() {
        return this.$store.state.user.userInfo;
      }
    },
    watch: {
      stateUserInfo: {
        handler() {
          this.userInfo = Auth.hasUserInfo();
          this.handleSetUserInfo();
        },
        deep: true
      }
    },
    created() {
      this.userInfo = Auth.hasUserInfo();
      this._getStatus();
      this._getStatusInterval();
    },
    mounted () {
      this.handleSetUserInfo();
      this.$nextTick(() => {
        // const ok = document.getElementById("ok"); // 获取按钮元素的引用
        const menuLink = document.getElementsByClassName('menuLink')[0];
        const menusList = document.getElementsByClassName('menusList')[0];
        const p = document.createElement('p'); // 创建段落节点
        p.setAttribute('id', 'allMenu');
        const text = this.$t(`subSystem.${this.$utils.config.subSystemCode}`);
        p.innerHTML = `<i class='el-icon-menu' id='allMenu-icon'></i>${text}`;
        menuLink && menuLink.appendChild(p);
        menuLink.setAttribute('title', text);
        menuLink && menuLink.addEventListener('mouseover', this.clickHanlder); // 材料云
        menuLink && menuLink.addEventListener('mouseout', this.clickmouseout);
        menusList && menusList.addEventListener('mousemove', this.closeHanlder);
      });

      this.clickmouseout = (e) => {
        clearTimeout(this.timeout);
      };
      this.clickHanlder = (e) => {
        if (e.target.id === 'allMenu') {
            this.timeout = setTimeout(() => {
            this.menuNavigationFlag = true;
          }, 500);
        }
      };

      this.closeHanlder = (e) => {
        // this.menuNavigationFlag = false;
      };
    },
    beforeDestroy() {
      clearInterval(this.taskTimer);
      clearInterval(this.messageTimer);
      // window.removeEventListener('mousemove', this.clickHanlder);
      window.removeEventListener('mousemove', this.clickHanlder);
      window.removeEventListener('mousemove', this.closeHanlder);
    },
    methods: {
      _getStatus() {
        // this._getMessageList();
        this._getTaskList();
      },
      // 获取任务级消息状态延迟
      _getStatusInterval() {
        this.taskTimer = setInterval(() => {
          this._getTaskList();
        }, 60000);
        // this.messageTimer = setInterval(() => {
        //   this._getMessageList();
        // }, (60000 * 5));
      },
      // 获取消息状态
      _getMessageList() {
        getMessageStatus().then(res => {
          if (res.results.allUnRead && res.results.allUnRead > 0) {
            this.messageStatus = true;
          }
        });
      },
      // 获取任务状态
      _getTaskList() {
        getTaskStatus().then(res => {
          if (res.status === 0) {
            this.taskStatus = res.results;
          }
        });
        // 任务中心
        this.$store.dispatch('publicApi/taskAllTodoCountPublicApi', {}).then(res => {
          if (res.status === 0) {
            this.taskCenterTotal = res.results;
          }
        });
        // 互动中心
        this.$store.dispatch('publicApi/getStepTodoCounts').then(res => {
          if (res.status === 0) {
            this.interactionCenterStatus = res.results;
          }
        });
      },
      handleSetUserInfo () {
        const userInfo = Auth.hasUserInfo();
        this.types = userInfo.types;
        this.userName = userInfo.userName;
        // this.logoImage = config.imageUrl + userInfo.logo;
        this.headPic = userInfo.headPic;
        // 1使用客户 0正式客户
        this.isProbation = userInfo.isProbation;
        if (userInfo.logo) {
          this._getLogoDownloadList(userInfo.logo);
        }
        if (!this.headPic) return;
        this._getFileDownloadList(this.headPic);
      },
      // 获取图片路径
      _getFileDownloadList(id) {
          this.$store.dispatch('publicApi/getFilepath', {fileIds: [id]}).then(res => {
             this.userHead = `${config.imageUrl}${res.results[0].filePath}`;
          });
      },
      // 获取图片路径
      _getLogoDownloadList(id) {
          this.$store.dispatch('publicApi/getFilepath', {fileIds: [id]}).then(res => {
             this.logoImage = `${config.imageUrl}${res.results[0].filePath}`;
          });
      },
      // 退出登录
      exitLogon () {
        const tips = `<div style="height: 60px; line-height: 60px;">${this.$t('dialog.exitTheSystemTips')}</div>`;
        this.$confirm(tips, this.$t('tips.tips'), {
          dangerouslyUseHTMLString: true,
          confirmButtonText: this.$t('button.determine'),
          cancelButtonText: this.$t('button.close'),
          type: 'warning'
        }).then(() => {
          this.submitForm();
        }).catch(() => {});
        // this.dialogVisible = true;
      },
      submitForm () {
        const userInfo = Auth.hasUserInfo();
        this.$store.dispatch('publicApi/outLoginPublic', {token: userInfo.token}).then(res => {
          Auth.reLogin();
          Utils.commonUtil.resetVuex(); // 清楚store数据
          this.jumpPageProtal(Auth.hasLoginTitle());
        });
      },
      // 导航跳转到中台页面
      jumpPageProtal(page) {
        if (page === Auth.hasLoginTitle()) {
          const url = `${config.jumpUrl}/portal/#/${page}`;
          window.open(url, '_self');
        } else {
          const href = `${config.jumpUrl}/portal/#/${page}`;
          window.open(href, '_blank');
        }
      },
      handleCloseMenu() {
        this.menuNavigationFlag = false;
      },
      mousemoveMenuModal() {
        this.menuNavigationFlag = false;
      },
      mouseoverNavigation() {
        this.subsystemNavigationFlag = true;
        this.useNavigationFlag = false;
      },
      mouseLeaveNavigation() {
        this.subsystemNavigationFlag = false;
      },
      mouseoverUseNavigation() {
        this.useNavigationFlag = true;
        this.subsystemNavigationFlag = false;
      },
      mouseLeaveUseNavigation() {
        // this.useNavigationFlag = false;
      },
      jumpPath(path) {
        // this.$router.push(`/${path}`);
        const url = `${config.jumpUrl}/portal/#/${path}`;
        window.open(url, '_blank');
      }
    }
  };
</script>

<style scoped lang="scss">
.menuModal {
  width: 100%;
  height: 100%;
  top: 80px;
  left: 200px;
  z-index: 1005;
  position: fixed;
  background-color: rgba(0, 0, 0, 0.5);
  opacity: 1;
}
.navigationModal {
  width: 100%;
  height: 100%;
  top: 80px;
  left: 0px;
  z-index: 1005;
  position: fixed;
  background-color: rgba(0, 0, 0, 0.5);
  opacity: 1;
}

.status-notice{
  width: 5px;
  height: 5px;
  display: inline-block;
  border-radius: 50%;
  background: #f73535;
  position: absolute;
  top: 26px;
  right: -8px;
}
.header {
  height: 80px;
  // padding: 0 0 0 10px;
  width: 100%;
  line-height: 80px;
  overflow: hidden;
  box-sizing: border-box;
  // background: linear-gradient(90deg,#2b74ec,#2b74ec);
  background: white;
  display: flex;
  .logo {
    // float: left;
    background: rgb(43,116,237);
    padding-left: 10px;
    width: 200px;
    line-height: 80px;
    box-sizing: border-box;
    img {
      height: 40px;
      width: 100px;
      position: relative;
      top: 15px;
      left: 10px;
    }
  }
  .header-left {
    // width: calc(100% - 200px);
    flex: auto;
    // float: left;
    padding-left: 10px;
    box-shadow: 0 2px 6px 0 rgba(0, 0, 0, .1);
    background: white;
    margin-bottom: 10px;
  }
  .menu {
    float: left;
    height: 70px;
    flex: auto;
    // background: linear-gradient(90deg,#2b74ec,#2b74ec);
    background: white;
    margin-bottom: 10px;
    // box-shadow: 0 2px 12px 0 rgba(0, 0, 0, .1);
    padding: 0 10px;
    p {
      font-weight: bold;
      font-size: 20px;
    }
    li {
      height: 100%;
      float: left;
      font-size: 12px;
      // color: white;
      color: #000;
      cursor: pointer;
      margin: 0 20px;
      &.active {
        color: #2b74ec;
      }
    }
  }
  .public {
    float: right;
    display: flex;
    height: 70px;
    margin-bottom: 10px;
    // box-shadow: 0 2px 12px 0 rgba(0, 0, 0, .1);
    // background: linear-gradient(90deg,#2b74ec,#2b74ec);
    background: white;
    padding-right: 20px;
    .exitLogon {
      margin-left: 40px;
      // color: white;
      color: #000;
      cursor: pointer;
      position: relative;
      /deep/ .el-badge__content.is-fixed{
        top: 22px !important;
      }
      .imgHot {
        position: absolute;
        top: 11px;
        right: -20px;
      }
    }
    .reference-user-img{
      width: 32px;
      height: 32px;
      overflow: hidden;
      background: #ffffff;
      margin-top: 9px;
      border-radius: 50%;
      display: flex;
      align-items: center;
    }
  }
}

.out-header {
  // color: white;
  color: #000;
  display: flex;
  align-items: center;
  span {
    font-size: 12px;
    margin-left: 5px;
    display: inline-block;
  }
}
.userInfo_list {
  width: 300px;
  .user-info{
    border-bottom: 1px solid #eeeeee;
    padding: 10px 20px;
    box-sizing: border-box;
    display: flex;
    align-items: center;
    .user-userHead{
      width: 45px;
      height: 45px;
      border-radius: 50%;
      padding-right: 15px;
      display: flex;
      align-items: center;
    }
    .user-infos{
      flex: auto;
      line-height: 28px;
      overflow: hidden;
      div{
        font-size: 14px;
        color: black;
      }
    }
  }
  .list_li {
    display: inline-block;
    width: 100%;
    height: 40px;
    line-height: 40px;
    padding: 0 20px;
    box-sizing: border-box;
    cursor: pointer;
    display: flex;
    align-items: center;
    i{
      font-size: 16px;
    }
  }
  .list_li:hover {
    background: #ebebeb;
  }
  .active {
    background: rgb(212, 235, 250);
    color: #2b74ec;
    border-radius: 5px;
  }
  .list_footer {
    display: flex;
    align-items: center;
    justify-content: center;
    line-height: 40px;
    height: 40px;
    text-align: center;
    background: #fafafa;
    cursor: pointer;
    color: #f55e14;
    margin-top: 15px;
  }
  .list_footer:hover {
    background: #eee;
  }
}
</style>
