<!--
 * @Author: your name
 * @Date: 2020-07-27 15:54:27
 * @LastEditTime: 2021-05-25 11:09:54
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web_contract-合同管理\src\components\basicComponents\global\dialog\contractIncomeSummaryDialog\contractIncomeSummaryDialog.vue
-->
<template>
  <div style="height: 100%;">
    <query-page
        res="sysQueryPage"
        :page-config="pageConfig"
        :loading.sync="loading"
        :tableSeleList.sync="tableSeleList"
        :dialogHeight="dialogHeight"
        @searchData="getSearchData"
        @fnName="pageConfigBtnFnName"
        @resetTableConfigList="pageConfigResetTableConfigList"
        @onRefresh="pageConfigOnRefresh"
        @pages="pageConfigPages"
        @dialogEvent="dialogEvent"
        @searchEvent="searchEvent">
        <template slot="mainTable" slot-scope="config">
          <g-query-table
            :config="config.scope"
            :tableList.sync="tableSeleList"
            @fnName="pageConfigEmitQueryTableButtonFnName">
          </g-query-table>
        </template>
    </query-page>
  </div>
</template>

<script>
  import Page from './config.js';
  import {search} from 'mixins/searchMixins';
  import Auth from 'util/auth';

  export default {
    name: 'contractIncomeSummaryDialog',
    mixins: [search],
    data () {
      return {
        // 查询页面基础参数
        page: new Page(),
        pageConfig: {},
        loading: false,
        // =====================
        tableSeleList: [],
        partyATypeTitle: '',
        // 搜索数据
        searchData: {
            contractClassifyId: '',
            contractCode: '',
            contractName: '',
            flowStatus: '',
            partyAUnitId: '',
            partyAUnitName: '',
            projectId: '',
            signTimeFrom: '',
            signTimeTo: '',
            contractNatureCode: '',
            executionStatus: ['01', '02']
        },
        dialogVisible: false
      };
    },
    props: {
        dialogHeight: {
            type: Number,
            default: 300
        },
        // 选中的单位
        selectId: {
            default: 0
        },
        projectId: {
            default: ''
        },
        getTableListApi: {
            type: String,
            default: 'publicApi/getContractIncomeSummaryPage'
        },
        // 合同性质 01 公司 02 项目
        contractNatureCode: {
          default: ''
        }
    },
    async created () {
      await this._getTableDataList();
      this.pageConfig.mainTable.selectedList = [{id: this.selectId}];
    },
    methods: {
      // 获取表单
      _getTableDataList () {
        this.pageConfig.searchControls.searchData.projectId = this.$clone(this.projectId);
        this.pageConfig.searchControls.searchData.contractNatureCode = this.contractNatureCode;
        this.handleGetTableDataList(this.getTableListApi);
      },
      // 根据url获取数据
      handleGetTableDataList(url, paging = true, callBack) {
        this.loading = true;
        const data = {
            pageNo: this.pageNo,
            pageSize: this.pageSize,
            ...this.pageConfig.searchControls.searchData
        };
        this.$store.dispatch(url, data).then(res => {
          if (res.status === 0) {
            if (paging) {
              for (const item of res.results.records) {
                const changeTotalAmount = item.changeTotalAmount || 0;
                const signAmount = item.signAmount || 0;
                item.contractAmount = (changeTotalAmount + signAmount).toFixed(2);
              }
              this.pageConfig.mainTable.tableData = res.results.records;
              this.pageConfig.mainTable.total = res.results.total;
            } else {
              for (const item in res.results) {
                const changeTotalAmount = item.changeTotalAmount || 0;
                const signAmount = item.signAmount || 0;
                item.contractAmount = (changeTotalAmount + signAmount).toFixed(2);
              }
              this.pageConfig.mainTable.tableData = res.results;
            }
            callBack && callBack();
          } else {
            this.$message.error(this.$t(`exception.${res.errorCode}`));
          }
          this.loading = false;
        }).catch(e => {
          this.loading = false;
        });
      }
    }
  };
</script>

<style scoped lang="scss">
</style>
