/*
 * @Author: your name
 * @Date: 2020-07-30 20:16:47
 * @LastEditTime: 2021-06-03 16:29:25
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web_projectmaterial\src\components\basicComponents\global\dialog\partyBDialog\config.js
 */
import Utils from 'util';

const PageConfig = {
  // 数据字典
  dictionary: [
    {dicCode: 'property', propCode: 'propertyCode'},
    { dicCode: 'appraiseStatus', propCode: 'appraiseStatus' }
  ],
  // 接口数据
  selectList: [],
  // 搜索
  searchControls: {
    // 是否显示
    formShow: true,
    // 搜索使用插槽
    slotFormShow: true,
    // 表单配置
    formList: [
      // 单位名称
      {show: true, label: 'dialog.partyName', prop: 'partyBName', span: 8, formType: 'input', clearable: true, inputStatus: 'edit', maxlength: 128},
      // 单位编号
      {show: true, label: 'dialog.partyCode', prop: 'partyBCode', span: 8, formType: 'input', maxlength: 32, clearable: true, inputStatus: 'edit'},
      // 单位性质
      {show: true, label: 'dialog.propertyCode', prop: 'propertyCode', span: 8, formType: 'dicSelect', clearable: true, inputStatus: 'edit', selectList: []},
      // 经营范围
      {show: true, label: 'dialog.businessScope', prop: 'businessScope', span: 8, formType: 'input', maxlength: 64, clearable: true, inputStatus: 'edit'},
      // 乙方分类
      {show: true, label: 'dialog.partyBTypeName', prop: 'partyBTypeName', span: 8, formType: 'input', maxlength: 64, clearable: true, inputStatus: 'edit'},
      // 收录时间
      {label: 'dialog.createTime', span: 8, formType: 'daterange-split', clearable: true,
            propStart: 'createTimeStart', propEnd: 'createTimeEnd',
            inputStatus: 'edit'}
    ],
    // 是否显示重置按钮
    isReset: true
  },
  // 表格操作按钮
  mainOperateBtn: [],
  isFooterShow: true,
  // 主表渲染参数
  mainTable: {
    //   单选
    isRadio: true,
    // 表格数据
    tableData: [],
    // 表格高度
    maxHeight: 300,
    height: 300,
    pageSize: 10,
    // 页码
    total: 0,
    // 是否显示分页
    paging: true,
    // 表头操作行配置
    tableHeader: {
      showColumnCtrl: true, // 显示/隐藏列
      refresh: false // 刷新
    },
    // 是否默认选中第一行
    defaultSeleFirstLine: false,
    // 子系统表头渲染参数
    tableList: [
      // 单位名称
      {show: true, prop: 'partyBName', label: 'dialog.partyName'},
      // 是否合格
      {
        show: true, prop: 'appraiseStatus', label: 'dialog.appraiseStatus',
        selectList: [],
        formType: 'dicSelect', minWidth: '100'
      },
      // 单位编号
      {show: true, prop: 'partyBCode', label: 'dialog.partyCode', minWidth: '100'},
      // 所属分类
      {show: true, prop: 'partyBTypeName', label: 'dialog.partyTypeName', minWidth: '100'},
      // 单位性质
      {show: true, prop: 'propertyValue', label: 'dialog.propertyValue', minWidth: '100'},
      // 经营范围
      {show: true, prop: 'businessScope', label: 'dialog.businessScope'},
      // 填写人
      {show: true, prop: 'createByName', label: 'fConfig.createByName', minWidth: '100'},
      // 收录日期
      {show: true, filterName: 'date', prop: 'createTime', label: 'dialog.createTime', minWidth: '120'}
    ]
  }
};
class Page {
  constructor() {
    this.PageConfig = JSON.parse(JSON.stringify(PageConfig));
    this.init();
  }
  init () {
    Utils.commonUtil.getSelectList(this.PageConfig.selectList, this);
    Utils.commonUtil.getDicAllDataList(this.PageConfig.dictionary, this);
  }
}
export default Page;
