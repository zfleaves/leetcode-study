<!--
 * @Author: your name
 * @Date: 2020-08-09 10:13:02
 * @LastEditTime: 2022-09-02 18:24:38
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_contract-合同管理\src\components\basicComponents\global\upload\importFile.vue
-->
<template>
  <div
    class="uploadOrgWraHouse" style="display: inline-flex; margin:0 10px;">
    <el-button :disabled="flowStatus" v-fast-click class="more" size="small"
        type="primary" icon="el-icon-folder-opened" @click="setUploadStatus">
        {{$t(parameter.name)}}
    </el-button>
    <div class="imgUrlList">
      <el-upload
        v-if="!flowStatus"
        :action="fileUrl"
        :headers="myHeaders"
        :data="fileName"
        ref="upload"
        :limit="limit"
        :auto-upload="false"
        :file-list="imgUrlList"
        :on-error="handleError"
        :on-change="imgPreview"
        :on-exceed='handleExceed'
        :on-success="handleSuccess"
        :before-upload="beforeAvatarUpload">
        <!-- <el-button :disabled="flowStatus" v-fast-click class="more" size="small" type="primary" icon="el-icon-folder-opened">
          {{$t('button.Import')}}
        </el-button> -->
      </el-upload>
      <!-- <el-button v-else disabled class="more" size="small" type="primary"
                 icon="el-icon-folder-opened">{{$t('button.Import')}}
      </el-button> -->
    </div>
    <!-- 导入获取的物资明细 -->
    <slot v-loading="loadingShow" :dialogImportFlag='dialogImportFlag' :subImportTable='subImportTable'></slot>
  </div>
</template>

<script>
import config from 'util/config';
import Auth from 'util/auth';

export default {
    name: 'importFile',
    data() {
        return {
            fileUrl: config.url,
            myHeaders: {
                'Access-Token': Auth.hasToken(),
                'Access-Domain': 'customer',
                userId: Auth.hasUserInfo().userId,
                tenantId: Auth.hasUserInfo().tenantId,
                Language: Auth.hasLanguage(),
                resource: 'P2'
            },
            fileName: {
                fileName: '',
                subSystemCode: config.subSystemCode,
                projectId: ''
            },
            imgUrlList: [],
            tableData: [],
            dialogImportFlag: false,
            loadingShow: false,
            subImportTable: {}
        };
    },
    props: {
        parameter: {
            type: Object,
            deefault: () => {}
        },
        buttonConfig: {
            type: Object,
            deefault: () => {}
        },
        tableDetailList: {
            type: Array,
            default: () => []
        },
        flowStatus: {
            type: Boolean,
            default: true
        },
        limit: {
            type: Number,
            default: 10
        },
        importUrl: {
            type: String,
            default: ''
        },
        subTable: {
            type: Object,
            deefault: () => {}
        },
        isImportSuccessTips: {
            type: Boolean,
            default: true
        },
        editPage: {},
        projectId: {
            type: Number,
            default: 0
        }
    },
    mounted() {
        this.fileUrl = `${config.url}${this.importUrl}`;
    },
    watch: {
        importUrl: {
            handler() {
                this.fileUrl = `${config.url}${this.importUrl}`;
            },
            deep: true,
            immediate: true
        }
    },
    methods: {
        async setUploadStatus() {
            // console.log(this.projectId, 'this.projectId');
            this.fileName.projectId = this.projectId || '';
            if (this.editPage.canImprotDetail) {
                // 当是否能导入时 需要接口判断 会产生异步判断
                if (this.editPage.isAsync) {
                    const isImport = await this.editPage.canImprotDetail(this.parameter);
                    if (isImport) {
                        this.$refs.upload.$refs['upload-inner'].handleClick();
                    }
                } else if (this.editPage.canImprotDetail(this.parameter)) {
                    this.$refs.upload.$refs['upload-inner'].handleClick();
                }
            }
        },
        // 文件超出个数限制时的钩子
        handleExceed(files, fileList) {
            this.$message.error(this.$t('tips.limitTips'));
        },
        // 文件上传失败
        handleError (err) {
            this.$store.commit('diaLog/set_contentLoading', {status: false, text: ''});
            if (err.status === 401) {
            this.$store.commit('user/SET_OVERDUETOKEN', true);
                return;
            }
            this.$message.error(this.$t('tips.uploadFail'));
        },
        beforeAvatarUpload(file) {
            const isLt5M = file.size / 1024 / 1024 < 50;
            if (!isLt5M) {
               this.$message.error(this.$t('tips.isLt5M'));
            }
            this.fileName.fileName = file.name;
            this.$store.commit('diaLog/set_contentLoading', {status: true, text: ''});
            return isLt5M;
        },
        // 文件预览
        imgPreview(files, fileList) {
            const fileName = files.name;
            const regex = /(.xls|.xlsx)$/;
            if (!regex.test(fileName)) {
                this.$message.error(this.$t('tips.importTips'));
            } else {
                this.dialogImportFlag = true;
                this.loadingShow = true;
                this.$refs.upload.submit();
            }
        },
        handleSuccess(response, file, fileList) {
            if (response.status === 0) {
                if (this.isImportSuccessTips && response.data && response.data.length) {
                    this.$message.success(this.$t('tips.importSuccess'));
                }
                this.subImportTable = this.$clone(this.subTable);
                this.subImportTable.tableData = response.data;
                this.$emit('importData', this.subImportTable);
                this.$refs.upload.clearFiles();
                fileList = [];
            } else {
                if (response.errorCode) {
                    this.$message.error(this.$t(`exception.${response.errorCode}`));
                } else {
                    this.$message.error(response.errorMsg ? response.errorMsg : response.errList[0].errMsg);
                }
                this.dialogImportFlag = false;
            }
            this.loadingShow = false;
            this.$store.commit('diaLog/set_contentLoading', {status: false, text: ''});
        }
    }
};
</script>

<style scoped lang="scss">
  body {
    margin: 0;
  }

  .imgUrlList {
    display: flex;
    justify-content: space-between;
    align-items: center;
    ul {
      border: none;
    }
  }

  .footer {
    display: flex;
    justify-content: space-around;
    align-items: center;
    margin-top: 20px;
  }
</style>
