<template>
  <div class="generalPage">
    <div class="roleCons">
      <div class="content">
        <div class="cons">
          <div class="search_cons" ref="searchCons" v-if="pageConfig.searchControls.formShow">
            <template v-if="pageConfig.searchControls.searchSlotShow">
                <slot name="search" :configForm="pageConfig.searchControls" :isSearch="isSearch"
                    :searchFormValue="pageConfig.searchControls.searchData">
                </slot>
            </template>
            <g-search-form :configForm="pageConfig.searchControls" v-else :isSearch="isSearch"
                          :searchFormValue="pageConfig.searchControls.searchData"
                          :searchData.sync="searchData" v-on="$listeners">
            </g-search-form>
          </div>
          <div class="table_cons">
            <div class="table_cons_table" ref="table_cons">
                <div class="table-fixed-content">
                    <div class="fixed">
                        <div class="table_btn slot_btn" ref="table_btn" v-if="pageConfig.mainOperateBtn.length || pageConfig.mainBtnSlotShow || pageConfig.mainTable.tableHeader.showColumnCtrl">
                            <slot name="mainOperateBtnTips"></slot>
                            <div  v-if="pageConfig.mainBtnSlotShow">
                                <slot name="mainBtnSlot" :pageConfig="pageConfig"></slot>
                            </div>
                            <g-button v-else :operationButtons="pageConfig.mainOperateBtn" @butFnName="mainOperateBtn">
                                <query-table-header
                                :tableHeight="pageConfig.mainTable.maxHeight"
                                :info="pageConfig.mainTable.tableHeader"
                                :columns="pageConfig.mainTable.tableList || []"
                                :customShow="pageConfig.mainTable.customShow"
                                @onColumnChange="onColumnChange"
                                @onRefresh="onRefreshPage"
                                @onFixedColumnChange="onFixedColumnChange"
                                ></query-table-header>
                            </g-button>
                            <slot name="mainOperateBtn"></slot>
                        </div>
                        <div class="table_content" v-loading="loading">
                            <slot name="mainTable" :scope="pageConfig.mainTable"></slot>
                        </div>
                        <div class="table_pages" v-if="pageConfig.mainTable.paging">
                            <g-to-page ref="Page"
                                    :page-sizes="pageConfig.mainTable.pageSizes"
                                    :pager-count="pageConfig.mainTable.pagerCount"
                                    :page-size="pageSize"
                                    :total="pageConfig.mainTable.total"
                                    @sentPages="getPages">
                            </g-to-page>
                        </div>
                        <div class="footer" v-if="pageConfig.isFooterShow">
                            <el-button class="urgent" type="primary" icon="el-icon-circle-close" size="small" @click="handleDialogStatus('close')">{{$t('button.close')}}</el-button>
                            <el-button size="small" type="primary" icon="el-icon-circle-check" @click="handleDialogStatus('save')" v-fast-click>{{$t('button.determine')}}</el-button>
                        </div>
                        <slot name="footer"></slot>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 流程审批弹出框 -->
    <el-dialog v-dialogDrag :title="`${config.subSystemCode === 'oa' ? title : $t(`menu.${this.$route.name}`)}${$t('tips.processSubmission')}`"
        v-if="dialogProcess"
        :top="processName==='sendProcess'?'3vh':'25vh'"
        :width="processName==='sendProcess'?'800px':'400px'"
        center
        :visible.sync="dialogProcess">
      <component
        @closeDialog="handleCloseDialog"
        :is="processName"
        :startForm="sendProcessForm"
        :processSubmitApi="processParmas">
      </component>
    </el-dialog>
    <!-- 打印提示 -->
    <el-dialog
      v-dialogDrag
      :visible.sync="printFlag"
      v-if="printFlag"
      :title="$t('print.printPlugIn')"
      @close='handleClose'
      :close-on-click-modal="false"
      top="25vh" width="70%">
      <div style="height: 300px;padding: 40px;">
        <div style="padding: 40px;">
          <p style="line-height: 40px;" v-for="(item,index) in printStr" :key="index">
            <span style="color: #FF00FF">{{item.title}}</span>
            <el-button
              @click.stop="handleDownload(item)"
              type="text"
              size="small">
              {{item.tips}}
            </el-button>
          </p>
          <p style="line-height: 40px;">
            {{$t('print.restartBrowserAfterDownload')}}
          </p>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {closeRoute} from 'mixins/index';
import config from '@/util/config';

  export default {
    name: 'queryPage',
    mixins: [closeRoute],
    data () {
        return {
            config,
            tableHeaderCon: [],
            pageSize: 10,
            pageNo: 1,
            searchData: {},
            processName: 'sendProcess',
            dialogProcess: false,
            shortMsssage: true,
            assigneeUsersList: [], // 处理人
            copyPersonArr: [], // 抄送人
            selectedUsersList: [], // 选中的人员
            selectedUserDialog: false,
            sendProcessForm: {},
            printFlag: false,
            title: ''
        };
    },
    props: {
        // 配置数据
        pageConfig: {
            type: Object,
            default: () => {
                const parmas = {
                    // 搜索配置
                    searchControls: {},
                    // 操作按钮
                    mainOperateBtn: [],
                    mainTable: {},
                    // 流程提交
                    processParmas: {}
                };
                return parmas;
            }
        },
        // 列表选中的数据
        tableSeleList: {
            type: Array,
            default: () => []
        },
        isSearch: {
            type: Boolean,
            default: true
        },
        // 加载动画
        loading: {
            type: Boolean,
            default: false
        },
        dialogHeight: {
            type: Number,
            default: 300
        }
    },
    created() {
        this.pageSize = this.pageConfig.mainTable.pageSize;
        this.processParmas = this.pageConfig.processParmas;
    },
    computed: {
        printStr() {
            const printStr = this.$store.state.diaLog.printStr || [];
            this.printStrFn(printStr);
            return printStr;
        }
    },
    components: {
        queryTableHeader(resolve) {
            require(['../../table/queryTable/queryTableHeader.vue'], resolve);
        },
        // 提交流程
        sendProcess(resolve) {
            require(['components/basicComponents/process/sendProcess'], resolve);
        },
        // 无流程时提交弹出框
        noProcess(resolve) {
            require(['components/basicComponents/process/noProcess.vue'], resolve);
        }
    },
    mounted () {
        this.$nextTick(() => {
            if (this.config.subSystemCode === 'oa') {
                this.title = this.$route.meta.title;
            }
            const consHeight = this.$refs.table_cons ? this.$refs.table_cons.offsetHeight : 522;
            const searchCons = this.$refs.searchCons ? this.$refs.searchCons.offsetHeight : 0;
            let tableHeight = 0;
            const pagingHeight = this.pageConfig.mainTable.paging ? 60 : 20;
            if (this.pageConfig.isFooterShow) {
                tableHeight = this.dialogHeight - searchCons - 70 - pagingHeight;
            } else {
                tableHeight = consHeight - pagingHeight ;
            }
            if (this.$refs.table_btn) {
                tableHeight = tableHeight - 60;
            }
            this.pageConfig.mainTable.height = this.$clone(tableHeight);
            this.pageConfig.mainTable.maxHeight = this.$clone(tableHeight);
        });
    },
    watch: {
        searchData: {
            handler () {
                this.$emit('searchData', this.searchData);
            },
            deep: true
        }
    },
    methods: {
        // 操作按钮
        mainOperateBtn(fnName) {
            if (fnName === 'sysHandleStartProcess' || fnName === 'sysHandleScenarioFlowSubmit' ||
            fnName === 'noAuthHandleStartProcess' || fnName === 'sysHandleMonitorProcess' || fnName === 'sysHandleScenarioFlowMonitor') {
                this[fnName]();
            } else {
                this.$emit('fnName', fnName);
            }
        },
        // 列的显示与隐藏
        onColumnChange(list) {
            // 将list传出重置 tableList 配置
            this.$emit('resetTableConfigList', list);
        },
        // 刷新 列表数据
        onRefreshPage() {
            this.$emit('onRefresh', true);
        },
        onFixedColumnChange() {
        },
        // 分页
        getPages (obj) {
            if (obj.isSzieChange) {
                this.pageSize = obj.pageSize;
            } else {
                this.pageNo = obj.pageNo;
            }
            this.$emit('pages', {pageSize: this.pageSize, pageNo: this.pageNo});
        },
        // =========== 流程
        // 不判断数据填写人
        noAuthHandleStartProcess() {
            // 判断是否勾选
            if (this.tableSeleList.length === 0) {
                this.$message.warning(this.$t('tips.processTips1'));
                return;
            }
            if (this.tableSeleList.length > 1) {
                // 数据选择过多，请选择一条数据进行处理！
                this.$message.error(this.$t('tips.selectDataTips'));
                return;
            }
            // 判断是否否已提交
            if (this.tableSeleList[0].flowStatus !== '0') {
                this.$message.warning(this.$t('tips.selectDataTips'));
                return;
            }
            // 获取开始流程信息
            const startInfo = this.processParmas.startInfo;
            const nextParmas = {};
            if (startInfo.parmasList && startInfo.parmasList.length) {
                for (const item of startInfo.parmasList) {
                    nextParmas[item.receive] = this.tableSeleList[0][item.value] || '';
                }
            } else {
                nextParmas[startInfo.parmas] = this.tableSeleList[0].id || '';
            }
            this.$store.dispatch(startInfo.url, nextParmas).then(res => {
                this.sendProcessForm = res.results;
                if (this.sendProcessForm.workflowNextNodes === null) {
                    this.processName = 'noProcess';
                } else {
                    this.processName = 'sendProcess';
                }
                // 将当前行存储于缓存中
                localStorage.setItem('dataInfo', JSON.stringify(this.tableSeleList[0]));
                this.dialogProcess = true;
            });
        },
        // 流程提交
        sysHandleStartProcess() {
            // 判断是否勾选
            if (this.tableSeleList.length === 0) {
                this.$message.warning(this.$t('tips.processTips1'));
                return;
            }
            if (this.tableSeleList.length > 1) {
                // 数据选择过多，请选择一条数据进行处理！
                this.$message.error(this.$t('tips.selectDataTips'));
                return;
            }
            // 判断是否本人
            if (this.tableSeleList[0].createBy !== this.$utils.Auth.hasUserInfo().userId) {
                this.$message.warning(this.$t('tips.processTips2'));
                return;
            }
            // 判断是否否已提交
            if (this.tableSeleList[0].flowStatus !== '0') {
                this.$message.warning(this.$t('tips.processTips3'));
                return;
            }
            // 获取开始流程信息
            const startInfo = this.processParmas.startInfo;
            const nextParmas = {};
            if (startInfo.parmasList && startInfo.parmasList.length) {
                for (const item of startInfo.parmasList) {
                    nextParmas[item.receive] = this.tableSeleList[0][item.value] || '';
                }
            } else {
                nextParmas[startInfo.parmas] = this.tableSeleList[0].id || '';
            }
            this.$store.dispatch(startInfo.url, nextParmas).then(res => {
                this.sendProcessForm = res.results;
                if (this.sendProcessForm.workflowNextNodes === null) {
                    this.processName = 'noProcess';
                } else {
                    this.processName = 'sendProcess';
                }
                // 将当前行存储于缓存中
                localStorage.setItem('dataInfo', JSON.stringify(this.tableSeleList[0]));
                this.dialogProcess = true;
            });
        },
        // 事项提交
        sysHandleScenarioFlowSubmit() {
            // 判断是否勾选
            if (this.tableSeleList.length === 0) {
                this.$message.warning(this.$t('tips.processTips1'));
                return;
            }
            if (this.tableSeleList.length > 1) {
                // 数据选择过多，请选择一条数据进行处理！
                this.$message.error(this.$t('tips.selectDataTips'));
                return;
            }
            // 判断是否本人
            if (this.tableSeleList[0].createBy !== this.$utils.Auth.hasUserInfo().userId) {
                this.$message.warning(this.$t('tips.processTips2'));
                return;
            }
            // 判断是否否已提交
            if (this.tableSeleList[0].flowStatus !== '0') {
                this.$message.warning(this.$t('tips.stepProcessTips3'));
                return;
            }
            // 获取开始流程信息
            const startInfo = this.processParmas.startInfo;
            const nextParmas = {};
            if (startInfo.parmasList && startInfo.parmasList.length) {
                for (const item of startInfo.parmasList) {
                    nextParmas[item.receive] = this.tableSeleList[0][item.value] || '';
                }
            } else {
                nextParmas[startInfo.parmas] = this.tableSeleList[0].id || '';
            }
            this.$store.dispatch(startInfo.url, nextParmas).then(res => {
                this.sendProcessForm = res.results;
                if (this.sendProcessForm.workflowNextNodes === null) {
                    this.processName = 'noProcess';
                } else {
                    this.processName = 'sendProcess';
                }
                // 将当前行存储于缓存中
                localStorage.setItem('dataInfo', JSON.stringify(this.tableSeleList[0]));
                this.dialogProcess = true;
            });
        },
        // 流程监控
        sysHandleMonitorProcess() {
            // 判断是否勾选
            if (this.tableSeleList.length === 0) {
                // 请勾选一条数据查看流程审批
                this.$message.warning(this.$t('tips.monitorProcessTips1'));
                return;
            }
            if (this.tableSeleList.length > 1) {
                // 数据选择过多，请选择一条数据进行处理！
                this.$message.error(this.$t('tips.selectDataTips'));
                return;
            }
            // 判断是否否已提交
            if (this.tableSeleList[0].flowStatus === '0') {
                // 该流程未提交
                this.$message.warning(this.$t('tips.monitorProcessTips2'));
                return;
            }
            // 判断是否否已提交
            if (!this.tableSeleList[0].taskId) {
                // 该数据没有流程
                this.$message.warning(this.$t('tips.monitorProcessTips3'));
                return;
            }
            // 将当前行存储于缓存中 是否为场景流程
            localStorage.setItem('processType', this.pageConfig.processType);
            this.$store.commit('diaLog/set_process_dialog', this.tableSeleList[0].taskId);
        },
        // 事项监控
        sysHandleScenarioFlowMonitor() {
            // 判断是否勾选
            if (this.tableSeleList.length === 0) {
                // 请勾选一条数据查看事项审批
                this.$message.warning(this.$t('tips.stepMonitorProcessTips1'));
                return;
            }
            if (this.tableSeleList.length > 1) {
                // 数据选择过多，请选择一条数据进行处理！
                this.$message.error(this.$t('tips.selectDataTips'));
                return;
            }
            // 判断是否否已提交
            if (this.tableSeleList[0].flowStatus === '0') {
                // 该事项未提交
                this.$message.warning(this.$t('tips.stepMonitorProcessTips2'));
                return;
            }
            // 判断是否否已提交
            if (!this.tableSeleList[0].taskId) {
                // 该数据没有事项
                this.$message.warning(this.$t('tips.stepMonitorProcessTips3'));
                return;
            }
            // 将当前行存储于缓存中 是否为场景流程
            localStorage.setItem('processType', this.pageConfig.processType);
            this.$store.commit('diaLog/set_process_dialog', this.tableSeleList[0].taskId);
        },
        // 导出
        sysHandleExport(row) {},
        // 关闭 流程审批弹出框
        handleCloseDialog(status) {
            if (status) {
                this.onRefreshPage();
            }
            localStorage.removeItem('dataInfo');
            this.dialogProcess = false;
        },
        // 弹出框页面按钮
        handleDialogStatus(status) {
            this.$emit('dialogEvent', status);
        },
        printStrFn(printStr) {
            if (printStr.length) {
                this.printFlag = true;
            } else {
                this.printFlag = false;
            }
        },
        // 关闭弹出框
        handleClose() {
            this.$store.commit('diaLog/SET_PRINT_STR');
            this.setRoute();
        },
        // 下载打印插件
        handleDownload(item) {
            const url = item.url;
            const link = document.createElement('a');
            link.style.display = 'none';
            link.href = url;
            document.body.appendChild(link);
            link.click();
            this.$message({
                message: this.$t('print.restartBrowserAfterDownload'),
                type: 'error'
            });
        }
    }
  };
</script>

<style scoped lang="scss">
  @import 'components/basicComponents/styles/generalPage.scss';
</style>
