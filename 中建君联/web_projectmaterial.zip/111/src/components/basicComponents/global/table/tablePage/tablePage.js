export default () => ({
    table: {
      'tooltip-effect': 'light',
      'stripe': true,
      'border': true,
      'resizeable': true,
      'size': 'small'
    }
});
