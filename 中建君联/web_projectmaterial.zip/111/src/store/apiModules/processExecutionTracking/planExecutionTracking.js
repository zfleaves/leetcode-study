
export default {
    // 查询分页
    getPageList: {
        url: '/promaterial/demand/master/main/execute/situation/page',
        method: 'post'
    }
};
