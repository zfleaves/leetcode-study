/*
 * @Author: your name
 * @Date: 2021-05-10 15:12:54
 * @LastEditTime: 2021-05-10 15:29:46
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web_projectmaterial\src\store\apiModules\basic\ruleSetting.js
 */

export default {
    mastercheckEdit: {
      url: '/promaterial/demand/mastercheck/edit',
      method: 'post'
    },
    mastercheckList: {
        url: '/promaterial/demand/mastercheck/list',
        method: 'get'
    }
};
