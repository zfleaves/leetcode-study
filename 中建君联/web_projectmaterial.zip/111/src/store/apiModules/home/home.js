export default {
    // 获取免费子系统
    tenantSubsystem: {
      url: '/backstage/tenant/subsystem/effective',
      method: 'get',
      loading: true,
      loadingText: '加载中...'
    }
};
