/*
 * @Author: your name
 * @Date: 2020-07-24 18:18:27
 * @LastEditTime: 2020-07-25 16:35:36
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web_contract-合同管理\src\views\task\processJump.js
 */
import promaterial from './promaterial';

export default {
    // ----------- 项目材料管理 -promaterial ---------------------
    ...promaterial
};

