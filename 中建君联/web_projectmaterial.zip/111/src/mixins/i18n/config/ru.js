/*
 * @Author: your name
 * @Date: 2021-09-26 10:08:30
 * @LastEditTime: 2021-12-20 14:04:39
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \hdy-translate\src\i18n\config\ru.js
 */
import arLocale from 'element-ui/lib/locale/lang/ru-RU';

const ru = {
    ...arLocale
};
export default ru;
