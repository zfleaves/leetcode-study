/*
 * @Author: your name
 * @Date: 2021-09-26 10:20:15
 * @LastEditTime: 2021-12-20 14:04:38
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \hdy-translate\src\i18n\config\fr.js
 */
import arLocale from 'element-ui/lib/locale/lang/fr';

const fr = {
    ...arLocale
};
export default fr;
