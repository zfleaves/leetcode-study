import viLocale from 'element-ui/lib/locale/lang/vi';

const vn = {
    menu: {
      home: 'Trang chủ'
    },
    errorCode: {
      20001001: 'Lỗi tài khoản hoặc mật khẩu',
      40001005: 'Xác thực mật khẩu không thành công'
    },
    globalData: {
      browserTitle: '',
      currentLanguage: 'Tiếng Việt',
      noData: 'Không có dữ liệu.',
      serialNumber: 'Số sê-ri',
      putItAway: 'Thu gọn',
      open: 'Mở rộng',
      tips: 'Mẹo',
      signOut: 'Thoát',
      exitTheSystem: 'Thoát khỏi hệ thống'
    },
    login: {
      title: 'Chào mừng đến với đám mây',
      logIn: 'Đăng nhập',
      username: 'Số điện thoại/Số tài khoản/Hộp thư',
      usernameErrorTips: 'Số điện thoại/tài khoản/hộp thư không được để trống',
      password: 'Mật khẩu',
      passwordErrorTips: 'Mật khẩu không được để trống',
      rememberPassword: 'Ghi nhớ mật khẩu',
      forgetPassword: 'Quên mật khẩu',
      footer: 'Bản quyền: Zhongjian Junlian (Guangzhou) Software Technology Co., Ltd. | Đề xuất Firefox, Google Browser | ICP chuẩn bị số 18134766'
    },
    ...viLocale
};
export default vn;
