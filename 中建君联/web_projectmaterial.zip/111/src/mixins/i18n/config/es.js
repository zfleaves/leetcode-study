/*
 * @Author: your name
 * @Date: 2021-09-26 10:21:41
 * @LastEditTime: 2021-12-20 14:04:38
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \hdy-translate\src\i18n\config\es.js
 */
import arLocale from 'element-ui/lib/locale/lang/es';

const es = {
    ...arLocale
};
export default es;
