/*
 * @Author: your name
 * @Date: 2021-06-16 16:44:16
 * @LastEditTime: 2023-01-13 12:44:19
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \hdy-translate\src\i18n\config\ar.js
 */
import arLocale from 'element-ui/lib/locale/lang/ar';

const ar = {
    ...arLocale
};
export default ar;
