/*
 * @Author: your name
 * @Date: 2020-06-28 09:08:48
 * @LastEditTime: 2023-02-18 14:21:36
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_basicconfiguration-施工云企业信息及配置\src\filters\index.js
 */
import Utils from 'util';
import Vue from 'vue';
import i18n from '@/mixins/i18n/index.js';

// 设置 完整时间
const setTime = (value) => {
    return value ? Utils.commonUtil.formatTime(value) : '';
};
// 设置 日期
const setDate = (value) => {
    return value ? Utils.commonUtil.formatDate(value) : '';
};
// 数据字典过滤
const setDataItem = (value, arr) => {
    return value ? Utils.commonUtil.getDataItemName(value, arr) : '';
};
// 字段定义
const setStatus = (value) => {
    return value === 0 ? '系统字段' : '自定义字段';
};
// 字段定义
const setMoney = (value, precision) => {
    return value ? Utils.commonUtil.toQfw(value, precision) : value;
};
// 金额大写
const amountInWords = (value) => {
    return Utils.commonUtil.amountInWords(value);
};
// 设置文件名称
const fileNameFilter = (value) => {
    return value ? (value.substr(0, value.lastIndexOf('_')) ? value.substr(0, value.lastIndexOf('_')) : value) : '';
};
// 设置税率
const setTaxRate = value => {
    return value ? Number(value.taxRate.split('%')[0]) : '';
};

const setTaxRateInfo = value => {
    return value ? `${Number(value)}%` : '';
};

const setTaxWarRate = value => {
    return value ? `${Number((Number(value) * 100).toFixed(2))}%` : value === 0 ? '0%' : '';
};
// 根据身份证号码判断男女
const sexIdcardFilter = value => {
    return value ? value.substr(16, 1) % 2 === 1 ? '男' : '女' : '';
};

// 身份证号脱敏('331082199708094687' 转换成 '33108219********87') 第8位开始替换8个
const IDcardHide = num => {
    return num.replace(/(\d{8})\d{8}(\d*)/, '$1********$2');
};
// 手机号脱敏('13912345678' 转换成 '139****5678') 第3位开始替换4个
const telHide = num => {
    return num.replace(/(\d{3})\d{4}(\d*)/, '$1****$2');
};

// 设置地址
const setAddress = val => {
    return val ? val.split('-')[1] : '';
};

// 是否
const whether = val => {
    return val && Number(val) === 1 ? '是' : '否';
};

// 设置周
// 根据日期判断是月的第几周
const getWeekInMonth = t => {
    if (t === undefined || t === '' || t == null) {
        t = new Date();
    } else {
        t = new Date(t);
        const _t = new Date();
        _t.setYear(t.getFullYear());
        _t.setMonth(t.getMonth());
        _t.setDate(t.getDate());
        const date = _t.getDate(); // 给定的日期是几号
        _t.setDate(1);
        const d = _t.getDay(); // 1. 得到当前的1号是星期几。
        let fisrtWeekend = d;
        if (d === 0) {
            fisrtWeekend = 1;
            // 1号就是星期天
        } else {
            fisrtWeekend = 7 - d + 1; // 第一周的周未是几号
        }
        if (date <= fisrtWeekend) {
            return 1;
        } else {
            return 1 + Math.ceil((date - fisrtWeekend) / 7);
        }
    }
};

/**
 * 时间格式化方法
 *
 * @param {(Object|string|number)} time
 * @param {String} cFormat
 * @returns {String | null}
 */
 const parseTime = (time, cFormat) => {
    let date;
    const format = cFormat || '{y}-{m}-{d} {h}:{i}:{s}';

    if (typeof time === 'object') {
      date = time;
    } else {
      if (typeof time === 'string' && /^[0-9]+$/.test(time)) {
        // eslint-disable-next-line radix
        time = parseInt(time);
      }
      if (typeof time === 'number' && time.toString().length === 10) {
        time = time * 1000;
      }

      date = new Date(time.replace(/-/g, '/'));
    }

    const formatObj = {
      y: date.getFullYear(),
      m: date.getMonth() + 1,
      d: date.getDate(),
      h: date.getHours(),
      i: date.getMinutes(),
      s: date.getSeconds(),
      a: date.getDay()
    };

    const timeStr = format.replace(/{([ymdhisa])+}/g, (result, key) => {
      const value = formatObj[key];
      // Note: getDay() returns 0 on Sunday
      if (key === 'a') {
        return ['日', '一', '二', '三', '四', '五', '六'][value];
      }

      return value.toString().padStart(2, '0');
    });

    return timeStr;
};

/**
 * Url 替换超链接
 *
 * @param {String} text 文本
 * @param {String} color 超链接颜色
 */
 const textReplaceLink = (text, color = '#409eff') => {
    // eslint-disable-next-line no-useless-escape
    const exp = /(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/gi;
    return text.replace(
      exp,
      `<a href='$1' target="_blank" style="color:${color};text-decoration: revert;">$1</a >`
    );
};

const systemFilters = (value, row) => {
    // 单选
    if (row.filterName === 'radio') {
        // eslint-disable-next-line eqeqeq
        const index = row.selectList && row.selectList.findIndex(v => v.value == value);
        if (index < 0) return '';
        if (!row.selectList || row.selectList.length === 0) return ;
        return row.isTranslate ? i18n.t(row.selectList[index].label) : row.selectList[index].label;
    }
    // 数据字典
    if (row.filterName === 'dicSelect') {
        const index = row.selectList && row.selectList.findIndex(v => v.dataCode === value);
        if (index < 0) return '';
        if (!row.selectList || row.selectList.length === 0) return ;
        return row.isTranslate ? i18n.t(row.selectList[index].dataName) : row.selectList[index].dataName;
    }
    // 为数组时
    if (value instanceof Array) {
        const values = [];
        value.forEach(item => {
            values.push(item[row.printValue]);
        });
        return values.join(',');
    }
    // 是否
    if (row.filterName === 'whether') {
        return value && Number(value) === 1 ? '是' : '否';
    }
    // 千分位 且
    if (row.filterName === 'setMoney') {
        if (!value) return value;
        return row.precision ? setMoney(Math.round(value * Math.pow(10, row.precision)) / Math.pow(10, row.precision), row.precision) : setMoney(value);
    }
    if (row.filterName === 'number') {
        if (!value) return value;
        return value ? row.precision ? Math.round(value * Math.pow(10, row.precision)) / Math.pow(10, row.precision) : Math.round(value * Math.pow(10, 4)) / Math.pow(10, 4) : value;
    }
    // 附件
    if (row.filterName === 'attachment') {
        if (!value) return;
        return `附件${value.split(',').length}个`;
    }
    // 日期
    if (row.filterName === 'date' || row.formType === 'date' || row.formType === 'changePropDate') {
        return setDate(value);
    }
    // 时间
    if (row.filterName === 'time' || row.formType === 'time' || row.formType === 'changePropTime') {
        return setTime(value);
    }
    // 格式化文件名
    if (row.filterName === 'file') {
        return fileNameFilter(value);
    }
    // 税率
    if (row.filterName === 'taxRate') {
        return setTaxWarRate(value);
    }
    // 周
    if (row.filterName === 'week') {
        const week = getWeekInMonth(value);
        return `${value.substring(0, 4)}年${value.substring(5, 7)}月第${week}周`;
    }
    // 金额大写
    if (row.filterName === 'amountInWords') {
        return amountInWords(value);
    }
    return value;
};

export default {
    setTime,
    setDate,
    setDataItem,
    setTaxRateInfo,
    setTaxWarRate,
    setStatus,
    setMoney,
    fileNameFilter,
    setTaxRate,
    sexIdcardFilter,
    IDcardHide,
    telHide,
    setAddress,
    whether,
    systemFilters,
    parseTime,
    textReplaceLink
};
