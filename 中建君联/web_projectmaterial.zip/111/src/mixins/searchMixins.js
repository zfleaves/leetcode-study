/*
 * @Author: your name
 * @Date: 2020-06-28 09:08:48
 * @LastEditTime: 2023-02-24 09:15:23
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_basicconfiguration-施工云企业信息及配置\src\mixins\searchMixins.js
 */
import Auth from 'util/auth';
import { freshList } from './index';
import { templatePrint } from './templatePrint';

export const search = {
  mixins: [freshList, templatePrint],
  data() {
    return {
      total: 0,
      pageSize: 10,
      pageNo: 1,
      tableHeight: 400,
      loading: false,
      queryLoading: false,
      searchData: {},
      authButtonList: [],
      cloneSearchData: {},
      isMultipleOrgName: false,
      // 关联发票
      dialogSettlementInvoice: false,
      dialogSettlementConfigInvoice: {
          title: this.$t('button.relationInvoice'),
          appendBody: false,
          center: true,
          top: '50px',
          width: '80%',
          span: '0.7'
      },
      selectSettlementInvoiceList: [],
      settlementInvoiceContractId: '',
      settlementInvoiceProjectId: '',
      // 补充发票
      dialogAttachmentVisible: false,
      // 请补充发票
      dialogAttachmentConfig: {
        title: `${this.$t('tips.upload')}${this.$t('button.updateAttachment')}`,
        appendBody: false,
        center: true,
        top: '10%',
        width: '60%',
        span: '0.5'
      },
      // 补充发票附件字段
      projectAttachmentForm: {
        attachment: ''
      },
      mainFormAttachmentConfig: {
          formList: [
            // 附件
            { label: 'fConfig.attachment', prop: 'attachment', span: 24, formType: 'upload', isRule: true }
          ]
      }
    };
  },
  created() {
    this.authButtonList = this.$route.meta.authButtonList && this.$route.meta.authButtonList.map(v => v.resUrl);
    if (this.page) {
      if (this.searchData.flowStatus !== undefined) {
        if (this.searchData.flowStatus === '') {
          this.searchData.flowStatus = [];
        }
      }
      const searchControls = this.page.PageConfig.searchControls;
      // console.log(searchControls, 'searchControls');
      if (searchControls.formList && searchControls.formList.some(v => v.formType === 'multipleProject')) { // 是否有多选项目
        if (!this.searchData.projectIds) {
          this.$set(this.searchData, 'projectIds', []);
        }
      }
      if (searchControls.formList && searchControls.formList.some(v => v.formType === 'multipleOrgName')) { // 是否有多选项目
        this.isMultipleOrgName = true;
        if (!this.searchData.orgList) {
          this.$set(this.searchData, 'orgList', []);
          this.$set(this.searchData, 'orgIds', []);
        }
      }
      // console.log(this.page.PageConfig, 'this.page.PageConfig');
      this.cloneSearchData = this.$clone(this.searchData);
      this.page.PageConfig.mainTable.tableList.forEach(item => {
        this.$set(item, 'fixed', item.fixed || '');
      });
      this.page.PageConfig.mainTable.tableList = this.page.PageConfig.mainTable.tableList.filter(v => {
        const index = this.$utils.config.currencyList.findIndex(r => r === v.prop);
        if (index >= 0) {
          return false;
        } else {
          return true;
        }
      });
      this.pageConfig = this.page.PageConfig;
      this.pageConfig.mainTable.tableData = [];
      this.pageSize = this.pageConfig.mainTable.pageSize ? this.pageConfig.mainTable.pageSize : this.pageSize;
      this.pageConfig.searchControls.searchData = this.searchData;
    }
  },
  activated() {
    if (this.page) {
      this.page.init();
      this.page.PageConfig.mainTable.tableList.forEach(item => {
        this.$set(item, 'fixed', item.fixed || '');
      });
      this.page.PageConfig.mainTable.tableList = this.page.PageConfig.mainTable.tableList.filter(v => {
        const index = this.$utils.config.currencyList.findIndex(r => r === v.prop);
        if (index >= 0) {
          return false;
        } else {
          return true;
        }
      });
      this.pageConfig = this.page.PageConfig;
    }
  },
  mounted() {
    this.$nextTick(() => {
      const consHeight = this.$refs.table_cons ? this.$refs.table_cons.offsetHeight : 522;
      const buttonListHeight = 60; // 按钮高度
      const pageHeight = 60; // 分页高度
      const tableHeight = consHeight - buttonListHeight - pageHeight; // 20 位 padding 高度
      this.tableHeight = tableHeight;
    });
  },
  methods: {
    // 根据url获取数据
    handleGetTableDataList(url, paging = true, callBack) {
      this.loading = true;
      const data = {
        pageNo: this.pageNo,
        pageSize: this.pageSize,
        ...this.pageConfig.searchControls.searchData
      };
      if (this.isMultipleOrgName) { // 如果存在多选项目
        data.orgIds = data.orgList.map(v => v.id);
      }
      this.$store.dispatch(url, data).then(res => {
        if (res.status === 0) {
          if (paging) {
            this.pageConfig.mainTable.tableData = res.results ? res.results.records : [];
            this.pageConfig.mainTable.total = res.results ? res.results.total : 0;
          } else {
            this.pageConfig.mainTable.tableData = res.results ? res.results : [];
          }
          callBack && callBack();
        } else {
          this.$message.error(this.$t(`exception.${res.errorCode}`));
        }
        this.loading = false;
      }).catch(e => {
        this.loading = false;
      });
    },
    // 表格数据字典
    setDicData(value, selectList) {
      const index = selectList && selectList.findIndex(v => v.dataCode === value);
      if (index < 0) return '';
      return selectList[index].dataName;
    },
    // 获取搜索条件
    setSearchForm(parameter) {
      return parameter;
    },
    // 重置搜索条件
    emptyForm(formName) {
      this.$refs[formName].resetFields();
      this.$set(this.pageConfig.searchControls, 'searchData', this.$clone(this.cloneSearchData));
      this.handleSearch();
    },
    // 搜索
    handleSearch() {
      if (this.$refs.Page) {
        this.$refs.Page.setCurrentPage();
      } else {
        this._getTableDataList();
      }
    },
    // 分页
    getPages(obj) {
      if (obj.isSzieChange) {
        this.pageSize = obj.pageSize;
      } else {
        this.pageNo = obj.pageNo;
      }
      this._getTableDataList();
    },
    // 根据函数名调用函数
    setFnName({ fn, row, index }) {
      this[fn](row, index);
    },
    // 勾选
    toggleSelection(rows, formName) {
      if (rows) {
        rows.forEach(row => {
          this.$refs[formName].toggleRowSelection(row, true);
        });
      } else {
        this.$refs[formName].clearSelection();
      }
    },
    // 页面查询按钮
    butFnName(fnName) {
      this[fnName]();
    },
    // 组件查询页面
    // 获取搜索数据
    searchEvent({ eventName, params }) {
      if (eventName === 'multipleOrgName') {
        // console.log(this.pageConfig.searchControls.searchData, 'this.pageConfig.searchControls.searchData');
      }
      if (eventName === 'clear') {
        for (const key in this.cloneSearchData) {
          this.$set(this.pageConfig.searchControls.searchData, key, this.cloneSearchData[key]);
        }
      }
      for (const item of this.pageConfig.searchControls.formList) {
        if (item.formType === 'daterange-split' && item.type !== 'time') {
          const value = this.pageConfig.searchControls.searchData[item.propEnd];
          this.pageConfig.searchControls.searchData[item.propEnd] = value ? value.replace('00:00:00', '23:59:59') : '';
        }
      }
      for (let i = 0; i < this.$children.length; i++) {
        if (this.$children[i].$el && this.$children[i].$el.className === 'generalPage') {
          this.$children[i].$refs.Page && this.$children[i].$refs.Page.setCurrentPage();
        }
      }
      this._getTableDataList();
    },
    getSearchData(searchData) {
      this.pageConfig.searchControls.searchData = searchData;
      this._getTableDataList();
    },
    // 操作按钮
    pageConfigBtnFnName(fnName) {
      this[fnName]();
    },
    // 子表行操作按钮
    pageConfigEmitQueryTableButtonFnName({ row, btnParameter }) {
      if (btnParameter.fn) {
        this[btnParameter.fn](row);
      }
    },
    // 列的显示与隐藏
    pageConfigResetTableConfigList(list) {
      this.pageConfig.mainTable.tableList = JSON.parse(JSON.stringify(list));
    },
    // 刷新
    pageConfigOnRefresh() {
      this._getTableDataList();
    },
    // 分页
    pageConfigPages({ pageSize, pageNo }) {
      this.pageSize = pageSize;
      this.pageNo = pageNo;
      this._getTableDataList();
    },
    // 增、改、查 路由跳转设置
    handleSetRouter(type, row = {}) {
      if (row.id) {
        if (!this.judgeSamePerson(row) && type === 'edit') {
          this.editError(this.$t('button.edit'));
          return;
        }
      }
      const translateType = type;
      type = this.$base64.encode(type);
      const id = this.$base64.encode(row.id || 0);
      const RouteTitleObj = { name: `${this.$route.name}Edit`, loadRouteName: this.$route.name, translateType };
      localStorage.setItem('RouteTitle', JSON.stringify(RouteTitleObj));
      this.$router.push(`/${this.$route.name}Edit/${type}/${id}/${this.$route.name}`);
    },
    // 添加
    sysHandleAdd() {
      this.handleSetRouter('add', {});
    },
    // 修改
    handleEdit(row) {
      this.handleSetRouter('edit', row);
    },
    // 查看
    handleInfo(row) {
      this.handleSetRouter('info', row);
    },
    // 保存数据
    handleSaveData(data) {
      const saveUrl = this.page.PageConfig.processParmas.saveUrl;
      this.$store.dispatch(saveUrl.url, data).then(res => {
        const status = this.type === 'add' ? this.$t('button.add') : this.$t('button.edit');
        if (res.status === 0) {
          this._getTableDataList();
          this.$message.success(`${status}${this.$t('tips.success')}!`);
        } else {
          this.$message.error(`${status}${this.$t('tips.fail')}!`);
        }
      });
    },
    // 流程监控
    sysHandleMonitorProcess(row) { },
    // 禁用/启用
    // statusConfig = {
    //   keyId: 'unitPartyATypeId',
    //   keyName: 'partyATypeName',
    //   row,
    //   api: 'partyAType/partyATypeDisable'
    // }
    setDataStatus(statusConfig) {
      const statusTips = statusConfig.row.status === 0 ? this.$t('button.disable') : this.$t('button.enable');
      const status = statusConfig.row.status === 0 ? 1 : 0;
      this.$confirm(`${statusTips} ${statusConfig.row[statusConfig.keyName]}?`, statusTips, {
        confirmButtonText: this.$t('button.determine'),
        cancelButtonText: this.$t('button.close'),
        type: 'warning'
      })
        .then(() => {
          this.$store.dispatch(statusConfig.api, { [statusConfig.keyId]: statusConfig.row.id, status }).then(res => {
            if (res.status === 0) {
              this._getTableDataList();
              this.$message.success(`${statusTips}${this.$t('tips.success')}!`);
            } else {
              this.$message.error(`${statusTips}${this.$t('tips.fail')}!`);
            }
          });
        })
        .catch(() => { });
    },
    // 删除
    setDataDelete(statusConfig, row) {
      if (!this.judgeSamePerson(row) && statusConfig.isCreate !== false) {
        this.editError(this.$t('button.delete'));
        return;
      }
      this.$confirm(`${this.$t('button.delete')} ${statusConfig.row[statusConfig.keyName]}?`, this.$t('button.delete'), {
        confirmButtonText: this.$t('button.determine'),
        cancelButtonText: this.$t('button.close'),
        type: 'warning'
      })
        .then(() => {
          this.$store.dispatch(statusConfig.api, { [statusConfig.keyId]: statusConfig.row.id }).then(res => {
            if (res.status === 0) {
              this._getTableDataList();
              this.$message.success(`${this.$t('button.delete')}${this.$t('tips.success')}!`);
            } else {
              this.$message.error(`${this.$t(`exception.${res.errorCode}`)}${this.$t('button.delete')}${this.$t('tips.fail')}!`);
            }
          });
        })
        .catch(() => { });
    },
    judgeSamePerson(row) {
      const createBy = row.createBy;
      const userId = Auth.hasUserInfo().userId;
      return createBy === userId;
    },
    editError(key) {
      this.$message({
        message: `${this.$t('tips.notCreatedByMyself')}${key}`,
        type: 'error'
      });
    },
    dialogEvent(event) {
      if (event === 'close') {
        this.$emit('update:close', false);
      } else {
        this.$emit('getData', this.tableSeleList);
      }
    },
    // 导出
    sysHandleExport() {
      if (this.pageConfig.mainTable.tableData.length === 0) return;
      const data = {
        pageNo: this.pageNo,
        pageSize: this.pageSize,
        ...this.pageConfig.searchControls.searchData
      };
      const exportUrl = this.pageConfig.processParmas.exportUrl.url;
      if (!exportUrl) return this.$message.error(this.$t('tips.exportUrlError'));
      this.$store.dispatch(exportUrl, data).then(data => {
        if (!data) return;
        const url = window.URL.createObjectURL(new Blob([data]));
        const link = document.createElement('a');
        link.style.display = 'none';
        link.href = url;
        let fileName = '';
        if (this.$route.name.indexOf('Edit') >= 0) {
          const index = this.$store.state.tagNav.cachedPageList.findIndex(v => v.name === this.$route.name);
          if (index >= 0) {
            const tag = this.$store.state.tagNav.cachedPageList[index];
            fileName = `${this.$t(`menu.${tag.loadRouteName}`)} ${this.$t(`button.${tag.translateType}`)}`;
          } else {
            fileName = `${this.$t(`menu.${this.$route.name}`)}`;
          }
        } else {
          let name = '';
          if (this.$route.meta.isReport) {
            name = `${this.$t(`${this.$route.params.translateName}.${this.$route.params.subTitle}`)}`;
          } else {
            name = `${this.$t(`menu.${this.$route.name}`)}`;
          }
          fileName = name;
        }
        link.setAttribute('download', `${fileName}${this.$t('fConfig.excel')}.xls`);
        document.body.appendChild(link);
        link.click();
      });
    },
    // 导出
    handleExport(url) {
      if (this.pageConfig.mainTable.tableData.length === 0) return;
      const data = {
        pageNo: this.pageNo,
        pageSize: this.pageSize,
        ...this.pageConfig.searchControls.searchData
      };
      this.$store.dispatch(url, data).then(data => {
        if (!data) return;
        const url = window.URL.createObjectURL(new Blob([data]));
        const link = document.createElement('a');
        link.style.display = 'none';
        link.href = url;
        let fileName = '';
        if (this.$route.name.indexOf('Edit') >= 0) {
          const index = this.$store.state.tagNav.cachedPageList.findIndex(v => v.name === this.$route.name);
          if (index >= 0) {
            const tag = this.$store.state.tagNav.cachedPageList[index];
            fileName = `${this.$t(`menu.${tag.loadRouteName}`)} ${this.$t(`button.${tag.translateType}`)}`;
          } else {
            fileName = `${this.$t(`menu.${this.$route.name}`)}`;
          }
        } else {
          fileName = `${this.$t(`menu.${this.$route.name}`)}`;
        }
        link.setAttribute('download', `${fileName}${this.$t('fConfig.excel')}.xls`);
        document.body.appendChild(link);
        link.click();
      });
    },
    // 下载模板
    handleDownloadTemplate(url, templateName) {
      this.$store.dispatch(url).then(data => {
        if (!data) return;
        const url = window.URL.createObjectURL(new Blob([data]));
        const link = document.createElement('a');
        link.style.display = 'none';
        link.href = url;
        link.setAttribute('download', `${this.$t(templateName)}${this.$t('fConfig.excel')}.xls`);
        document.body.appendChild(link);
        link.click();
      });
    },
    // 打印
    sysHandlePrint() {
      if (this.tableSeleList.length === 0) {
        // 请您先选中想要提打印标签的一行数据
        this.$message({
            message: this.$t('print.selePrintLabelTips'),
            type: 'info'
        });
        return;
      }
      if (this.tableSeleList.length > 1) {
          // 数据选择过多，请选择一条数据进行处理！
          this.$message.error(this.$t('tips.selectDataTips'));
          return;
      }
      const row = this.tableSeleList[0];
      const printModelCode = this.$base64.encode(this.pageConfig.formCode);
      const taskId = this.$base64.encode(row.taskId); // 打印
      const id = this.$base64.encode(row.id);
      const RouteTitleObj = { name: 'printDesign', loadRouteName: this.$route.name, translateType: 'print' };
      localStorage.setItem('RouteTitle', JSON.stringify(RouteTitleObj));
      this.$router.push(`/printDesign/${printModelCode}/${taskId}/${id}/${this.$route.name}`);
    },
    // 关联发票
    relationInvoice(row, contractIdKey, selectList) {
      if (!this.judgeSamePerson(row)) {
        this.editError(this.$t('button.relationInvoice'));
        return;
      }
      this.settlementInvoiceContractId = row[contractIdKey];
      this.settlementInvoiceProjectId = row.projectId;
      this.selectSettlementInvoiceList = selectList;
      this.dialogSettlementInvoice = true;
    },
    // ----------------------------- 使用弹出框选择后的一系列赋值操作 -------------------------------
    editFormEvent({ eventName, params }) {
      if (eventName === 'relationTable') {
        this.handleOtherSelect(params);
      }
      if (eventName === 'clearProjcet') {
        this.handleClearProject(params);
      }
      if (eventName === 'projcet') {
        this.handleSelectProject(params);
      }
      if (eventName === 'clearPartyA') {
        this.handleClearPartyA(params);
      }
      if (eventName === 'partyA') {
        this.handleSelectPartyA(params);
      }
      if (eventName === 'clearPartyB') {
        this.handleClearPartyB(params);
      }
      if (eventName === 'partyB') {
        this.handleSelectPartyB(params);
      }
      if (eventName === 'operateFun') {
        this[params.operateFun] && this[params.operateFun](params);
      }
      if (eventName === 'clearUser') { // 清除用户
        this.handleClearUser(params);
      }
      if (eventName === 'user') { // 获取用户
        this.handleSelectUser(params);
      }
      // 所属公司
      if (eventName === 'clearOrg') { // 清除用户
        this.handleClearOrg(params);
      }
      if (eventName === 'org') { // 获取用户
        this.handleSelectOrg(params);
      }
    },
    // 清除项目
    handleClearProject(params) {
      if (params.item && params.item.formType === 'multipleProject') {
        const projectList = this.pageConfig.searchControls.searchData[params.item.prop];
        const projectIdList = this.pageConfig.searchControls.searchData[params.item.key];
        projectList.splice(projectList.indexOf(params.tag), 1);
        projectIdList.splice(projectIdList.indexOf(params.tag.id), 1);
        if (projectIdList.length === 0) {
          this.pageConfig.searchControls.searchData[params.item.key] = null;
        }
        return;
      }
      this.handleSelectProject({ selectList: [], paramsConfig: params });
    },
    // 选择项目
    handleSelectProject(params) {
      if (params.paramsConfig.check) {
        this.handleCheckProject && this.handleCheckProject(params);
        return;
      }
      // 多选项目
      if (params.paramsConfig.formType === 'multipleProject') {
        const selectList = params.selectList;
        const projectId = [];
        const projectName = [];
        if (selectList.length === 0) {
          this.$set(this.pageConfig.searchControls.searchData, params.paramsConfig.prop, []);
          this.$set(this.pageConfig.searchControls.searchData, params.paramsConfig.key, null);
          return;
        }
        for (let i = 0; i < selectList.length; i++) {
          projectId.push(selectList[i].id);
          projectName.push({ projectName: selectList[i].projectName, id: selectList[i].id });
        }
        this.$set(this.pageConfig.searchControls.searchData, params.paramsConfig.prop, projectName);
        this.$set(this.pageConfig.searchControls.searchData, params.paramsConfig.key, projectId);
        // this.$set(this.pageConfig.searchControls.searchData, params.paramsConfig.prop, this.$clone(params.selectList));
        return;
      }
      this.handleSelect(params, 'projectName');
    },
    // ----------------------------- 事业部 -------------------------------
    handleClearOrgName(params) {
      this.handleSelectOrgName({ selectList: [], paramsConfig: params });
    },
    handleSelectOrgName(params) {
      if (params.selectList.length === 0) {
        this.$set(this.pageConfig.searchControls.searchData, params.paramsConfig.prop, null);
        this.$set(this.pageConfig.searchControls.searchData, params.paramsConfig.key, null);
        return;
      }
      this.$set(this.pageConfig.searchControls.searchData, params.paramsConfig.prop, params.selectList[0].orgName);
      this.$set(this.pageConfig.searchControls.searchData, params.paramsConfig.key, params.selectList[0].id);
    },
    // ----------------------------- 甲方单位 -------------------------------
    // 清除甲方单位
    handleClearPartyA(params) {
      this.handleSelectPartyA({ selectList: [], paramsConfig: params });
    },
    // 选择甲方单位
    handleSelectPartyA(params) {
      this.handleSelect(params, 'partyAName');
    },
    // ----------------------------- 乙方单位 -------------------------------
    // 清除甲方单位
    handleClearPartyB(params) {
      this.handleSelectPartyB({ selectList: [], paramsConfig: params });
    },
    // 选择甲方单位
    handleSelectPartyB(params) {
      this.handleSelect(params, 'partyBName');
    },
    // ----------------------------- 员工 ---------------------------------
    // 清除员工
    handleClearUser(params) {
      this.handleSelectUser({ selectList: [], paramsConfig: params });
    },
    // 选择员工
    handleSelectUser(params) {
      this.handleSelect(params, 'userName');
    },
    // =================组织机构====================
    // 选择所属公司
    handleSelectOrg(params) {
      this.handleSelect(params, 'currentOrgName');
    },
    // 清除所属公司
    handleClearOrg(params) {
      this.handleSelectOrg({ selectList: [], paramsConfig: params });
    },
    // 确认选择
    handleSelect(params, displayValue, callback) {
      const arr = params.selectList;
      const item = params.paramsConfig;
      // 关联子表时
      if (item.relationTable && item.relationTable.length) {
        let isTableList = false;
        for (const table of item.relationTable) {
          if (this.pageConfig.subTableConfig[table].tableData.length) {
            isTableList = true;
          }
        }
        if (this.pageConfig.projectForm[item.prop] && isTableList) {
          this.selectChange(item, arr, displayValue, callback);
        } else {
          this.setRelationData(item, arr, displayValue, callback);
        }
      } else {
        this.setRelationData(item, arr, displayValue, callback);
      }
    },

    // 下拉选择框
    handleOtherSelect(params) {
      const arr = params.selectList;
      const item = params.paramsConfig;
      this.setSelectValue(item, this.projectForm[item.prop]);
    },
    // 下拉框联动赋值
    setSelectValue(item, event, cancleFlag = true) {
      if (item.isRelation) {
        item.relationList && item.relationList.forEach(row => {
          let index = 0;
          if (item.formType === 'select') {
            index = item.selectList.findIndex(v => v[item.valueCode] === event);
          } else {
            index = item.selectList.findIndex(v => v.dataCode === event);
          }
          this.$set(this.projectForm, row.receive, item.selectList[index] && item.selectList[index][row.value] || ''); // 显示值
        });
      }
      if (item.otherOperate && cancleFlag) {
        item.otherOperateFun && this[item.otherOperateFun]();
      }
    },
    // 主表联动赋值
    setRelationData(item, arr, displayValue, callback) {
      this.$set(this.projectForm, item.prop, arr.length > 0 ? arr[0][displayValue] : ''); // 显示值
      this.$set(this.projectForm, item.key, arr.length > 0 ? arr[0].id : ''); // 关键值
      if (item.isRelation) {
        item.relationList.forEach(row => {
          if (row.isAddress) {
            // 获取详细地址
            let address = '';
            if (arr.length > 0) {
              const province = arr[0].province && arr[0].province.split('-')[0];
              const city = arr[0].city && arr[0].city.split('-')[0];
              const area = arr[0].area && arr[0].area.split('-')[0];
              address = `${province}${city}${area}`;
            }
            this.$set(this.projectForm, row.receive, arr.length > 0 ? address : ''); // 显示值
          } else if (row.areaCode) {
            // 货取地址代码
            const areas = [];
            const keysList = ['province', 'city', 'area'];
            for (const key of keysList) {
              if (arr[0][key] && arr[0][key].indexOf('-')) {
                const id = arr[0][key].split('-')[1];
                areas.push(id);
              }
              this.$set(this.projectForm, key, arr[0][key] ? arr[0][key] : ''); // 显示值
            }
            this.$set(this.projectForm, row.receive, arr.length > 0 ? areas : ''); // 显示值
          } else {
            let value = '';
            if (arr.length) {
              value = arr[0][row.value] === undefined ? '' : arr[0][row.value];
            } else {
              value = '';
            }
            this.$set(this.projectForm, row.receive, value); // 显示值
          }
        });
      }
      if (item.clearRelation && item.clearRelation.length) {
        this.clearRelationData(item.clearRelation);
      }
      callback && callback();
    },
    // 清除相关连动数据
    clearRelationData(clearList) {
      for (const v of clearList) {
        const index = this.pageConfig.mainFormConfig.formList.findIndex(item => item.prop === v.prop);
        if (index >= 0) {
          this[v.clearFun] && this[v.clearFun](this.pageConfig.mainFormConfig.formList[index]);
        }
      }
    },
    // 合并单元行或者列
    /**
     * @param {*} param0
     * row 当前行的数据
     * column 列的数据
     * rowIndex 行的下标
     * columnIndex 列的下标
     *
     */
    spanMethod({ row, column, rowIndex, columnIndex }) {
      const that = this;
      function objectSpanMethod(row, column, rowIndex, columnIndex) {
        // columnIndex代表列，合并表格
        const newArr1 = that.formatRowspanAndColspan1(
          that.pageConfig.mainTable.tableData,
          'orgName'
        );
        const newArr2 = that.formatRowspanAndColspan2(
          that.pageConfig.mainTable.tableData,
          'projectName'
        );
        // 合并第二列
        if (columnIndex === 1) {
          const num = newArr1[rowIndex].num;
          if (num > 1) {
            return {
              rowspan: num,
              colspan: 1
            };
          } else if (num < 1) {
            return {
              rowspan: 1,
              colspan: num
            };
          } else {
            return {
              rowspan: 1,
              colspan: 1
            };
          }
        }
        // 合并第三列
        if (columnIndex === 2) {
          const num = newArr2[rowIndex].num;
          if (num > 1) {
            return {
              rowspan: num,
              colspan: 1
            };
          } else if (num < 1) {
            return {
              rowspan: 1,
              colspan: num
            };
          } else {
            return {
              rowspan: 1,
              colspan: 1
            };
          }
        }
      }
      return objectSpanMethod(row, column, rowIndex, columnIndex);
    },
    // 过滤重复数组
    formatRowspanAndColspan1(tableData, tableKey) {
      const newArr = [];
      // 分类检出tempList中的数据push到newArr中
      for (let i = 0; i < tableData.length;) {
        let count = 0;
        for (let j = i; j < tableData.length; j++) {
          if (tableKey === 'orgName') {
            if (tableData[i].orgName === tableData[j].orgName) {
              count++;
            }
          }
        }
        if (tableKey === 'orgName') {
          newArr.push({
            data: tableData[i].orgName,
            num: count
          });
        }
        i += count;
      }
      // 根据此算法，格式化newArr中的数据
      for (let k = 0; k < newArr.length; k++) {
        if (newArr[k].num > 1 || newArr[k].num === 0) {
          for (let w = k; w < newArr[k].num + k - 1; w++) {
            newArr.splice(w + 1, 0, {
              data: newArr[k].data,
              num: 0
            });
          }
        }
      }
      return newArr;
    },
    formatRowspanAndColspan2(tableData, tableKey) {
      const newArr = [];
      // 分类检出tempList中的数据push到newArr中
      for (let i = 0; i < tableData.length;) {
        let count = 0;
        for (let j = i; j < tableData.length; j++) {
          if (tableKey === 'projectName') {
            if (tableData[i].projectName === tableData[j].projectName) {
              count++;
            }
          }
        }
        if (tableKey === 'projectName') {
          newArr.push({
            data: tableData[i].projectName,
            num: count
          });
        }
        i += count;
      }
      // 根据此算法，格式化newArr中的数据
      for (let k = 0; k < newArr.length; k++) {
        if (newArr[k].num > 1 || newArr[k].num === 0) {
          for (let w = k; w < newArr[k].num + k - 1; w++) {
            newArr.splice(w + 1, 0, {
              data: newArr[k].data,
              num: 0
            });
          }
        }
      }
      return newArr;
    },
    // ------------------ 补充发票 ---------------------
    // 补充发票
    handleUpdateAttachment(row, idKey, attachmentKey) {
      // 此操作为上传发票附件，上传后不可更改，请务必操作正确。
      if (row.ifAcquireInvoice) {
        return;
      }
      if (!this.judgeSamePerson(row)) {
        this.editError(this.$t('button.updateAttachment'));
        return;
      }
      this.$confirm(this.$t('tips.acquireInvoiceAttachmentTips2'), this.$t('button.updateAttachment'), {
        confirmButtonText: this.$t('button.determine'),
        cancelButtonText: this.$t('button.close'),
        dangerouslyUseHTMLString: true,
        type: 'warning'
      }).then(() => {
        this.$set(this.projectAttachmentForm, idKey, row.id);
        this.$set(this.projectAttachmentForm, 'attachment', row[attachmentKey]);
        this.dialogAttachmentVisible = true;
      }).catch(() => {
      });
    },
    // 补充发票保存
    handleAttachmentSubmit(url) {
      this.$refs.editAttachmentForm.getValidateForm(() => {
        const data = this.$clone(this.projectAttachmentForm);
        this.$store
          .dispatch(url, data)
          .then(res => {
            if (res.status === 0) {
              this.$message.success(`${this.$t('button.updateAttachment')}${this.$t('tips.success')}`);
              this.dialogAttachmentVisible = false;
              this._getTableDataList();
            } else {
              this.$message.error(`${this.$t(`exception.${res.errorCode}`)}`);
            }
          });
      });
    }
  }
};
