/*
 * @Author: Zengfa
 * @Email: 1051403128@qq.com
 * @Date: 2020-05-18 14:42:09
 * @LastEditTime: 2022-11-09 17:40:42
 */
/* eslint-disable */
import Vue from "vue";
import store from 'store';
import config from './config';
import Auth from './auth'
import { Message } from 'element-ui';

const add0 = (m) => {
    return m < 10 ? `0${m}` : m;
};
class CommonUtils {
    // 跳入任务待办页面
    toTask() {
        const url = `${config.jumpUrl}/portal/#/task`;
        window.open(url, '_self');
    }
    // 跳入互动中心
    toInteractionCenter() {
        const url = `${config.jumpUrl}/portal/#/interactionCenter`;
        window.open(url, '_self');
    }
    // 跳入中台登陆页面login
    toLogin() {
        const url = `${config.jumpUrl}/portal/#/${Auth.hasLoginTitle()}`;
        window.open(url, '_self');
    }
    // 跳入中台首页
    toHome() {
        const url = `${config.jumpUrl}/portal/#/home`;
        window.open(url, '_self');
    }
    // 跳入中台首页
    toLinkUrl(url) {
        window.open(url);
    }
    /**
     * @name: 时间补 0
     * @param {Number} key
     */
    // static add0(m) {
    //     return m < 10 ? '0' + m : m
    // }

    /**
     * @name: 时间戳转换未 时分秒格式
     * @param {Number} shijianchuo
     */
    formatTime(shijianchuo) {
        if (!shijianchuo) return '';
        const time = new Date(shijianchuo);
        const y = time.getFullYear();
        const m = time.getMonth() + 1;
        const d = time.getDate();
        const h = time.getHours();
        const mm = time.getMinutes();
        const s = time.getSeconds();
        return `${y}-${add0(m)}-${add0(d)} ${add0(h)}:${add0(mm)}:${add0(s)}`;
    }

    /**
     * @name: 时间戳转换未 日期个
     * @param {Number} shijianchuo
     */
    formatDate(shijianchuo) {
        if (!shijianchuo) return '';
        const time = new Date(shijianchuo);
        const y = time.getFullYear();
        const m = time.getMonth() + 1;
        const d = time.getDate();
        return `${y}-${add0(m)}-${add0(d)}`;
    }

    /**
     * @name: 时间戳转换未 月份
     * @param {Number} shijianchuo
     */
    formatMonth(shijianchuo) {
        const m = shijianchuo.getMonth() + 1;
        const d = shijianchuo.getDate();
        return `${add0(m)}-${add0(d)}`;
    }

    /**
     * @name: 日期格式转时间戳
     * @param {timestamp} 日期格式
     */
    formatTimestamp(timestamp) {
        if (!timestamp) return 0;
        return new Date(timestamp).getTime();
    }

    /**
     * @name: 金钱转千分位
     * @param {Number} n
     */
    toQfw(n, precision) {
        if (n === 0) {
            return '0';
        }
        if (!n) {
            return n;
        }
        if (typeof (n) === 'string') {
            return n;
        }
        // n 50000
        const copyNum = n;
        n = Math.abs(n);
        // Math.abs(-8)
        n = n.toFixed(precision || 2); // 50000.13
        n = Number(n);
        const strN = n.toString(); // '50000.13'
        let num, num1;
        if (strN.indexOf('.') >= 0) {
            num = strN.split('.')[0]; // 12345678
            num1 = strN.split('.')[1]; // '13'
        } else {
            num = strN;
            num1 = '';
        }
        let result = '';
        while (num.length > 3) {
            result = `,${num.slice(-3)}${result}`; // ,345,678
            num = num.slice(0, num.length - 3); // 12
        }
        if (num) { // 12
            if (copyNum >= 0) {
                return num1 ? `${num}${result}.${num1}` : `${num}${result}`; // 12,345,678.13
            } else {
                return num1 ? `-${num}${result}.${num1}` : `-${num}${result}`; // 12,345,678.13
            }
        }
        return 0;
    }

    /**
    * @name: 金钱转大写
    * @param {Number} money
    */
    amountInWords(money) {
        //汉字的数字
        var cnNums = new Array('零', '壹', '贰', '叁', '肆', '伍', '陆', '柒', '捌', '玖');
        //基本单位
        var cnIntRadice = new Array('', '拾', '佰', '仟');
        //对应整数部分扩展单位
        var cnIntUnits = new Array('', '万', '亿', '兆', '京', '垓', '秭');
        //对应小数部分单位
        var cnDecUnits = new Array('角', '分', '毫', '厘');
        //整数金额时后面跟的字符
        var cnInteger = '整';
        //整型完以后的单位
        var cnIntLast = '元';
        //最大处理的数字
        var maxNum = 9999999999999999.9999;
        //金额整数部分
        var integerNum;
        //金额小数部分
        var decimalNum;
        //输出的中文金额字符串
        var chineseStr = '';
        //分离金额后用的数组，预定义
        var parts;
        // 传入的参数为空情况 
        if(money == '') {
            return '';
        }
        money = parseFloat(Number(money))
        if(money > maxNum){
            return ''
        }
        // 传入的参数为0情况 
        if(money == 0) {
            chineseStr = cnNums[0] + cnIntLast + cnInteger;
            return chineseStr
        }
        // 转为字符串
        money = money.toString();
        // indexOf 检测某字符在字符串中首次出现的位置 返回索引值（从0 开始） -1 代表无
        if(money.indexOf('.') == -1){
            integerNum = money;
            decimalNum = ''
        }else{
            parts = money.split('.');
            integerNum = parts[0];
            decimalNum = parts[1].substr(0,4);
        }
        //转换整数部分
        if(parseInt(integerNum, 10) > 0){
            let zeroCount  = 0;
            let IntLen = integerNum.length
            for(let i = 0; i < IntLen; i++){
                let n = integerNum.substr(i,1);
                let p = IntLen - i - 1;
                let q = p / 4;
                let m = p % 4;
                if( n == '0'){
                    zeroCount ++ ;
                }else{
                    if(zeroCount > 0){
                        chineseStr += cnNums[0]
                    }
                    zeroCount = 0;
                    chineseStr += cnNums[parseInt(n)] + cnIntRadice[m];
                }
                if(m == 0 && zeroCount < 4){
                    chineseStr += cnIntUnits[q]; 
                }
            }
            // 最后+ 元
            chineseStr += cnIntLast;
        }
        // 转换小数部分
        if(decimalNum != ''){
            let decLen = decimalNum.length;
            for(let i = 0; i <decLen; i++){
                let n = decimalNum.substr(i,1);
                if(n != '0'){
                    chineseStr += cnNums[Number(n)] + cnDecUnits[i]
                }
            }
        }
        if(chineseStr == ''){
            chineseStr += cnNums[0] + cnIntLast + cnInteger;
        }else if(decimalNum == ''){
            chineseStr += cnInteger;
        }
    
        return chineseStr
    }

    /**
     * @name: 千分位转金钱
     * @param {String} str
     */
    reseveQfw(str) {
        if (!str) {
            return str;
        }
        if (typeof (str) === 'number') {
            return str;
        }
        str = str.split(',').join('');
        str = Number(str);
        return str;
    }

    /**
     * @name: 节流函数
     * @param {Function} func  回调函数
     * @param {Number} delay   延迟时间
     */
    debounce(func, delay) {
        let timer;

        return function (...args) {
            if (timer) {
                clearTimeout(timer);
            }
            timer = setTimeout(() => {
                func.apply(this, args);
            }, delay);
        };
    }

    /**
     * @name: 还原数据仓库数据
     */
    resetVuex() {
        // store.commit('auth/resetAuthData');
        // store.commit('dialog/resetDialogData');
        // store.commit('tagNav/resetTagNavData');
        // store.commit('user/resetUserData');
        // store.commit('tagNav1/resetTagNav1Data');
        store.commit('user/resetUser');
        store.commit('tagNav/resetTagNav');
        store.commit('diaLog/resetDiaLog');
    }

    /**
     * @name: 获取数据字典名称
     * @param {String} val 数据字典编号
     * @param {Array} arr 数据字典列表
     */
    getDataItemName(val, arr) {
        const index = arr.findIndex(v => v.dataValue === val);
        return index >= 0 ? arr[index].dataName : '';
    }

    //
    getCurrentDate() {
        let myDate = new Date();
        let year = myDate.getFullYear(); //年
        let month = myDate.getMonth() + 1; //月
        let day = myDate.getDate(); //日
        let days = myDate.getDay();
        switch (days) {
            case 1:
                days = '星期一';
                break;
            case 2:
                days = '星期二';
                break;
            case 3:
                days = '星期三';
                break;
            case 4:
                days = '星期四';
                break;
            case 5:
                days = '星期五';
                break;
            case 6:
                days = '星期六';
                break;
            case 0:
                days = '星期日';
                break;
        }
        let obj = {
            date: year + "年" + month + "月" + day + "日",
            days
        }
        return obj;
    }
    /** 
     * @name: 页面初始化 获取常用下拉框的值
     * @param {Array} arr
    */
    async getSelectList(arr, _this) {
        for (const i in arr) {
            const item = arr[i];
            await this.getSelectDataList(item, _this);
        }
    }
    getSelectDataList(item, _this) {
        const params = item.params || {};
        store.dispatch(item.fun, params).then(res => {
            if (res.status === 0) {
                this.setFormSearchData(item.code, res.results, _this);
                _this.PageConfig[`${item.code}List`] = res.results;
            } else {
                Message.error(`${res.errorMessage}`);
            }
        });
    }
    setFormSearchData(code, arr, _this) {
        // 编辑页面
        if (_this.PageConfig.mainFormConfig) {
            _this.PageConfig.mainFormConfig.formList.forEach(item => {
                if (item.prop === code) {
                    item.selectList = arr;
                }
            });
        }
        // 搜索页面
        if (_this.PageConfig.searchControls) {
            _this.PageConfig.searchControls.formList.forEach(item => {
                if (item.prop === code) {
                    item.selectList = arr;
                }
            });
        }
    }
    /** 
     * @name: 页面初始化 获取数据字典
     * @param {Array} arr
    */
    async getDicAllDataList(arr, _this) {
        for (const i in arr) {
            const item = arr[i];
            await this.getDataList(item, _this);
        }
    }
    getDataList(item, _this) {
        const index = config.dataList.findIndex(v => v.code === item.dicCode);
        if (index < 0) return;
        const id = config.dataList[index].id;
        this._getDicItemValues(id, item.dicCode, item.propCode, _this);
    }
    _getDicItemValues(id, dicCode, propCode, _this) {
        store.dispatch('publicApi/getDicItemValues', { dicId: id }).then(res => {
            if (dicCode === 'taxRate' || dicCode === 'qualityDepositScale') {
                for (const i in res.results) {
                    const item = res.results[i];
                    item.value = item.dataName.indexOf('%') >= 0 ? Number(item.dataName.split('%')[0]) / 100 : '';
                    item.percentValue = item.dataName.indexOf('%') >= 0 ? Number(item.dataName.split('%')[0]) : '';
                    item.dataCode = Number(item.value.toFixed(4));
                }
            }
            if (dicCode === 'sex') {
                for (const i in res.results) {
                    const item = res.results[i];
                    item.dataCode = item.dataName;
                }
            }
            _this.PageConfig[`${propCode}List`] = res.results;
            this.setDicConfig(propCode, res.results, _this);
        });
    }
    setDicConfig(propCode, res, _this) {
        //   编辑页面主表赋值
        if (_this.PageConfig.mainFormConfig) {
            const index = _this.PageConfig.mainFormConfig.formList.findIndex(v => v.prop === propCode);
            if (index >= 0) {
                _this.PageConfig.mainFormConfig.formList[index].selectList = res;
            }
        }
        // 查询页面 搜索赋值
        if (_this.PageConfig.searchControls) {
            const key = _this.PageConfig.searchControls.formList.findIndex(v => v.prop === propCode);
            if (key >= 0) {
                _this.PageConfig.searchControls.formList[key].selectList = res;
            }
        }
        // 查询页面 表格赋值
        if (_this.PageConfig.mainTable) {
            const indexTable = _this.PageConfig.mainTable.tableList.findIndex(v => v.prop === propCode);
            if (indexTable >= 0) {
                _this.PageConfig.mainTable.tableList[indexTable].selectList = res;
            }
        }
        // 编辑子表格赋值
        if (_this.PageConfig.subTableConfig && _this.PageConfig.subTableMatch) {
            for (const item of _this.PageConfig.subTableMatch) {
                let tableList = _this.PageConfig.subTableConfig[item.assignment].tableList;
                const index = tableList.slaveColumns.findIndex(v => v.prop === propCode);
                if (index >= 0) {
                    Vue.set(tableList.slaveColumns[index], 'selectList', res);
                }
                if (tableList.childrenSlaveColumns) {
                    const index1 = tableList.childrenSlaveColumns.findIndex(v => v.prop === propCode);
                    if (index1 >= 0) {
                        tableList.childrenSlaveColumns[index1].selectList = res;
                    }
                }
            }
            
        }
    }
}

export default CommonUtils;
