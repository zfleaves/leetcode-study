/*
 * @Author: your name
 * @Date: 2021-12-29 16:32:18
 * @LastEditTime: 2022-06-16 17:31:25
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \web_projectprocess\src\mixins\util\processJump.js
 */

import config from './config';
// 往来单位
import unit from './systemProcess/unit';
// 询价管理
import inquire from './systemProcess/inquire';
// 公司收入合同
import contract from './systemProcess/contract';
// 招标管理
import tenders from './systemProcess/tenders';
// 项目材料管理
import promaterial from './systemProcess/promaterial';
// 项目劳务管理
import projectlabour from './systemProcess/projectlabour';
// 项目成本管理
import procost from './systemProcess/procost';
// 项目分包管理
import prosubcontract from './systemProcess/prosubcontract';
// 项目综合管理
import proover from './systemProcess/proover';
// 机械租赁
import promachinery from './systemProcess/promachinery';
// 项目安全云
import prosecurity from './systemProcess/prosecurity';
// 项目质量云
import proquality from './systemProcess/proquality';
// 项目周转材管理
import protmaterials from './systemProcess/protmaterials';
// 项目投标云
import bid from './systemProcess/bid';
// 项目环境管理
import environment from './systemProcess/environment';
// 进度
import proprogress from './systemProcess/proprogress';
// 人力资源云
import personnel from './systemProcess/personnel';
// 行政事务云
import administrative from './systemProcess/administrative';
// 资产云
import assets from './systemProcess/assets';
// 资金云
import capital from './systemProcess/capital';
// 过程云
import proprocess from './systemProcess/proprocess';
// oa
import oa from './systemProcess/oa';
// 供应中心
import supply from './systemProcess/supply';


export default {
    //  ----------- 往来单位 -unit ---------------------
    ...unit,
    //  ----------- 询价管理 -inquire ---------------------
    ...inquire,
    //  ----------- 公司收入合同 -contract ---------------------
    ...contract,
    //  ----------- 招标管理 -contract ---------------------
    ...tenders,
    // ----------- 项目材料管理 -promaterial ---------------------
    ...promaterial,
    // ----------- 项目劳务管理 -projectlabour ---------------------
    ...projectlabour,
    // ----------- 项目成本管理 -projectlabour ---------------------
    ...procost,
    // ----------- 项目分包管理 -projectlabour ---------------------
    ...prosubcontract,
     // ----------- 项目综合管理 -proover ---------------------
     ...proover,
    // ----------- 机械租赁 -promachinery ---------------------
    ...promachinery,
    // ----------- 项目安全云 -prosecurity ---------------------
    ...prosecurity,
    // ----------- 项目质量云 -proquality ---------------------
    ...proquality,
    // ----------- 项目周转材管理 -protmaterials ---------------------
    ...protmaterials,
    // ----------- 项目投标云 -bid ---------------------
    ...bid,
    // ----------- 项目投标云 -environment ---------------------
    ...environment,
    // ------------ 进度 -------------
    ...proprogress,
    // ------------ 人力资源云 -------------
    ...personnel,
    // ------------ 行政事务云 -------------
    ...administrative,
    // ------------ 资产云 ------------
    ...assets,
    // ------------ 资金云 ------------
    ...capital,
    // ------------ 过程云 ------------
    ...proprocess,
    // ------------ oa ------------
    ...oa,
    // ------------ 供应中心 ------------
    ...supply
};
