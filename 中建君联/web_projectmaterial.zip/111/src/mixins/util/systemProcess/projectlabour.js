/*
 * @Author: wumaoxia 1805428335@qq.com
 * @Date: 2021-12-28 15:01:14
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @LastEditTime: 2022-06-08 13:47:35
 * @FilePath: \web_projectlabour\src\mixins\util\systemProcess\projectlabour.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */

import config from 'util/config';

export default {
    //  ----------- 公司收入合同 -contract ---------------------
    // 人工预算清单
    labourBudget: {
        jumpUrl: `${config.jumpUrl}/prolabour/#/processApprovalPage`,
        translateName: 'labourBudget'
    },
    // 人工预算清单变更
    labourBudgetChange: { // labourBudgetChangeDetail
        jumpUrl: `${config.jumpUrl}/prolabour/#/processApprovalPage`,
        translateName: 'labourBudgetChange'
    },
    // 用工申请
    labourWorkerApply: { // labourWorkerPlanDetail
        jumpUrl: `${config.jumpUrl}/prolabour/#/processApprovalPage`,
        translateName: 'labourWorkerApply'
    },
    // 用工计划
    labourWorkerPlan: { // labourWorkerPlanDetail
        jumpUrl: `${config.jumpUrl}/prolabour/#/processApprovalPage`,
        translateName: 'labourWorkerPlan'
    },
    // 点工计划
    labourPointWorkPlan: { // labourPointworkPlanDetail
        jumpUrl: `${config.jumpUrl}/prolabour/#/processApprovalPage`,
        translateName: 'labourPointworkPlan'
    },
    // 点工计划
    labourPointworkPlan: { // labourPointworkPlanDetail
        jumpUrl: `${config.jumpUrl}/prolabour/#/processApprovalPage`,
        translateName: 'labourPointworkPlan'
    },
    // 人员进场
    labourWorkerEntry: { // labourWorkerPlanDetail
        jumpUrl: `${config.jumpUrl}/prolabour/#/processApprovalPage`,
        translateName: 'labourWorkerEntry'
    },
    // 班组排班
    labourWorkSchedule: { // labourWorkScheduleDetail
        jumpUrl: `${config.jumpUrl}/prolabour/#/processApprovalPage`,
        translateName: 'labourWorkSchedule'
    },
    // 培训
    labourCultivate: { // labourCultivateDetail
        jumpUrl: `${config.jumpUrl}/prolabour/#/processApprovalPage`,
        translateName: 'labourCultivate'
    },
    // 人员离场
    labourWorkerLeave: { // labourWorkerLeaveDetail
        jumpUrl: `${config.jumpUrl}/prolabour/#/processApprovalPage`,
        translateName: 'labourWorkerLeave'
    },
    // 班组考勤
    labourTeamAttendance: {
        jumpUrl: `${config.jumpUrl}/prolabour/#/processApprovalPage`,
        translateName: 'labourAttendanceSheet'
    },
    // 班组工资发放
    labourTeamSalary: {
        jumpUrl: `${config.jumpUrl}/prolabour/#/processApprovalPage`,
        translateName: 'labourPayrollStatement'
    },
    // 请假
    labourWorkerVacation: {
        jumpUrl: `${config.jumpUrl}/prolabour/#/processApprovalPage`,
        translateName: 'labourWorkerVacation'
    },
    // 违规
    labourWorkerViolations: {
        jumpUrl: `${config.jumpUrl}/prolabour/#/processApprovalPage`,
        translateName: 'labourWorkerViolations'
    },
    // 点工报销
    labourPointWorkReimburse: { // labourSettlementDetail
        jumpUrl: `${config.jumpUrl}/prolabour/#/processApprovalPage`,
        translateName: 'labourPointworkReimburse'
    },
    // 点工报销
    labourPointworkReimburse: { // labourSettlementDetail
        jumpUrl: `${config.jumpUrl}/prolabour/#/processApprovalPage`,
        translateName: 'labourPointworkReimburse'
    },
    // 劳务结算
    labourSettlement: { // labourSettlementDetail
        jumpUrl: `${config.jumpUrl}/prolabour/#/processApprovalPage`,
        translateName: 'labourSettlement'
    },
    // 劳务支付
    labourPayment: { // labourPaymentDetail
        jumpUrl: `${config.jumpUrl}/prolabour/#/processApprovalPage`,
        translateName: 'labourPayment'
    }
};

