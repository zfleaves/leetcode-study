/*
 * @Author: your name
 * @Date: 2022-04-07 08:56:44
 * @LastEditTime: 2022-04-22 10:26:18
 * @LastEditors: Please set LastEditors
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \web_tenders\src\mixins\util\systemProcess\tenders.js
 */

import config from 'util/config';

export default {
    //  ----------- 招标云 -tenders ---------------------
    // 招标立项
    tBiddingInitiation: {
        jumpUrl: `${config.jumpUrl}/tenders/#/processApprovalPage`,
        translateName: 'biddingInitiation'
    },
    // 招标内容与清单
    tenders: {
        jumpUrl: `${config.jumpUrl}/tenders/#/processApprovalPage`,
        translateName: 'attractTenders'
    },
    // 资审结果通知
    tendersReview: {
        jumpUrl: `${config.jumpUrl}/tenders/#/processApprovalPage`,
        translateName: 'reviewTenders'
    },
    // 发标
    tendersPublish: {
        jumpUrl: `${config.jumpUrl}/tenders/#/processApprovalPage`,
        translateName: 'publishTenders'
    },
    // 设置评标人
    tendersEvaluatePerson: {
        jumpUrl: `${config.jumpUrl}/tenders/#/processApprovalPage`,
        translateName: 'evaluateTenders'
    },
    // 定标报告
    tendersEvaluate: {
        jumpUrl: `${config.jumpUrl}/tenders/#/processApprovalPage`,
        translateName: 'confirmTenders'
    },
    // 定标结果
    tendersConfirm: {
        jumpUrl: `${config.jumpUrl}/tenders/#/processApprovalPage`,
        translateName: 'resultTenders'
    },
    // 退款查看及办理页面
    tendersRefund: {
        jumpUrl: `${config.jumpUrl}/tenders/#/processApprovalPage`,
        translateName: 'refundTenders'
    },
    // 申诉
    tendersAppeal: {
        jumpUrl: `${config.jumpUrl}/tenders/#/processApprovalPage`,
        translateName: 'appealTenders'
    },
     // 招标线下定标登记
    tCalibra: {
        jumpUrl: `${config.jumpUrl}/tenders/#/processApprovalPage`,
        translateName: 'calibrationRegistration'
    },
    // 招标线下定标结果
    tWin: {
        jumpUrl: `${config.jumpUrl}/tenders/#/processApprovalPage`,
        translateName: 'calibrationResults'
    },
    // 评标会报告
    tEvaluateMeetting: {
        jumpUrl: `${config.jumpUrl}/tenders/#/processApprovalPage`,
        translateName: 'evaluateMeetting'
    },
    // 中标通知
    tBidNotice: {
        jumpUrl: `${config.jumpUrl}/tenders/#/processApprovalPage`,
        translateName: 'bidNotice'
    }
};
