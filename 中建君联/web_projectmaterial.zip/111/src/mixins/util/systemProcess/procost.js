/*
 * @Author: your name
 * @Date: 2022-03-09 13:39:42
 * @LastEditTime: 2023-01-06 10:40:14
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \web_projectcost\src\mixins\util\systemProcess\procost.js
 */

import config from 'util/config';

export default {
    //  ----------- 项目成本管理 -procost ---------------------
    // 认质认价表
    enterpriseIdentifyPrice: {
        jumpUrl: `${config.jumpUrl}/procost/#/processApprovalPage`,
        translateName: 'enterpriseIdentifyPrice'
    },
    // 中标工程量清单
    projectBidQuantities: {
        jumpUrl: `${config.jumpUrl}/procost/#/processApprovalPage`,
        translateName: 'projectBidQuantities'
    },
    // 中标工程量清单调整
    projectBidQuantitiesChange: {
        jumpUrl: `${config.jumpUrl}/procost/#/processApprovalPage`,
        translateName: 'projectBidQuantitiesAdjust'
    },
    // 项目成本工程量清单
    projectCostQuantities: { // labourBudgetChangeDetail
        jumpUrl: `${config.jumpUrl}/procost/#/processApprovalPage`,
        translateName: 'projectCostQuantities'
    },
    // 目标工程量清单调整
    projectCostQuantitiesChange: { // labourBudgetChangeDetail
        jumpUrl: `${config.jumpUrl}/procost/#/processApprovalPage`,
        translateName: 'projectCostQuantitiesAdjust'
    },
    // 施工签证
    constructSign: { // labourBudgetChangeDetail
        jumpUrl: `${config.jumpUrl}/procost/#/processApprovalPage`,
        translateName: 'constructSign'
    },
    // 项目现金流策划
    cashFlowPlan: {
        jumpUrl: `${config.jumpUrl}/procost/#/processApprovalPage`,
        translateName: 'cashFlowPlan'
    },
    // 投标报价测算
    enterpriseQuotaCalculate: {
        jumpUrl: `${config.jumpUrl}/procost/#/processApprovalPage`,
        translateName: 'calculationBidPrice'
    },
    // 待分摊费管理
    shareCostManage: {
        jumpUrl: `${config.jumpUrl}/procost/#/processApprovalPage`,
        translateName: 'costShareManager'
    },
    // 管理费分摊
    shareCostExecute: {
        jumpUrl: `${config.jumpUrl}/procost/#/processApprovalPage`,
        translateName: 'costShareExecute'
    },
    // 其他直接费分摊
    oContractShare: {
        jumpUrl: `${config.jumpUrl}/procost/#/processApprovalPage`,
        translateName: 'otherContractShare'
    }
};
