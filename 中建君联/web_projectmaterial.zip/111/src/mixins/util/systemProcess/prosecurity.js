/*
 * @Author: your name
 * @Date: 2021-12-28 15:03:43
 * @LastEditTime: 2021-12-29 10:59:57
 * @LastEditors: your name
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \web_projectsecurity-安环云\src\mixins\util\systemProcess\prosecurity.js
 */

import config from 'util/config';

export default {
    //  ----------- 项目安全云 -prosecurity ---------------------
    // 安全计划
    secutiryPlan: {
        jumpUrl: `${config.jumpUrl}/prosecurity/#/processApprovalPage`,
        translateName: 'safetyPlan'
    },
    // 安全检查
    secutiryInspect: {
        jumpUrl: `${config.jumpUrl}/prosecurity/#/processApprovalPage`,
        translateName: 'safetyCheck'
    },
    // 安全整改
    secutiryRectification: {
        jumpUrl: `${config.jumpUrl}/prosecurity/#/processApprovalPage`,
        translateName: 'safetyRectify'
    },
    // 安全奖励
    secutiryReward: {
        jumpUrl: `${config.jumpUrl}/prosecurity/#/processApprovalPage`,
        translateName: 'safetyReward'
    },
    // 安全处罚
    secutiryPunish: {
        jumpUrl: `${config.jumpUrl}/prosecurity/#/processApprovalPage`,
        translateName: 'safetyPunishment'
    },
    //  安全日志填报
    secLogReport: {
        jumpUrl: `${config.jumpUrl}/prosecurity/#/processApprovalPage`,
        translateName: 'securityLogReport'
    },
    //  安全事故及处理
    secAccidentHandler: {
        jumpUrl: `${config.jumpUrl}/prosecurity/#/processApprovalPage`,
        translateName: 'safetyAccidentsAndHandle'
    }
};
