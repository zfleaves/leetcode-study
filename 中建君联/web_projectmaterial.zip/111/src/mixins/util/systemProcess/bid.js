/*
 * @Author: wumaoxia 1805428335@qq.com
 * @Date: 2022-08-26 09:57:02
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @LastEditTime: 2023-02-09 16:19:40
 * @FilePath: \web_bid\src\mixins\util\systemProcess\bid.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */

import config from 'util/config';

export default {
    //   ============================= 项目投标云 bid=====================================
        // 投标项目登记 bidRegister
        bidRegister: {
            jumpUrl: `${config.jumpUrl}/bid/#/processApprovalPage`,
            translateName: 'biddingProjectRegistration'
        },
        // 投标费用缴纳 bidCostPay
        bidCostPay: {
            jumpUrl: `${config.jumpUrl}/bid/#/processApprovalPage`,
            translateName: 'biddingPayment'
        },
        // 投标费用退回 bidReturn
        bidReturn: {
            jumpUrl: `${config.jumpUrl}/bid/#/processApprovalPage`,
            translateName: 'biddingReturn'
        },
        // 投标文件编制 bidFile
        bidFile: {
            jumpUrl: `${config.jumpUrl}/bid/#/processApprovalPage`,
            translateName: 'biddingDocuments'
        },
        // 项目开标情况 bidOpen
        bidOpen: {
            jumpUrl: `${config.jumpUrl}/bid/#/processApprovalPage`,
            translateName: 'projectBidOpening'
        },
        // 投标资料移交 bidTransfer
        bidTransfer: {
            jumpUrl: `${config.jumpUrl}/bid/#/processApprovalPage`,
            translateName: 'tenderDataTransfer'
        },
        // 新开工联系单 bidStartWork
        bidStartWork: {
            jumpUrl: `${config.jumpUrl}/bid/#/processApprovalPage`,
            translateName: 'newConstructionContact'
        },
        // 商机登记报审
        customerBusinessRegister: {
            jumpUrl: `${config.jumpUrl}/bid/#/processApprovalPage`,
            translateName: 'customersBusinessRegister'
        }
};
