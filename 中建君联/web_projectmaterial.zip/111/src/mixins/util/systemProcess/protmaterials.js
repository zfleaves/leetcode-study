
import config from 'util/config';

export default {
    //  ----------- 项目周转材管理 -protmaterials ---------------------
    // 总预算
    zmcDemandMasterPlan: {
        jumpUrl: `${config.jumpUrl}/protmaterials/#/processApprovalPage`,
        translateName: 'masterPlan'
    },
    // 月
    zmcDemandMonthPlan: {
        jumpUrl: `${config.jumpUrl}/protmaterials/#/processApprovalPage`,
        translateName: 'monthPlan'
    },
    // 临时
    zmcDemandTempPlan: {
        jumpUrl: `${config.jumpUrl}/protmaterials/#/processApprovalPage`,
        translateName: 'tempPlan'
    },
    // 周
    zmcDemandWeekPlan: {
        jumpUrl: `${config.jumpUrl}/protmaterials/#/processApprovalPage`,
        translateName: 'weekPlan'
    },
    // ----------- 采购管理 ---------------------
    // 采购计划
    leasePurchaseApply: {
        jumpUrl: `${config.jumpUrl}/protmaterials/#/processApprovalPage`,
        translateName: 'promaterialPurchaseApply'
    },
    // 零星采购
    leaseSporadicPurchase: {
        jumpUrl: `${config.jumpUrl}/protmaterials/#/processApprovalPage`,
        translateName: 'sporadicPurchase'
    },
    // 合同结算
    leaseSettlement: {
        jumpUrl: `${config.jumpUrl}/protmaterials/#/processApprovalPage`,
        translateName: 'purchaseSettlement'
    },
    // 付款申请
    leasePaymentApply: {
        jumpUrl: `${config.jumpUrl}/protmaterials/#/processApprovalPage`,
        translateName: 'paymentApply'
    },
    // 零星采购报销
    leaseSporadicReimburse: {
        jumpUrl: `${config.jumpUrl}/protmaterials/#/processApprovalPage`,
        translateName: 'sporadicReimburse'
    },
    // ----------- 出入库管理 ---------------------
    // 材料入库
    zlcWarehouseApproach: {
        jumpUrl: `${config.jumpUrl}/protmaterials/#/processApprovalPage`,
        translateName: 'warIncoming'
    },
    // 材料出库
    zlcWarehouseOutbound: {
        jumpUrl: `${config.jumpUrl}/protmaterials/#/processApprovalPage`,
        translateName: 'warOutbound'
    },
    // 领料退回
    zlcWarehouseReturn: {
        jumpUrl: `${config.jumpUrl}/protmaterials/#/processApprovalPage`,
        translateName: 'warReturn'
    },
    // 材料报损
    zlcWarehouseScrap: {
        jumpUrl: `${config.jumpUrl}/protmaterials/#/processApprovalPage`,
        translateName: 'warReportloss'
    },
    // 材料退货
    zlcWarehouseExit: {
        jumpUrl: `${config.jumpUrl}/protmaterials/#/processApprovalPage`,
        translateName: 'warReturngoods'
    }
};
