/*
 * @Author: wumaoxia 1805428335@qq.com
 * @Date: 2022-10-12 17:20:45
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @LastEditTime: 2023-02-22 15:53:25
 * @FilePath: \web_contract\src\mixins\util\systemProcess\contract.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */

import config from '../config';

export default {
    //  ----------- 公司收入合同 -contract ---------------------
    // 收入合同登记
    contractIncomeRegister: {
        jumpUrl: `${config.jumpUrl}/contract/#/processApprovalPage`,
        translateName: 'contractIncomeRegister'
    },
    // 收入合同登记更新
    contractIncomeRegisterAdjust: {
        jumpUrl: `${config.jumpUrl}/contract/#/processApprovalPage`,
        translateName: 'contractIncomeRegisterAdjust'
    },
    // 合同变更/签证
    contractIncomeChange: {
        jumpUrl: `${config.jumpUrl}/contract/#/processApprovalPage`,
        translateName: 'contractIncomeChange'
    },
    // 收入合同进度款申报
    contractIncomeProgressPayment: {
        jumpUrl: `${config.jumpUrl}/contract/#/processApprovalPage`,
        translateName: 'contractIncomePayment'
    },
    // 内部产值报审
    contractIncomeInternalPayment: {
        jumpUrl: `${config.jumpUrl}/contract/#/processApprovalPage`,
        translateName: 'contractIncomeInternalPayment'
    },
    // 收入合同开票
    contractIncomeInvoice: {
        jumpUrl: `${config.jumpUrl}/contract/#/processApprovalPage`,
        translateName: 'contractIncomeInvoice'
    },
     // 收入合同签证
    contractIncomeVisa: {
        jumpUrl: `${config.jumpUrl}/contract/#/processApprovalPage`,
        translateName: 'contractIncomeVisa'
    },
    // 合同收款登记
    contractIncomeCollection: {
        jumpUrl: `${config.jumpUrl}/contract/#/processApprovalPage`,
        translateName: 'contractIncomeCollection'
    },
    // 支出合同登记
    contractExpendRegister: {
        jumpUrl: `${config.jumpUrl}/contract/#/processApprovalPage`,
        translateName: 'contractExpendRegister'
    },
    // 合同评审
    contractExpendReview: {
        jumpUrl: `${config.jumpUrl}/contract/#/processApprovalPage`,
        translateName: 'contractExpendInternalReview'
    },
    // 合同签章
    bestAccountContract: {
        jumpUrl: `${config.jumpUrl}/contract/#/processApprovalPage`,
        translateName: 'contractExpendOnlineSignature'
    },
    // 支出合同变更
    contractExpendChange: {
        jumpUrl: `${config.jumpUrl}/contract/#/processApprovalPage`,
        translateName: 'contractExpendChange'
    },
    // 支出合同收票
    contractExpendInvoice: {
        jumpUrl: `${config.jumpUrl}/contract/#/processApprovalPage`,
        translateName: 'contractExpendInvoice'
    },
    // 支出合同付款
    contractExpendPayment: {
        jumpUrl: `${config.jumpUrl}/contract/#/processApprovalPage`,
        translateName: 'contractExpendPayment'
    },
    // 支出合同结算
    contractExpendSettlement: {
        jumpUrl: `${config.jumpUrl}/contract/#/processApprovalPage`,
        translateName: 'contractExpendSettlement'
    },
    // 支出合同签证
    contractExpendVisa: {
        jumpUrl: `${config.jumpUrl}/contract/#/processApprovalPage`,
        translateName: 'contractExpenditureVisa'
    },
    // 已签合同更新
    contractExpendRegisterAdjust: {
        jumpUrl: `${config.jumpUrl}/contract/#/processApprovalPage`,
        translateName: 'contractExpendRegisterAdjust'
    }
};
