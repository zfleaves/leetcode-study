
import config from 'util/config';

export default {
    //  ----------- 人力资源云 -personnel ---------------------
    // 招聘管理年度招聘计划
    personnelRecruitYearPlan: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'recruitYearPlan'
    },
    // 招聘管理临时招聘计划
    personnelRecruitTempPlan: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'recruitTempPlan'
    },
    // 招聘管理面试信息
    personnelRecruitInterviewRecord: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'recruitInterviewRecord'
    },
    // 人事管理录用审批
    personnelEmployRegister: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'employmentApproval'
    },
    // 人事管理入职登记
    personnelEntryRegister: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'personnelEntryRegister'
    },
    // 人事管理合同签订
    personnelContract: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'personnelContract'
    },
    // 人事管理合同解除
    personnelContractRelieve: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'personnelContractRelieve'
    },
    // 人事管理转正申请
    personnelRegular: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'personnelRegular'
    },
    // 人事管理离职申请
    personnelQuit: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'personnelQuit'
    },
    // 人事管理调岗申请
    personnelPositionAdjust: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'personnelPositionAdjust'
    },
    // 薪资登记
    personnelSalaryRegister: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'salaryRegistration'
    },
    // 人员资证资证登记
    personnelCertificaRegister: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'certificaRegister'
    },
    // 人员资证资证借用
    personnelCertificaUse: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'certificaUse'
    },
    // 人员资证资证归还
    personnelCertificaReturn: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'certificaReturn'
    },
    // 人员资证资证年审
    personnelCertificaAnnual: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'certificaAnnual'
    },
    // 人员资证资证作废
    personnelCertificaCancel: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'certificaCancel'
    },
    // 培训管理培训计划
    personnelTrainPlan: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'trainPlan'
    },
    // 培训管理培训记录
    personnelTrainRecord: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'trainRecord'
    },
    // 培训管理培训反馈
    personnelTrainFeedback: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'trainFeedback'
    },
    // 补卡申请
    cardReplenishmentApplication: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'cardReplenishmentApplication'
    },
    // 请假申请
    personnelVacationApply: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'leaveApplication'
    },
    // 外出申请
    personnelGooutApply: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'attendanceGoout'
    },
    // 加班登记
    personnelOvertimeApply: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'attendanceOvertimeRegister'
    },
    // 绩效考核
    personnelPerformanceAppraisal: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'performanceAppraisal'
    },
    // 社保公积金
    personnelSocialInsurance: {
        jumpUrl: `${config.jumpUrl}/personnel/#/processApprovalPage`,
        translateName: 'securityAndProvidentApplication'
    }
};
