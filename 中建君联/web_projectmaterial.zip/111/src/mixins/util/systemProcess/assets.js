
import config from 'util/config';

export default {
    // 固定资产年度预算上报
    asBudget: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'annualBudgetReport'
    },
    // 固定资产年度预算调整
    asBudgetChange: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'annualBudgetAdjustment'
    },
    // 固定资产年度预算汇总报批
    asBudgetSummary: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'annualBudgetSummary'
    },
    // 固定资产购置申请
    asPurchase: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'purchaseApplication'
    },
    // 固定资产设备安装
    asPurchaseInstall: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'equipmentInstallation'
    },
    // 固定资产采购付款
    asPurchasePayment: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'contractPayment'
    },
    // 固定资产零星采购
    asPurchaseSporadic: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'sporadicPurchase'
    },
    // 固定资产零星采购报销
    asPurchaseSporadicReimburse: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'sporadicReimbursement'
    },
    // 固定资产到货验收
    asPurchaseArrival: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'arrivalAcceptance'
    },
    // 固定资产采购结算
    asPurchaseSettlement: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'contractSettlement'
    },
    // 固定资产资产登记
    asManageIncrease: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'newlyPurchasedAssets'
    },
    // 固定资产其他来源资产登记
    asManageIncreaseTarget: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'otherSourceAssets'
    },
    // 固定资产资产领用
    asManageReceive: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'assetCollection'
    },
    // 资产折旧登记
    asManageDepreciation: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'assetDepreciation'
    },
    // 固定资产资产领用退回
    asManageReturned: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'assetCollectionReturn'
    },
    // 固定资产资产借用
    asManageBorrow: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'assetBorrowing'
    },
    // 固定资产资产归还
    asManageBack: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'assetsReturn'
    },
    // 固定资产资产调出
    asManageTransferOut: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'assetTransferOut'
    },
    // 固定资产资产调入
    asManageTransferIn: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'assetsTransferIn'
    },
    // 	固定资产维保变更
    asMaintenanceChange: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'assetMaintenanceChange'
    },
    // 	固定资产维修
    asMaintenanceRepair: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'assetRepair'
    },
    // 	固定资产保养
    asMaintenanceMaintain: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'assetMaintenance'
    },
    // 	固定资产检定校准
    asMaintenanceCalibration: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'assetVerification'
    },
    // 	固定维保报销
    asMaintenanceReimburse: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'assetExpenseReimbursement'
    },
    // 固定资产常规资产盘点
    asManageInventory: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'assetsInventoryRelease'
    },
    // 固定资产特种资产盘点
    asManageInventorySpecial: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'assetSpecialInventory'
    },
    // 固定资产盘点复核
    asManageInventoryReview: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'assetReviewReport'
    },
    // 	固定资产使用信息变更
    asManageUseChange: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'assetInfoChange'
    },
    // 	固定资产财务信息变更
    asManageFinanceChange: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'assetFinanceInfoChange'
    },
    // 固定资产报废
    asManageScrap: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'assetRetirement'
    },
    // 固定资产损毁
    asManageDamage: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'assetDamage'
    },
    // 固定资产处置
    asManageDispose: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'assetDisposal'
    },
    // 固定资产转让
    asManageTransfer: {
        jumpUrl: `${config.jumpUrl}/assets/#/processApprovalPage`,
        translateName: 'assetTransfer'
    }
};
