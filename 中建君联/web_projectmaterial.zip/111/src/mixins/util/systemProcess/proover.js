/*
 * @Author: wumaoxia 1805428335@qq.com
 * @Date: 2022-06-22 16:31:38
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @LastEditTime: 2022-08-04 17:19:27
 * @FilePath: \web_proover\src\mixins\util\systemProcess\proover.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */

import config from 'util/config';

export default {
   //  ----------- 项目综合管理 -proover ---------------------
    // 其他策划
    otherMasterPlan: {
        jumpUrl: `${config.jumpUrl}/proover/#/processApprovalPage`,
        translateName: 'otherMasterPlan'
    },
    // 直接策划
    otherMasterPlanOther: {
        jumpUrl: `${config.jumpUrl}/proover/#/processApprovalPage`,
        translateName: 'otherMasterPlanOther'
    },
    // 其它合同支付
    oPayment: {
        jumpUrl: `${config.jumpUrl}/proover/#/processApprovalPage`,
        translateName: 'otherContractPay'
    },
    // 其它合同结算
    oContractSettlement: {
        jumpUrl: `${config.jumpUrl}/proover/#/processApprovalPage`,
        translateName: 'otherContractSettlement'
    },
    // 其它费用结算
    oOtherSettlement: {
        jumpUrl: `${config.jumpUrl}/proover/#/processApprovalPage`,
        translateName: 'otherCostSettlement'
    },
    // 其它费用报销
    oReimburse: {
        jumpUrl: `${config.jumpUrl}/proover/#/processApprovalPage`,
        translateName: 'otherCostReimburse'
    },
    // 项目备用金申请
    oFundApply: {
        jumpUrl: `${config.jumpUrl}/proover/#/processApprovalPage`,
        translateName: 'fundApply'
    },
    // 项目备用金报销
    oFundReimburse: {
        jumpUrl: `${config.jumpUrl}/proover/#/processApprovalPage`,
        translateName: 'fundReimburse'
    },
    // 直接报销
    oReimburseOther: {
        jumpUrl: `${config.jumpUrl}/proover/#/processApprovalPage`,
        translateName: 'otherCostReimburseDirectFree'
    },
    // 其他直接费申请
    directExpensesApply: {
        jumpUrl: `${config.jumpUrl}/proover/#/processApprovalPage`,
        translateName: 'directExpensesApply'
    },
    // 合同支付
    oPaymentOther: {
        jumpUrl: `${config.jumpUrl}/proover/#/processApprovalPage`,
        translateName: 'otherContractPayDirectFree'
    },
    // 合同结算
    oContractSettlementOther: {
        jumpUrl: `${config.jumpUrl}/proover/#/processApprovalPage`,
        translateName: 'otherContractSettlementDirectFree'
    }
};
