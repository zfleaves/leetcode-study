/*
 * @Author: wumaoxia 1805428335@qq.com
 * @Date: 2021-12-16 15:52:09
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @LastEditTime: 2022-06-22 10:26:51
 * @FilePath: \web_projectsubcontract\src\mixins\util\systemProcess\prosubcontract.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */

import config from 'util/config';

export default {
    //  ----------- 分包管理 -prosubcontract ---------------------
    // 分包执行策划
    scMasterPlan: {
        jumpUrl: `${config.jumpUrl}/prosubcontract/#/processApprovalPage`,
        translateName: 'scMasterPlan'
    },
    // 实施申请
    scImplementApply: {
        jumpUrl: `${config.jumpUrl}/prosubcontract/#/processApprovalPage`,
        translateName: 'scImplementApply'
    },
    // 分包计划
    scSubcontract: {
        jumpUrl: `${config.jumpUrl}/prosubcontract/#/processApprovalPage`,
        translateName: 'scSubcontract'
    },
    // 进度填报
    scSchedule: { // labourBudgetChangeDetail
        jumpUrl: `${config.jumpUrl}/prosubcontract/#/processApprovalPage`,
        translateName: 'scSchedule'
    },
    // 违规管理
    scViolations: { // labourWorkerPlanDetail
        jumpUrl: `${config.jumpUrl}/prosubcontract/#/processApprovalPage`,
        translateName: 'scViolations'
    },
    // 竣工验收
    scAcceptance: { // labourWorkScheduleDetail
        jumpUrl: `${config.jumpUrl}/prosubcontract/#/processApprovalPage`,
        translateName: 'scAcceptance'
    },
    // 分包结算
    scSettlement: { // labourWorkScheduleDetail
        jumpUrl: `${config.jumpUrl}/prosubcontract/#/processApprovalPage`,
        translateName: 'scSettlement'
    },
    // 分包报销
    scSubcontractReimburse: { // labourWorkScheduleDetail
        jumpUrl: `${config.jumpUrl}/prosubcontract/#/processApprovalPage`,
        translateName: 'scReimburse'
    },
    // 分包支付
    scPayment: { // labourCultivateDetail
        jumpUrl: `${config.jumpUrl}/prosubcontract/#/processApprovalPage`,
        translateName: 'scPayment'
    },
    // 零星分包申请
    scSporadicSubcontract: {
        jumpUrl: `${config.jumpUrl}/prosubcontract/#/processApprovalPage`,
        translateName: 'scSporadicApply'
    }
};
