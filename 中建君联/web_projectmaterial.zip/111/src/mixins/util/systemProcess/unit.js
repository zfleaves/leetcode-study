
import config from 'util/config';

export default {
    //  ----------- 往来单位 -unit ---------------------
    // 甲方信息
    partyA: {
        jumpUrl: `${config.jumpUrl}/unit/#/processApprovalPage`,
        translateName: 'partyAInfo'
    },
    // 甲方变更
    partyAChange: {
        jumpUrl: `${config.jumpUrl}/unit/#/processApprovalPage`,
        translateName: 'partyAChange'
    },
    // 乙方
    partyB: {
        jumpUrl: `${config.jumpUrl}/unit/#/processApprovalPage`,
        translateName: 'partyBInfo'
    },
    // 乙方变更
    partyBChange: {
        jumpUrl: `${config.jumpUrl}/unit/#/processApprovalPage`,
        translateName: 'partyBChange'
    },
    // 乙方评价
    partyAEvaluate: {
        jumpUrl: `${config.jumpUrl}/unit/#/processApprovalPage`,
        translateName: 'partyBEvaluate'
    },
    // 乙方考核
    partyAExamination: {
        jumpUrl: `${config.jumpUrl}/unit/#/processApprovalPage`,
        translateName: 'partyBEexamination'
    }
};
