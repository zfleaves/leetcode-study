/*
 * @Author: wumaoxia 1805428335@qq.com
 * @Date: 2021-12-15 10:18:42
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @LastEditTime: 2023-01-03 11:06:01
 * @FilePath: \web_capital\src\mixins\util\systemProcess\capital.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */

import config from 'util/config';

export default {
    //  ----------- 收入 ---------------------
    capitalBusinessIncome: {
        jumpUrl: `${config.jumpUrl}/capital/#/processApprovalPage`,
        translateName: 'otherIncome'
    },
    capitalBusinessIncomeProject: {
        jumpUrl: `${config.jumpUrl}/capital/#/processApprovalPage`,
        translateName: 'otherProjectIncome'
    },
    // 支出
    capitalBusinessExpenses: {
        jumpUrl: `${config.jumpUrl}/capital/#/processApprovalPage`,
        translateName: 'otherExpenses'
    },
    capitalBusinessExpensesProject: {
        jumpUrl: `${config.jumpUrl}/capital/#/processApprovalPage`,
        translateName: 'otherExpensesProject'
    },
    // 资金计划上报
    capitalPlanReport: {
        jumpUrl: `${config.jumpUrl}/capital/#/processApprovalPage`,
        translateName: 'capitalPlanReport'
    },
    // 月度资金
    capitalMonthPlanReport: {
        jumpUrl: `${config.jumpUrl}/capital/#/processApprovalPage`,
        translateName: 'monthlyFundReport'
    }
};
