
import config from 'util/config';

export default {
    //  ----------- 项目进度云 -proprogress ---------------------
    // 月
    progressBulildlogapply: {
        jumpUrl: `${config.jumpUrl}/proprogress/#/processApprovalPage`,
        translateName: 'buildLogApply'
    },
    progressBulildlogOtherapply: {
        jumpUrl: `${config.jumpUrl}/proprogress/#/processApprovalPage`,
        translateName: 'buildLogOther'
    },
    progressImageWork: {
        jumpUrl: `${config.jumpUrl}/proprogress/#/processApprovalPage`,
        translateName: 'imageProgressWork'
    },
    progressImageOther: {
        jumpUrl: `${config.jumpUrl}/proprogress/#/processApprovalPage`,
        translateName: 'imageProgressOther'
    },
    progressInspectRegister: {
        jumpUrl: `${config.jumpUrl}/proprogress/#/processApprovalPage`,
        translateName: 'inspectRegister'
    },
    progressMasterPlan: {
        jumpUrl: `${config.jumpUrl}/proprogress/#/processApprovalPage`,
        translateName: 'demMasterPlan'
    },
    progressMasterPlanAdjust: {
        jumpUrl: `${config.jumpUrl}/proprogress/#/processApprovalPage`,
        translateName: 'demMasterPlanAdjust'
    },
    // 月计划
    progressMonthPlan: {
        jumpUrl: `${config.jumpUrl}/proprogress/#/processApprovalPage`,
        translateName: 'demMonthPlan'
    },
    progressMonthPlanAdjust: {
        jumpUrl: `${config.jumpUrl}/proprogress/#/processApprovalPage`,
        translateName: 'demMonthPlanAdjust'
    },
    progressMonthProgressReport: {
        jumpUrl: `${config.jumpUrl}/proprogress/#/processApprovalPage`,
        translateName: 'demMonthprogressReport'
    },
    // 周计划
    progressWeekPlan: {
        jumpUrl: `${config.jumpUrl}/proprogress/#/processApprovalPage`,
        translateName: 'demWeekPlan'
    },
    progressWeekProgressReport: {
        jumpUrl: `${config.jumpUrl}/proprogress/#/processApprovalPage`,
        translateName: 'demWeekprogressReport'
    },
    // 工期
    progressDurationriskRegister: {
        jumpUrl: `${config.jumpUrl}/proprogress/#/processApprovalPage`,
        translateName: 'durationRiskRegister'
    },
    // 报告
    progressInspectReport: {
        jumpUrl: `${config.jumpUrl}/proprogress/#/processApprovalPage`,
        translateName: 'inspectReport'
    },
    // 里程碑上报
    proMilepostReport: {
        jumpUrl: `${config.jumpUrl}/proprogress/#/processApprovalPage`,
        translateName: 'milestoneCompletionReport'
    }
};
