
import config from 'util/config';

export default {
    // 会议纪要单
    meetingMinutesRecord: {
        jumpUrl: `${config.jumpUrl}/oa/#/processApprovalPage`,
        translateName: 'meetingMinutes'
    },
    // 协调沟通单
    makeCompromisesRecord: {
        jumpUrl: `${config.jumpUrl}/oa/#/processApprovalPage`,
        translateName: 'coordinationSheet'
    }
};
