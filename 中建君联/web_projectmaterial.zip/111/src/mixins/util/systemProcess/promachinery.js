
import config from 'util/config';

export default {
    //  ----------- 项目机械管理 -promachinery ---------------------
    //  ----------- 机械 ---------------------
    // 施工总预算
    zlDemandMasterPlan: {
        jumpUrl: `${config.jumpUrl}/promachinery/#/processApprovalPage`,
        translateName: 'masterPlan'
    },
    // 调整
    zlDemandMasterPlanAdjust: {
        jumpUrl: `${config.jumpUrl}/promachinery/#/processApprovalPage`,
        translateName: 'masterPlanAdjust'
    },
    // 月
    zlDemandMonthPlan: {
        jumpUrl: `${config.jumpUrl}/promachinery/#/processApprovalPage`,
        translateName: 'monthPlan'
    },
    // 临时
    zlDemandTempPlan: {
        jumpUrl: `${config.jumpUrl}/promachinery/#/processApprovalPage`,
        translateName: 'tempPlan'
    },
    // 周
    zlDemandWeekPlan: {
        jumpUrl: `${config.jumpUrl}/promachinery/#/processApprovalPage`,
        translateName: 'weekPlan'
    },
    // ----------- 租赁管理 ---------------------
    // 申请
    machineryLeaseApply: {
        jumpUrl: `${config.jumpUrl}/promachinery/#/processApprovalPage`,
        translateName: 'promachineryPurchaseApply'
    },
    // 临时租赁
    machineryTempLease: {
        jumpUrl: `${config.jumpUrl}/promachinery/#/processApprovalPage`,
        translateName: 'sporadicPurchase'
    },
    // 合同结算
    machineryLeaseSettlement: {
        jumpUrl: `${config.jumpUrl}/promachinery/#/processApprovalPage`,
        translateName: 'purchaseSettlement'
    },
    // 付款申请
    machineryLeasePayment: {
        jumpUrl: `${config.jumpUrl}/promachinery/#/processApprovalPage`,
        translateName: 'paymentApply'
    },
    // 报销
    machineryLeaseReimburse: {
        jumpUrl: `${config.jumpUrl}/promachinery/#/processApprovalPage`,
        translateName: 'sporadicReimburse'
    },
    // ----------- 机械管理 ---------------------
    // 进场
    machineryApproachApply: {
        jumpUrl: `${config.jumpUrl}/promachinery/#/processApprovalPage`,
        translateName: 'approach'
    },
    // 退场
    machineryExitApply: {
        jumpUrl: `${config.jumpUrl}/promachinery/#/processApprovalPage`,
        translateName: 'exit'
    },
    // 维修
    machineryMaintenance: {
        jumpUrl: `${config.jumpUrl}/promachinery/#/processApprovalPage`,
        translateName: 'repair'
    },
    // 保养
    machineryMaintain: {
        jumpUrl: `${config.jumpUrl}/promachinery/#/processApprovalPage`,
        translateName: 'maintain'
    },
    // 验收
    machineryInstallAccepter: {
        jumpUrl: `${config.jumpUrl}/promachinery/#/processApprovalPage`,
        translateName: 'installation'
    },
    // 特种作业人员
    specialOperatorsRegister: {
        jumpUrl: `${config.jumpUrl}/promachinery/#/processApprovalPage`,
        translateName: 'specialOperatorsRegister'
    },
    // 运行登记
    machineryRunningRegister: {
        jumpUrl: `${config.jumpUrl}/promachinery/#/processApprovalPage`,
        translateName: 'runningRegister'
    },
    // 其他过程资料
    machineryProcessFiles: {
        jumpUrl: `${config.jumpUrl}/promachinery/#/processApprovalPage`,
        translateName: 'processfiles'
    },
    // ----------- 分包方机械管理 ---------------------
    // 机械进场
    subcontractMachineryEnter: {
        jumpUrl: `${config.jumpUrl}/promachinery/#/processApprovalPage`,
        translateName: 'mechanicalApproach'
    },
    // 机械退场
    subcontractMachineryExit: {
        jumpUrl: `${config.jumpUrl}/promachinery/#/processApprovalPage`,
        translateName: 'mechanicalExits'
    }
};
