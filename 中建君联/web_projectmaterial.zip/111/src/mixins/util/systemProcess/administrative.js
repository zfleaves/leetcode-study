
import config from 'util/config';

export default {
    //  ----------- 行政事务云 -administrative ---------------------
    // 信息管理
    // 收文管理
    adDocReceive: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'recordManagement'
    },
    // 发文管理
    adDocSend: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'postManagement'
    },
    // 消息通知
    adMessage: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'announcement'
    },
    // 新闻管理
    adNews: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'newsManagement'
    },
    // 印章管理
    // 刻印申请
    adSealEngrave: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'printsBeforeApplying'
    },
    // 印章登记
    adSealRegister: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'sealRegistration'
    },
    // 借印申请
    adSealBorrow: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'printApply'
    },
    // 用印申请
    adSealUse: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'usingApplication'
    },
    // 印章销毁
    adSealDestroy: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'sealDestruction'
    },
    // 文件管理
    // 文件登记
    adFileRegister: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'fileRegistration'
    },
    // 外借登记
    adFileBorrow: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'fileCheckRegistration'
    },
    // 归还登记
    adFileBack: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'fileReturnRegistration'
    },
    // 借阅登记
    adFileRead: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'referApply'
    },
    // 车辆管理
    // 车辆登记
    adCarRegister: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'vehicleRegistration'
    },
    // 用车申请
    adCarUseApply: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'vehicleApplication'
    },
    // 车辆外借
    adCarBorrow: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'carCheckRegistration'
    },
    // 车辆归还
    adCarBack: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'carReturnRegistration'
    },
    // 车辆保险
    adCarInsurance: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'automobileInsurance'
    },
    // 车辆维修
    adCarRepair: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'maintenanceRequest'
    },
    // 车辆年审
    adCarAnnual: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'annualVehicleInspection'
    },
    // 费用登记
    adCarCost: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'costRegistration'
    },
    // 车辆保养
    adCarMaintain: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'vehicleMaintenance'
    },
    // 车辆转让
    adCarTransfer: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'vehicleTransfer'
    },
    // 车辆报废
    adCarScrap: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'vehicleScrapping'
    },
    // 办公用品管理
    // 采购申请
    adMaterialPurchase: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'purchaseRequest'
    },
    // 新购物品登记
    adMaterialRegister: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'registerNewPurchases'
    },
    // 领用登记
    adMaterialConsume: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'recipientsRegister'
    },
    // 报损登记
    adMaterialLoss: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'reportedLossRegistration'
    },
    // 借用登记
    adMaterialBorrow: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'borrowRegistration'
    },
    // 归还登记
    adMaterialBack: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'returnRegistration'
    },
    // 费用登记
    adMaterialCost: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'feeRegistration'
    },
    // 出差申请
    adBusinessTravel: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'syntheticBusinesstrave'
    },
    // 差旅费报销
    travelExpensesReimburse: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'travelReimburse'
    },
    // 其他费用报销
    otherExpensesReimburse: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'otherReimburse'
    },
    // 借款申请
    adLoanApply: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'loan'
    },
    // 还款登记
    adRepaymentApply: {
        jumpUrl: `${config.jumpUrl}/administrative/#/processApprovalPage`,
        translateName: 'repayment'
    }
};
