/*
 * @Author: your name
 * @Date: 2020-07-24 18:12:37
 * @LastEditTime: 2022-08-31 18:06:18
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_contract-合同管理\src\views\task\contract.js
 */
import config from 'util/config';

export default {
    // 方案设计
    schemeDesign: {
        jumpUrl: `${config.jumpUrl}/proprocess/#/processApprovalPage`,
        translateName: 'conceptualDesign'
    },
    // 施工图设计
    constructionDesign: {
        jumpUrl: `${config.jumpUrl}/proprocess/#/processApprovalPage`,
        translateName: 'constructionDrawingDesign'
    },
    // 施工图设计变更
    constructionDesignAdjust: {
        jumpUrl: `${config.jumpUrl}/proprocess/#/processApprovalPage`,
        translateName: 'constructionDrawingDesignChange'
    },
    // 加工图设计
    machiningDrawingDesign: {
        jumpUrl: `${config.jumpUrl}/proprocess/#/processApprovalPage`,
        translateName: 'machiningDrawingDesign'
    },
    // 加工图设计变更
    machiningDrawingDesignAdjust: {
        jumpUrl: `${config.jumpUrl}/proprocess/#/processApprovalPage`,
        translateName: 'machiningDrawingDesignChange'
    },
    // 材料选样设计
    materialSamplingDesign: {
        jumpUrl: `${config.jumpUrl}/proprocess/#/processApprovalPage`,
        translateName: 'materialSamplingDesign'
    },
    // 材料选样设计变更
    materialSamplingDesignAdjust: {
        jumpUrl: `${config.jumpUrl}/proprocess/#/processApprovalPage`,
        translateName: 'materialSamplingDesignChange'
    },
    // 项目经理月报
    promanagerMonthReport: {
        jumpUrl: `${config.jumpUrl}/proprocess/#/processApprovalPage`,
        translateName: 'monthlyReport'
    },
    // 项目经理周报
    promanagerWeekReport: {
        jumpUrl: `${config.jumpUrl}/proprocess/#/processApprovalPage`,
        translateName: 'weekly'
    },
    // 施工组织设计报审
    buildOrganizationDesign: {
        jumpUrl: `${config.jumpUrl}/proprocess/#/processApprovalPage`,
        translateName: 'buildOrganizationDesign'
    },
    // 超危大工程施工方案报审
    buildDangerousDesign: {
        jumpUrl: `${config.jumpUrl}/proprocess/#/processApprovalPage`,
        translateName: 'buildDangerousDesign'
    },
    // 主体结构验收
    buildMainStructureCheck: {
        jumpUrl: `${config.jumpUrl}/proprocess/#/processApprovalPage`,
        translateName: 'buildMainStructureCheck'
    },
    // 竣工初验
    buildCompleteFirstCheck: {
        jumpUrl: `${config.jumpUrl}/proprocess/#/processApprovalPage`,
        translateName: 'buildCompleteFirstCheck'
    },
    // 处置方案报审
    buildDisposalDesign: {
        jumpUrl: `${config.jumpUrl}/proprocess/#/processApprovalPage`,
        translateName: 'buildDisposalDesign'
    },
    // 现场处置跟督
    buildSceneHandler: {
        jumpUrl: `${config.jumpUrl}/proprocess/#/processApprovalPage`,
        translateName: 'buildSceneHandler'
    },
    // 工作联系函
    workContactLetter: {
        jumpUrl: `${config.jumpUrl}/proprocess/#/processApprovalPage`,
        translateName: 'workContactLetter'
    },
    // 竣工验收
    completionAcceptance: {
        jumpUrl: `${config.jumpUrl}/proprocess/#/processApprovalPage`,
        translateName: 'completionAcceptance'
    },
    // 技术交底
    technicalDesignDisclosure: {
        jumpUrl: `${config.jumpUrl}/proprocess/#/processApprovalPage`,
        translateName: 'designTechnicalDisclosure'
    },
    // 技术交底变更
    technicalDesignDisclosureAdjust: {
        jumpUrl: `${config.jumpUrl}/proprocess/#/processApprovalPage`,
        translateName: 'designChangeNotice'
    }
};
