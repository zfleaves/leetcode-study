/*
 * @Author: wumaoxia 1805428335@qq.com
 * @Date: 2022-05-07 13:49:05
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @LastEditTime: 2022-05-07 18:51:55
 * @FilePath: \web_portale:\project\CC\web_projectmaterial\src\mixins\util\systemProcess\proquality.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */

import config from 'util/config';

export default {
     //  ----------- 项目质量云 -proquality ---------------------
    // 质量计划
    qualityPlan: {
        jumpUrl: `${config.jumpUrl}/proquality/#/processApprovalPage`,
        translateName: 'safetyPlan'
    },
    // 质量检查
    qualityInspect: {
        jumpUrl: `${config.jumpUrl}/proquality/#/processApprovalPage`,
        translateName: 'safetyCheck'
    },
    // 质量整改
    qualityRectification: {
        jumpUrl: `${config.jumpUrl}/proquality/#/processApprovalPage`,
        translateName: 'safetyRectify'
    },
    // 质量奖励
    qualityReward: {
        jumpUrl: `${config.jumpUrl}/proquality/#/processApprovalPage`,
        translateName: 'safetyReward'
    },
    // 质量处罚
    qualityPunish: {
        jumpUrl: `${config.jumpUrl}/proquality/#/processApprovalPage`,
        translateName: 'safetyPunishment'
    },
    // 质量事故及处理
    quaAccidentHandler: {
        jumpUrl: `${config.jumpUrl}/proquality/#/processApprovalPage`,
        translateName: 'qualityAccidentsAndHandle'
    },
    //  质量日志填报
    quaLogReport: {
        jumpUrl: `${config.jumpUrl}/proquality/#/processApprovalPage`,
        translateName: 'securityLogReport'
    }
};
