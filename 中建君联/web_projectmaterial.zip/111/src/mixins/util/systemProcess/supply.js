/*
 * @Author: your name
 * @Date: 2020-07-24 18:12:37
 * @LastEditTime: 2023-02-23 10:24:30
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_contract-合同管理\src\views\task\contract.js
 */
import config from 'util/config';

export default {
    // ----------- 出入库管理 ---------------------
    // 材料入库
    warIncoming: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'warIncoming'
    },
    // 材料出库
    warOutbound: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'warOutbound'
    },
    // 领料退回
    warReturn: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'warReturn'
    },
    // 材料退货
    warReturngoods: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'warReturngoods'
    },
    // 材料报损
    warReportloss: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'warReportloss'
    },
    // 盘点
    warInventory: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'warInventory'
    },
    // 项目材料成本核算
    warProjectCostAccount: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'costAccountingSheet'
    },

    // ----------- 加工管理 ---------------------
    // BOM设置
    proBom: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'BOMSet'
    },
     // 加工任务下达
    proTaskRelease: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'taskRelease'
    },
    // 加工任务完成上报
    proTaskFinished: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'taskFinished'
    },
    // 加工任务发货
    proDeliverGoods: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'deliverGoods'
    },
    // 项目加工核算单
    proProjectAccount: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'processingAccountingDocument'
    },
    // ------------------------- 周转料租赁管理 ------------------------
    // 需求申请
    purDemandPlan: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'purDemandPlan'
    },
    // 采购方案报审
    purSchemeApproval: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'promaterialPurchaseApply'
    },

    // 采购合同结算
    purSettlement: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'purchaseSettlement'
    },
    // 采购合同支付
    purPaymentApply: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'paymentApply'
    },

    // 退货登记
    purReturngoods: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'purReturngoods'
    },

    // 零星采购申请
    purSporadicPurchase: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'sporadicPurchase'
    },
    // 零星采购报销
    purSporadicReimburse: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'sporadicReimburse'
    },
    // -------------------------机械设备登记 ------------------------
    // 机械设备登记
    machApproach: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'machApproach'
    },

    // 机械设备出场
    machExit: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'machExit'
    },

    // 机械设备返场
    machReturn: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'machReturn'
    },

    // 机械设备保养
    machMaintain: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'machMaintain'
    },

    // 机械设备维修
    machRepair: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'machRepair'
    },
    // 机械成本核算
    machProjectAccount: {
        jumpUrl: `${config.jumpUrl}/supply/#/processApprovalPage`,
        translateName: 'machProjectAccount'
    }
};
