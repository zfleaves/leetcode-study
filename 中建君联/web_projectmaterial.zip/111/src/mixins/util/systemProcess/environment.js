
import config from 'util/config';

export default {
    // =============================  环境管理目标=====================================
    //  环境管理目标
    secutiryEnvanagerTarget: {
        jumpUrl: `${config.jumpUrl}/prosecurity/#/processApprovalPage`,
        translateName: 'enTarget'
    },
    // 环境管理风险
    secutiryEnvanagerRish: {
        jumpUrl: `${config.jumpUrl}/prosecurity/#/processApprovalPage`,
        translateName: 'enRisk'
    },
     // ============================= 检查与整改=====================================
     // 环境管理计划
    secutiryEnvironmentPlan: {
        jumpUrl: `${config.jumpUrl}/prosecurity/#/processApprovalPage`,
        translateName: 'environmentPlan'
    },
    // 环境检查结果
    secutiryEnvironmentInspect: {
        jumpUrl: `${config.jumpUrl}/prosecurity/#/processApprovalPage`,
        translateName: 'environmentCheck'
    },
    // 检查结果整改
    secutiryEnvRectification: {
        jumpUrl: `${config.jumpUrl}/prosecurity/#/processApprovalPage`,
        translateName: 'environmentRectify'
    },
    // =============================  环境数据监测=====================================
    //  监测数据录入
    secutiryEnvMonitorData: {
        jumpUrl: `${config.jumpUrl}/prosecurity/#/processApprovalPage`,
        translateName: 'enDataEntry'
    }
};
