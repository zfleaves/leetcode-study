/*
 * @Author: your name
 * @Date: 2022-04-13 09:21:28
 * @LastEditTime: 2022-04-22 10:50:49
 * @LastEditors: your name
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \web_inquire\src\mixins\util\systemProcess\inquire.js
 */

import config from 'util/config';

export default {
    //  ----------- 往来单位 -inquire ---------------------
    // 询价内容
    inquiryBid: {
        jumpUrl: `${config.jumpUrl}/inquire/#/processApprovalPage`,
        translateName: 'inquiryContent'
    },
    // 线上询价定标内审
    inquiryBidReport: {
        jumpUrl: `${config.jumpUrl}/inquire/#/processApprovalPage`,
        translateName: 'biddingConfirm'
    },
    // 询价定标通知
    inquiryBidResult: {
        jumpUrl: `${config.jumpUrl}/inquire/#/processApprovalPage`,
        translateName: 'report'
    },
    // 询价定标公式
    inquiryBiddingConfirm: {
        jumpUrl: `${config.jumpUrl}/inquire/#/processApprovalPage`,
        translateName: 'result'
    },
    // 询价记录/物资表
    inquireMaterial: {
        jumpUrl: `${config.jumpUrl}/inquire/#/processApprovalPage`,
        translateName: 'inquiryRecordAndMaterialList'
    },
    // 询价记录/供应商表
    inquireVendor: {
        jumpUrl: `${config.jumpUrl}/inquire/#/processApprovalPage`,
        translateName: 'inquiryRecordSupplierList'
    },
    // 询价定标登记
    inquireCalibra: {
        jumpUrl: `${config.jumpUrl}/inquire/#/processApprovalPage`,
        translateName: 'inquiryAndCalibrationRegistration'
     },
    // 询价定标结果
    inquireWin: {
        jumpUrl: `${config.jumpUrl}/inquire/#/processApprovalPage`,
        translateName: 'inquiryAndCalibrationResults'
    }
};
