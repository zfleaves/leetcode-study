/*
 * @Author: your name
 * @Date: 2020-06-28 09:08:48
 * @LastEditTime: 2022-07-12 10:05:40
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_basicconfiguration-施工云企业信息及配置\src\util\config.js
 */
// 线下 测试 URL
// import personConfig from 'personSetting/config';
import personConfig from '@/util/config';
import OSS from 'ali-oss';

const TestUrl = 'http://121.196.105.62:8087'; // 测试
// const TestUrl = 'http://47.114.95.78:8087'; // 测试
// const TestUrl = 'http://192.168.1.30:8087'; // 测试 liu
// const TestUrl = 'https://api.junnysoft.com'; // 生产

const websocketUrl = '47.99.160.255:1031'; // websocket-测试
// const websocketUrl = 'im.junnysoft.com'; // websocket-生产
// import { fileDownloadList, fileDownload } from "api/fileInfo/fileInfo";


const ossClient = new OSS({
  endpoint: 'http://oss-cn-hangzhou.aliyuncs.com',
  // yourregion填写Bucket所在地域。以华东1（杭州）为例，Region填写为oss-cn-hangzhou。
  region: 'oss-cn-hangzhou',
  // 阿里云账号AccessKey拥有所有API的访问权限，风险很高。强烈建议您创建并使用RAM用户进行API访问或日常运维，请登录RAM控制台创建RAM用户。
  accessKeyId: 'LTAIaosct3SSvffM',
  accessKeySecret: 'q9CIjrFqepkWfsJDmYAGUoNWV155hC',
  // 填写Bucket名称。关于Bucket名称命名规范的更多信息，请参见Bucket。
  bucket: 'junnysoftfile',
  secure: true
});
const releaseUrl = TestUrl; // 发布
const Config = {
    url: releaseUrl,
    websocketUrl,
    ossClient,
    jumpUrl: 'http://121.196.105.62:8800',
    // 预览 Url
    fileViewerUrl: 'http://47.111.190.80:8060/onlinePreview?url=',
    // oss预览
    ossFileViewerUrl: 'https://static.junnysoft.cn/',
    // 微软预览
    officeappsFileViewerUrl: 'http://view.officeapps.live.com/op/view.aspx?src=',
    // 外部链接url
    linksUrl: 'http://121.196.105.62:8090/projectBasic/?tenantId=',
    // 后台文件上传 用户logo 用户头像 签名
    fileUrl: `${releaseUrl}/basic/file/backstage/upload`,
    // 租户文件上传 用于业务
    fileTenantUrl: `${releaseUrl}/basic/file/tenant/upload`,
    // 文件下载
    fileCmsUrl: `${releaseUrl}/basic/file/download?fileId=`,
    // 文件预览
    fileViewUrl: `${releaseUrl}/basic/file/view?fileId=`,
    // 图片预览
    imageUrl: 'https://static.junnysoft.cn/',
    // 系统名称
    subSystemCode: personConfig.subSystemCode || '',
    // 基础系统
    basicSystemCode: 'basic',
    // 菜单
    pageMenuCode: 'menu',
    // 数据字典
    dataList: personConfig.dataList || [],
    // 币种隐藏字段
    currencyList: ['currencyCode', 'currencyValue', 'currencyPropertyType', 'currencyPropertyName']
    // dataList: [
    //     {name: '项目类型', id: 12, code: 'projectTypeCode'},
    //     {name: '项目状态', id: 13, code: 'projectStatus'},
    //     {name: '流程状态', id: 14, code: 'flowStatus'},
    //     {name: '季度需求', id: 15, code: 'seasonStatus'},
    //     {name: '采购供应方式', id: 16, code: 'curementStatus'},
    //     {name: '采购订单类型', id: 17, code: 'orderType'},
    //     {name: '合同类型', id: 18, code: 'contractType'},
    //     {name: '标评方法', id: 19, code: 'tenderingStatus'},
    //     {name: '开标结果', id: 20, code: 'bidResult'},
    //     {name: '付款类型', id: 21, code: 'payType'},
    //     {name: '单位性质', id: 22, code: 'property'},
    //     {name: '供应商等级', id: 23, code: 'level'},
    //     {name: '是否合格', id: 24, code: 'appraiseStatus'},
    //     {name: '评价等级', id: 25, code: 'appraiseLevels'},
    //     {name: '资质', id: 26, code: 'qualifications'},
    //     {name: '许可', id: 27, code: 'permit'},
    //     {name: '产品质量', id: 28, code: 'productQuality'},
    //     {name: '用户反馈意见', id: 29, code: 'reputation'},
    //     {name: '生产/供货能力', id: 30, code: 'throughputEvaluation'},
    //     {name: '产品价格', id: 31, code: 'productPriceEvaluation'},
    //     {name: '产品价格', id: 32, code: 'productQualityEvaluation'},
    //     {name: '业绩/信誉', id: 33, code: 'reputationEvaluation'},
    //     {name: '服务水平', id: 34, code: 'serviceEvaluation'},
    //     {name: '税率（%）', id: 35, code: 'taxRate'},
    //     {name: '计税方式', id: 36, code: 'taxMethod'},
    //     {name: '发票类型', id: 37, code: 'invoiceType'},
    //     {name: '支付方式', id: 38, code: 'payMethodType'},
    //     {name: '费用类型', id: 39, code: 'costType'},
    //     {name: '盘亏原因', id: 41, code: 'reasonType'},
    //     {name: '租赁类型', id: 43, code: 'supplyMethodLease'},
    //     {name: '结算类型', id: 44, code: 'settleType'},
    //     {name: '租赁合同类型', id: 45, code: 'contractTypeLease'},
    //     {name: '周期类型', id: 46, code: 'cycleType'},
    //     {name: '保养级别', id: 47, code: 'careLevel'},
    //     {name: '维修级别', id: 48, code: 'repairLevel'},
    //     {name: '作业类别', id: 49, code: 'workType'},
    //     {name: '工程属性', id: 50, code: 'attribute'},
    //     {name: '消息类型', id: 51, code: 'messageType'},
    //     {name: '供货订单状态', id: 52, code: 'supperStatus'},
    //     {name: '运输方式', id: 53, code: 'arrivalMethod'},
    //     {name: '计量规则', id: 54, code: 'calcRules'},
    //     {name: '结算方式', id: 55, code: 'sellteMethod'},
    //     {name: '任职状态', id: 62, code: 'officeStatus'},
    //     {name: '角色类型', id: 63, code: 'rolesType'},
    //     {name: '变更事项', id: 64, code: 'changeMatter'},
    //     {name: '纳税人类型', id: 65, code: 'taxPayerType'},
    //     {name: '开具类型', id: 66, code: 'billingType'},
    //     {name: '标签', id: 67, code: 'tagCode'},
    //     {name: '发标状态', id: 68, code: 'biddingStatus'},
    //     {name: '回标有效性', id: 69, code: 'returnBidding'},
    //     {name: '询价类型', id: 70, code: 'inquireType'},
    //     {name: '币种', id: 71, code: 'currencyType'},
    //     {name: '分类性质', id: 73, code: 'classifyPropertyType'},
    //     {name: '是否需要开票', id: 74, code: 'isInvoice'},
    //     {name: '申报类型', id: 75, code: 'declareCode'},
    //     {name: '收款方式', id: 76, code: 'collectionMethodCode'},
    //     {name: '执行状态', id: 77, code: 'executionStatus'},
    //     {name: '计价方式', id: 78, code: 'valuationCode'},
    //     {name: '合同性质', id: 89, code: 'contractNatureCode'},
    //     {name: '质保金比例(%)', id: 103, code: 'qualityDepositScale'}
    // ]
    // this.$message.error(this.$t(`exception.${res.errorCode}`));

};

export default Config;


