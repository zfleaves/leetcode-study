/*
 * @Author: your name
 * @Date: 2020-07-08 18:35:05
 * @LastEditTime: 2023-01-03 09:54:27
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_basicconfiguration\src\promission.js
 */
/* eslint-disable */
import Vue from 'vue';
import Router from 'vue-router';
import router from 'router';
import store from 'store';
import Auth from 'util/auth';
import NProgress from "nprogress";
import 'nprogress/nprogress.css'
import Utils from 'util';
import whiteList from 'router/whiteList.js';
import Layout from 'views/lyout/index.vue'; // Layout 是架构组件，不在后台返回，在文件里单独引入
import Error404 from 'views/error/404.vue';
import i18n from '@/mixins/i18n/index.js';
import '@/mixins/modifyElemntUI/index.js' // 引入 修改 element 自定义配置 JS
import { constantRouterMap } from 'router/index.js'; // 自己配置的静态路由

const _import = require(`router/_import_${process.env.NODE_ENV}`); // 获取组件的方法

let basicLanguageFlag = false;
let pageLanguageFlag = false;
let loadingSubmit = null;

Vue.prototype.$websock = (value = {}) => {
  let websock = null;
  // 判断当前浏览器是否支持WebSocket
  if ('WebSocket' in window) {
      // 建立连接
      const userId = Auth.hasUserInfo().userId;
      const token = Auth.hasUserInfo().token;
      const tenantId = Auth.hasUserInfo().tenantId;
      websock = new WebSocket(`ws://${Utils.config.websocketUrl}/websocket/${tenantId}/${userId}/${token}`);
  } else {
      // 当前浏览器 不支持WebSocket 无法进行系统通知
      Message({
        message: '当前浏览器 不支持WebSocket 无法进行系统通知',
        type: 'error'
      });
  }
  return websock
}

const buttonList = [];
const language = Utils.storage.get('language') || 'zh';
let getRouter; // 用来获取后台拿到的路由
// 404 路由
const error = [{
  path: '*',
  name: 'Error404',
  component: Error404,
}];

// 路由拦截

router.beforeEach((to, from, next) => {
  // 开启进度条
  NProgress.start();
  if (Auth.hasToken()) {
    // 如果当前处于登录状态，并且跳转地址为login，则自动跳回系统首页
    // 这种情况出现在手动修改地址栏地址时
    if (to.path === `/${Auth.hasLoginTitle()}`) {
      next({ path: '/home', replace: true });
    } else if (to.path.indexOf('/error') >= 0) {
      // 防止因重定向到error页面造成beforeEach死循环
      next();
    } else {
      // next();
      const hasRouter = store.state.user.hasRouter;
      if (!hasRouter) { // 不加这个判断，路由会陷入死循环
        if (Auth.hasMenuRouter().length === 0) { // 没有获取菜单
          store.dispatch('publicApi/tokenCheckLoginPublic', { t: Auth.hasToken(), u: Auth.hasUserInfo().userId, d: 'customer', r: 'P2' }).then(ret => {
            if (!ret.results) {
              store.dispatch('login/getsubSystemMenus', { subSystemCode: Utils.config.subSystemCode }).then(res => {
                if (res.results && res.results.length > 0) {
                  getRouter = res.results;
                } else {
                  getRouter = [];
                }
                setRouter(getRouter);
                Auth.setMenuRouter(getRouter); // 存储路由到localStorage
                store.commit('user/set_hasRouter'); // 设置已存在缓存路由
                routerGo(to, next);
              }).catch(e => {
                console.log(e, 'e');
                Utils.commonUtil.resetVuex(); // 清楚store数据
                Auth.reLogin();
                // Utils.commonUtil.toLogin();
                next({ path: `/${Auth.hasLoginTitle()}`, replace: true });
              });
            } else {
              Utils.commonUtil.resetVuex(); // 清除数据仓库
              Auth.reLogin();
              // next({path: '/login', replace: true});
              // Utils.commonUtil.toLogin();
              next({ path: `/${Auth.hasLoginTitle()}`, replace: true });
            }
          }).catch(e => {
            Utils.commonUtil.resetVuex(); // 清除数据仓库
            Auth.reLogin();
            next({ path: `/${Auth.hasLoginTitle()}`, replace: true });
          })
        } else { // 从localStorage拿到了路由
          store.dispatch('publicApi/tokenCheckLoginPublic', { t: Auth.hasToken(), u: Auth.hasUserInfo().userId, d: 'customer', r: 'P2' }).then(res => {
            if (!res.results) {
              getRouter = Auth.hasMenuRouter(); // 拿到路由
              store.commit('user/set_hasRouter'); // 设置已存在缓存路由
              routerGo(to, next);
            } else {
              Utils.commonUtil.resetVuex(); // 清除数据仓库
              Auth.reLogin();
              // next({path: '/login', replace: true});
              // Utils.commonUtil.toLogin();
              next({ path: `/${Auth.hasLoginTitle()}`, replace: true });
            }
          }).catch(e => {
            Utils.commonUtil.resetVuex(); // 清除数据仓库
            Auth.reLogin();
            next({ path: `/${Auth.hasLoginTitle()}`, replace: true });
          })
        }
      } else {
        setMenuLanguage(to, next);
        /*
        *  获取当前页面的权限按钮菜单
        *  获取上一个页面的路由
        */
        // const authButtonList = Utils.menu.getCurrentButton(to.name);
        // if (authButtonList && authButtonList.length) {
        //   to.meta.authButtonList = JSON.parse(JSON.stringify(authButtonList));
        // } else {
        //   to.meta.authButtonList = [];
        // }
        // // to.meta.prevRouter = from;
        // next();
      }
    }
  } else {
    // 如果是免登录的页面则直接进入，否则跳转到登录页面
    if (whiteList.indexOf(to.name) >= 0) {
      getRouter = null;
      next();
    } else {
      // next({path: '/login', replace: true});
      // Utils.commonUtil.toLogin();
      next({ path: `/${Auth.hasLoginTitle()}`, replace: true });
      getRouter = null;
      // 如果store中有token，同时Cookie中没有登录状态
    }
  }

});



router.afterEach(() => {
  // 设置 TDK
  // setMetaName();
  // 关闭进度条
  NProgress.done();
});

// 设置 TDK
export function setMetaName() {
  document.title = '施工管理云登录界面_中建君联_欢迎使用';
  const meta = document.getElementsByTagName('meta');
  const metaNameList = [];
  // const metaList = [];
  for (let i = 0; i <= meta.length - 1; i++) {
    const metaName = meta[i].getAttribute('name');
    if (metaName) {
      metaNameList.push(meta[i].getAttribute('name'));
    }
  }
  if (metaNameList.indexOf('keywords') < 0) {
    // 插入 meta 标签
    const oMeta = document.createElement('meta');
    oMeta.content = '施工管理云,中建君联,施工管理软件,物资管理软件,材料管理软件,工程管理软件,工程项目管理软件,建筑施工管理软件,施工管理系统,物资管理系统,材料管理系统,工程项目管理系统,建筑施工管理系统';
    oMeta.name = 'keywords';
    document.getElementsByTagName('head')[0].appendChild(oMeta);
  }
  if (metaNameList.indexOf('description') < 0) {
    // 插入 meta 标签
    const oMeta = document.createElement('meta');
    oMeta.content = '欢迎登录中建君联施工管理云，施工管理云国内首个工程项目管理云平台，引领施工管理新模式。走进施工管理云时代，云应用赋能智慧项目，互联网+助推产业变革；建筑施工管理软件为施工企业提供项企一体化业务、数据平台，涵盖企业经营、项目管理、成本管控、OA协同的新一代SaaS云服务提供商';
    oMeta.name = 'keywords';
    document.getElementsByTagName('head')[0].appendChild(oMeta);
  }
}

export function getButtonResources(arr) {
  for (const i in arr) {
    const item = arr[i];
    if (item.flg === '2') {
      buttonList.push(item);
    }
    if (item.children && item.children.length) {
      getButtonResources(item.children);
    }
  }
}

export function setRouter(arr) {
  if (!arr.length) {
    return arr;
  } else {
    for (const i in arr) {
      const item = arr[i];
      item.pathLanguage = item.path;
      item.path = '';
      item.component = 'Layout';
      item.meta = {};
      item.meta.title = item.resName;
      item.meta.name = item.resName;
      item.meta.icon = item.icon;
      item.meta.isCached = item.cached;
      item.meta.isRoute = item.isRoute;
      for (const j in item.children) {
        const child = item.children[j];
        child.component = child.resUrl;
        child.name = child.path;
        child.meta = {};
        child.meta.title = child.resName;
        child.meta.name = child.resName;
        child.meta.icon = child.icon;
        child.meta.isCached = child.cached;
        child.meta.pathLanguage = child.path;
        child.meta.isRoute = child.isRoute;
      }
    }
    return arr;
  }
}

function routerGo(to, next) {
  getRouter = filterAsyncRouter(getRouter); // 过滤路由
  const newRouter = getRouter.concat(error);
  router.$addRoutes(newRouter);
  // 将路由数据传递给全局变量，做侧边栏菜单渲染工作
  next({ ...to, replace: true });
}

function filterAsyncRouter(asyncRouterMap) { // 遍历后台传来的路由字符串，转换为组件对象

  const accessedRouters = asyncRouterMap.filter(route => {
    if (route.component && route.isRoute) {
      if (route.component === 'Layout') { // Layout组件特殊处理
        route.component = Layout;
      } else {
        route.component = _import(route.component);
      }
    }
    if (route.children && route.children.length) {

      route.children = filterAsyncRouter(route.children);
    }
    return true && route.isRoute;
  });

  return accessedRouters;
}

function setLanguage(arr) {
  const obj = {};
  for (const i in arr) {
    const item = arr[i];
    Vue.set(obj, item.columnCode, item.languageValue);
  }
  return obj;
}
// 获取通用语言后进行数据处理
function setLanguageCommon(languageArr) { // 遍历后台传来的路由字符串，转换为组件对象
  let languageObj = {};
  languageArr.forEach(item => {
    if (languageObj[item.pageCode]) {
      Vue.set(languageObj[item.pageCode], item.columnCode, item.languageValue)
    } else {
      Vue.set(languageObj, item.pageCode, { [item.columnCode]: item.languageValue })
    }
  })
  return languageObj;
}

router.$addRoutes = (params) => {
  router.matcher = new Router({ // 重置路由规则
    routes: constantRouterMap,
  }).matcher;
  router.addRoutes(params); // 添加路由
};
// 国际化
function setMenuLanguage(to, next) {
  loadingSubmit = Vue.prototype.$loading({
    lock: true,
    background: 'rgba(0,0,0,0.7)',
    spinner: 'el-icon-loading',
  });
  // 语言初始化
  pageLanguageFlag = false;
  basicLanguageFlag = false;
  const pageName = to.params && to.params.translateName ? to.params.translateName : to.name;
  const params = {
    subSystemCode: Utils.config.subSystemCode,
    pageCode: pageName,
  };
  store.dispatch('publicApi/languageValues', params).then(res => {
    pageLanguageFlag = true;
    if (res.results.length) {
      let languageObj = i18n.messages[language];
      Vue.set(languageObj, pageName, setLanguage(res.results));
      i18n.setLocaleMessage(language, Object.assign(languageObj));
      if (basicLanguageFlag && pageLanguageFlag) {
        toRouter(to, next);
      }
    }
    // 2 个接口 都调用成功 跳转页面
    if (basicLanguageFlag && pageLanguageFlag) {
      toRouter(to, next);
    }
  });
  getLanguageSubSystemCodeValues(to, next);
}
// 通用国际化
function getLanguageSubSystemCodeValues(to, next) {
  store.dispatch('publicApi/getLanguageSubSystemCodeValues').then(res => {
    basicLanguageFlag = true;
    if (res.results.length === 0) {
    } else {
      let languageObj = i18n.messages[language];
      i18n.mergeLocaleMessage(language, Object.assign(languageObj, setLanguageCommon(res.results)));
    }
    // 2 个接口 都调用成功 跳转页面
    if (basicLanguageFlag && pageLanguageFlag) {
      toRouter(to, next);
    }
  });
}
// 跳转路由
function toRouter(to, next) {
  // translateName
  let authButtonList = [];
  if (to.params.translateName) {
    authButtonList = Utils.menu.getCurrentButton(to.params.translateName);
  } else {
    authButtonList = Utils.menu.getCurrentButton(to.name);
  }
  // console.log(authButtonList, 'authButtonList');
  if (authButtonList && authButtonList.length) {
    to.meta.authButtonList = JSON.parse(JSON.stringify(authButtonList));
  } else {
    to.meta.authButtonList = [];
  }
  next();
  loadingSubmit && loadingSubmit.close();
}
