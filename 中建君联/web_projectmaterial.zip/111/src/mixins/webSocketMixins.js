/*
 * @Author: your name
 * @Date: 2021-12-07 16:29:01
 * @LastEditTime: 2022-06-17 10:21:19
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \web_projectmaterial\src\mixins\webSocketMixins.js
 */

import MaskBorder from 'autoprefixer/lib/hacks/mask-border';
import processJump from 'util/processJump.js';

export const webSocketMixins = {
    data() {
      return {
        websock: null, // 建立的连接
        lockReconnect: false, // 是否真正建立连接
        timeout: 50 * 1000, // 30秒一次心跳
        timeoutObj: null, // 心跳心跳倒计时
        serverTimeoutObj: null, // 心跳倒计时
        timeoutnum: null, // 断开 重连倒计时
        lastRunTime: Date.now(), // 上次播放声音的时间
        messageTypeList: {
            '01': this.$t('dialog.messageTypeTips1'), // '流程中@消息'
            '02': this.$t('dialog.messageTypeTips2'), // '待办消息'
            '03': this.$t('dialog.messageTypeTips3'), // '待阅消息'
            '04': this.$t('tips.warnNews') // '待阅消息'
        },
        messageReminder: 'open'
      };
    },
    created() {
      this.hanleMessageReminder();
      // 页面刚进入时开启长连接
      this.initWebSocket();
    },
    destroyed() {
        // 页面销毁时关闭长连接
        this.websock && this.websock.close();
    },
    methods: {
        initWebSocket() {
            this.websock = null;
            // 判断当前浏览器是否支持WebSocket
            if ('WebSocket' in window) {
              // 建立连接
              const userId = this.$utils.Auth.hasUserInfo().userId;
              const token = this.$utils.Auth.hasUserInfo().token;
              const tenantId = this.$utils.Auth.hasUserInfo().tenantId;
              this.websock = new WebSocket(`ws://${this.$utils.config.websocketUrl}/websocket/${tenantId}/${userId}/${token}`);
            } else {
              // 当前浏览器 不支持WebSocket 无法进行系统通知
              this.$notify({
                message: this.$t('dialog.windowWebSocket'),
                duration: 5000
              });
            }
            if (!this.websock) return;
            // 连接成功
            this.websock.onopen = this.websocketonopen;
            // 连接错误
            this.websock.onerror = this.websocketonerror;
            // 接收信息
            this.websock.onmessage = this.websocketonmessage;
            // 连接关闭
            this.websock.onclose = this.websocketclose;
          },
          reset() {
            // 重置心跳
            const that = this;
            // 清除时间
            clearTimeout(that.timeoutObj);
            clearTimeout(that.serverTimeoutObj);
            // 重启心跳
            that.start();
          },
          start() {
            // 开启心跳
            this.timeoutObj && clearTimeout(this.timeoutObj);
            this.serverTimeoutObj && clearTimeout(this.serverTimeoutObj);
            this.timeoutObj = setTimeout(() => {
              // 这里发送一个心跳，后端收到后，返回一个心跳消息，
              if (this.websock.readyState === 1) {
                // 如果连接正常
                this.websock.send(JSON.stringify({content: 'junnysoft-heartCheck', ifHeartCheck: 1}));
              } else {
                // 否则重连
                this.reconnect();
              }
              this.serverTimeoutObj = setTimeout(() => {
                // 超时关闭
                this.websock.close();
              }, this.timeout);
            }, this.timeout);
          },
          reconnect() {
            // 重新连接
            const that = this;
            if (that.lockReconnect) {
              return;
            }
            that.lockReconnect = true;
            // 没连接上会一直重连，设置延迟避免请求过多
            that.timeoutnum && clearTimeout(that.timeoutnum);
            that.timeoutnum = setTimeout(() => {
              // 新连接
              that.initWebSocket();
              that.lockReconnect = false;
            }, 5000);
          },
          websocketonerror(e) {
            // 连接失败事件
            // 错误提示
            // WebSocket连接发生错误
            // this.$message.error(this.$t('dialog.webSocketError'));
            // 重连
            this.reconnect();
          },
          websocketclose(e) {
            // 连接关闭事件
            // 重连
            this.reconnect();
          },
          websocketonmessage(event) {
            // 接收服务器推送的信息
            // 收到服务器信息，心跳重置
            this.reset();
            // 打印收到服务器的内容
            // 心跳包返回消息不做处理
            const that = this;
            const data = JSON.parse(event.data);
            if (data.content === 'junnysoft-heartCheck') {
              return;
            }
            if (!data.receiverUsers.length) {
              this.initWebSocket();
              // '未发送成功，请重新发送!'
              this.$message.error(this.$t('tips.sendMessageErrorTips'));
              return;
            }
            if (!data.sendUserId) {
              this.$refs.TalkPanel && this.$refs.TalkPanel.setLoadChatRecords(data);
              this.websocketTodoList && this.websocketTodoList();
              return;
            }
            if (this.messageReminder === 'open' && !this.$refs.TalkPanel) {
              this.$notify({
                customClass: 'IMNoticeItemsNotify',
                message: `<div style="display: flex;min-height: 70px;">
                  <div style="width: 45px;
                        background: #64b524;
                        text-align: center;
                        display: flex;
                        align-items: center;
                        justify-content: center;">
                    <i class="el-icon-check" style="color: white;
                          font-size: 18px;font-weight: bold;"></i>
                  </div>
                  <div style="width: calc(100%);
                        font-size: 14px;
                        display: flex;
                        align-items: center;">
                    <div style="width: calc(100%);padding: 10px;
                          word-break: break-all;
                          box-sizing: border-box;">
                        <span style="padding-left: 10px;color: #0089f0;
                              cursor: pointer;overflow: hidden;">
                              ${data.taskName}：
                        </span>
                        <br>
                        <span style="padding-left: 10px;">
                          ${this.$t('dialog.messageTypeValueTips1')}${this.messageTypeList[data.messageType]}，
                          ${this.$t('dialog.messageTypeValueTips2')}
                        </span>
                    </div>
                  </div>
                </div>`,
                duration: 5000,
                showClose: false,
                onClick() {
                  that.handleOpen(data);
                  this.close();
                },
                dangerouslyUseHTMLString: true
              });
              // this.$notify({
              //   message: `<div style="padding-right: 10px;
              //                   box-sizing: border-box;
              //                   width: 280px;">
              //       <p>${data.taskName}：
              //       ${this.$t('dialog.messageTypeValueTips1')}${this.messageTypeList[data.messageType]}，
              //       ${this.$t('dialog.messageTypeValueTips2')}！</p>
              //       <div style="cursor: pointer;
              //                   text-align: right;
              //                   color: #24b568;">
              //         ${this.$t('dialog.onmessageBut')}
              //       </div>
              //     </div>`,
              //   duration: 5000,
              //   onClick() {
              //     that.handleOpen(data);
              //     this.close();
              //   },
              //   dangerouslyUseHTMLString: true
              // });
              // 播放声音
              this.playSound();
            }
            // 重新获取数据
            const messageData = this.$clone(data);
            if (this.$refs.TalkPanel) {
              this.$refs.TalkPanel.setLoadChatRecords(messageData);
              // 发送人不是当前人时
              this.handleItemsInfo(data);
              // 播放声音
              this.messageReminder === 'open' && this.playSound();
            } else {
              this.websocketTodoList && this.websocketTodoList();
            }
          },
          handleOpen(row, callback) {
            this.handleItemsInfo(row);
            callback && callback();
          },
          websocketonopen() {
            // 连接成功事件
            // 提示成功
            // 开启心跳
            this.start();
          },
          websocketsend(msg, messageData) {
            // 向服务器发送信息
            // 数据发送
            MaskBorder.ifHeartCheck = 0;
            this.websock.send(JSON.stringify(msg));
          },
          playSound() {
            const currentTime = Date.now();
            const protectTime = 500; // 设置保护性延时 单位毫秒，不要小于50 建议100以上
            if (currentTime - this.lastRunTime < protectTime) {
              return; // 两次执行太过频繁，直接退出
            }
            const app = document.getElementById('app');
            const div = document.createElement('div'); // 创建段落节点
            div.setAttribute('id', 'audioPlayBefore');
            app.appendChild(div);
            div.addEventListener('click', this.audioPlay);
            const audioPlayBefore = document.getElementById('audioPlayBefore');
            audioPlayBefore.click();
            this.lastRunTime = Date.now();
          },
          audioPlay() {
            const audio = document.getElementById('audioPlay');
            audio.play();
          },
          // 是否消息提醒
          hanleMessageReminder(type) {
            const messageReminder = localStorage.getItem('message-reminder');
            if (type === 'set') {
              const setMessageReminderStatus = messageReminder === 'open' ? 'close' : 'open';
              localStorage.setItem('message-reminder', setMessageReminderStatus);
              this.messageReminder = setMessageReminderStatus;
            } else {
              const setMessageReminderStatus = messageReminder || 'open';
              localStorage.setItem('message-reminder', setMessageReminderStatus);
              this.messageReminder = setMessageReminderStatus;
            }
          },
          // 点击查看
          handleItemsInfo(row) {
            if (row.messageType === '05' || row.messageType === '06') {
              const ids = [row.sessionId];
              this.$store.dispatch('publicApi/websocketBatchUpdateMessageStatus', ids).then(res => {
                this.websocketTodoList();
              });
              const url = `${this.$utils.config.jumpUrl}/portal/#/taskCenter?seeType=${row.messageType === '05' ? 'waitingExecution' : 'supervise'}`;
              window.open(url, '_blank');
              return;
            }
            if (row.messageType === '04') {
              this.$confirm(row['details'][0].messageContent, this.$t('tips.warnNews'), {
                confirmButtonText: this.$t('button.gotIt'),
                cancelButtonText: this.$t('tips.close'),
                type: 'warning'
              }).then(() => {
                const ids = [row.sessionId];
                this.$store.dispatch('publicApi/websocketBatchUpdateMessageStatus', ids).then(res => {
                  this.websocketTodoList();
                });
              }).catch(() => {});
              return;
            }
              // 消息类型(01流程中聊天消息,02待办消息,03待阅消息)
              // 跳转到流程页面
              if (!processJump[row.formCode]) {
                  this.$message.error(this.$t('tips.jumpRouteNotWebsocket'));
                  return;
              }
              this.websocketTaskQueryInfoMixins(row);
          },
          // 查询流程详细信息
          // 查询流程详细信息
          websocketTaskQueryInfoMixins(row) {
            this.$store.dispatch('processApi/workflowTaskDetailInfo', {taskDetailId: row.taskDetailId}).then(res => {
              if (res.status === 0) {
                const results = res.results;
                const processType = results.status === 1 ? 'undo' : 'info';
                if (row.messageType === '01') {
                  this.websocketUpdateMessageStatusMixins(row, () => {
                    this.handleProcessJump(row, processType);
                  });
                } else {
                  this.websocketTaskTodoUpdateMessageStatusMixins(row.taskId || results.taskId, row.messageType, () => {
                    this.handleProcessJump(row, processType);
                  });
                }
              } else {
                this.$message.error(`${res.errorMessage}`);
              }
            }).catch(e => {
              if (row.messageType === '01') {
                this.websocketUpdateMessageStatusMixins(row);
              } else {
                this.websocketTaskTodoUpdateMessageStatusMixins(row.taskId, row.messageType);
              }
              // 该流程已被发起人删除
              this.$message.error(this.$t('tips.deleteProcessMessageTips'));
            });
          },
          // 流程跳转
          handleProcessJump(row, processType) {
            const taskDetailId = this.$base64.encode(row.taskDetailId);
            // 查阅
            const type = this.$base64.encode(processType);
            const url =
            // eslint-disable-next-line max-len
            `${processJump[row.formCode].jumpUrl}/${type}/${taskDetailId}/${processJump[row.formCode].translateName}?seeType=${processType === 'undo' ? 'undo' : row.messageType === '03' ? 'read' : 'info'}`;
            window.open(url, '_self');
          },
          // 变更未读状态
          websocketUpdateMessageStatusMixins(row, callback) {
              const userId = this.$utils.Auth.hasUserInfo().userId;
              const data = {
                sessionMessageId: row.sessionId || row.sessionMessageId,
                receiverUserId: userId,
                sendMessageId: row.sendMessageId,
                messageSequence: row.messageSequence
              };
              const statusUrl = row.messageType === '01' ? 'websocketUpdateMessageStatus' : 'websocketTodoUpdateMessageStatus';
              this.$store.dispatch(`publicApi/${statusUrl}`, data).then(res => {
              if (res.status === 0) {
                  // 重新获取数据
                  this.websocketTodoList && this.websocketTodoList();
                  callback && callback();
              } else {
                  this.$message.error(`${res.errorMessage}`);
              }
              });
          },
          // 待办/待阅 通知设置消息已读
          websocketTaskTodoUpdateMessageStatusMixins(taskId, messageType, callback) {
            const data = {
              taskId,
              messageType
            };
            this.$store.dispatch('publicApi/websocketTaskTodoUpdateMessageStatus', data).then(res => {
              if (res.status === 0) {
                this.websocketTodoList();
                callback && callback();
              } else {
                this.$message.error(`${res.errorMessage}`);
              }
            });
          }
    }
};

