/*
 * @Author: your name
 * @Date: 2020-09-08 15:44:04
 * @LastEditTime: 2023-02-23 14:59:57
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_basicconfiguration\src\mixins\publicApi\index.js
 */

export default {
  // 批量更新常用联系人
  setProcessRoleList: {
    url: '/basicconfiguration/organization/user/batch/common/users/edit',
    method: 'post'
  },
  // 分页查询常用联系人
  getRecentUsersList: {
    url: '/basicconfiguration/organization/user/common/users',
    method: 'post'
  },
  // 分页查询常用联系人(包含离职的)
  getRecentUsersAllList: {
    url: '/basicconfiguration/organization/user/common/users/all',
    method: 'post'
  },
  // 批量获取用户信息
  getUserInfosListPublic: {
    url: '/basicconfiguration/organization/user/basic/infos',
    method: 'post'
  },
  // token解析
  tokenCheckLoginPublic: {
    url: '/oauth/auth/ht',
    method: 'get'
  },
  // 获取用户信息
  getUserInfoPublic: {
    url: '/basicconfiguration/passport/login/info/build',
    method: 'get'
  },
  // 退出登录
  outLoginPublic: {
    url: '/oauth/auth/logout',
    method: 'get'
  },
  // 密码登录
  passwordLoginPublic: {
    url: '/oauth/auth/pd',
    method: 'get'
  },
  // 获取语言类型
  getLanguageTypePublic: {
    url: '/backstage/language/api/type/all',
    method: 'get'
  },
  getLanguageTypeEffectivePublic: {
    url: '/backstage/language/type/effective',
    method: 'get'
  },
  // 初始化流程表单
  initWorkflowFormPublicApi: {
    url: '/basic/workflow/cfg/form/increment/init/column',
    method: 'post'
  },
  // 校验formCode是否存在
  checkFormcodeExistPublicApi: {
    url: '/basic/workflow/cfg/form/check/formcode/exist',
    method: 'get'
  },
  // 获取orgName
  getOrginfoPublicApi: {
    url: '/basicconfiguration/organization/org/info',
    method: 'get'
  },
  // 获取所有项目
  getProjectAllPublicApi: {
    url: '/project/project/page',
    method: 'post'
  },
  // 获取用户字段列缓存
  getMetaColumns: {
    url: '/basic/meta/column/get',
    method: 'get'
  },
  // 保存用户字段列缓存
  setMetaColumns: {
    url: '/basic/meta/column/set',
    method: 'post'
  },
  // 判断当前分支节点是否已经执行完成(不包含当前节点)
  judgeProcessOver: {
    url: '/basic/workflow/task/execute/check/over',
    method: 'get'
  },
  // 获取权限组织
  getOrgEffectiveTreePublicApi: {
    url: '/assets/config/property/org/effective/tree',
    method: 'get'
  },
  // 租户打印文件(pdf)上传
  tenantPdfUploadPublicApi: {
    url: '/basic/file/print/tenant/pdf/upload',
    method: 'post'
  },
  // 查询租户有效的子系统 currentTenantId
  getTenantSubSystemEffectivePublic: {
    url: '/backstage/tenant/subsystem/effective',
    method: 'get'
  },
  // 获取租户的子系统
  getQuickSubsystemPublic: {
    url: '/backstage/tenant/subsystem/quick/subsystem/get',
    method: 'get'
  },
  // 获取免费子系统
  tenantSubsystemPublic: {
    url: '/backstage/tenant/subsystem/effective',
    method: 'get'
  },
  // 设置用户子系统
  setQuickSubsystemPublic: {
    url: '/backstage/tenant/subsystem/quick/subsystem/set',
    method: 'post'
  },
  //  验证用户是否有子系统的菜单
  checkSubSystemMenusPublic: {
    url: '/basicconfiguration/passport/subsystem/menus/check',
    method: 'get'
  },
  // 查询人员待处理消息
  websocketTodoList: {
    url: '/websocket/message/receiver/todo/list',
    method: 'get'
  },
  // 待处理消息类型
  websocketTodoMessageType: {
      url: '/websocket/message/receiver/todo/message/type',
      method: 'get'
  },
  // 分页查询待处理消息列表
  websocketTodoMessagePage: {
      url: '/websocket/message/receiver/todo/session/page',
      method: 'post'
  },
  // 更新已读状态
  websocketUpdateMessageStatus: {
      url: '/websocket/message/receiver/update/message/status',
      method: 'get'
  },
  // 待办待阅更新为已读状态
  websocketTodoUpdateMessageStatus: {
    url: '/websocket/message/receiver/update/todo/message/status',
    method: 'get'
  },
  // 查询单个会话的聊天记录
  websocketReceiverMessagePage: {
    url: '/websocket/message/receiver/message/page',
    method: 'post'
  },
  // 查询消息会话的总数
  websocketMessageCounts: {
    url: '/websocket/message/send/session/counts',
    method: 'get'
  },
  // 待办/待阅标为已读
  websocketTaskTodoUpdateMessageStatus: {
    url: '/websocket/message/receiver/update/task/todo/message/status',
    method: 'get'
  },
  // 查询流程节点详细信息
  websocketTaskQueryInfo: {
      url: '/basic/workflow/task/query/info',
      method: 'get'
  },
  // 查询对应员工和帐户号(不分页)
  getPersonnelAccountList: {
    url: '/bff/baseconfig/personnel/account/list',
    method: 'get'
  },
  // 查询公司正常帐户列表信息(不分页)
  getCompanyAccountList: {
    url: '/bff/baseconfig/company/account/list',
    method: 'get'
  },
  // 批量更新为已读
  websocketBatchUpdateMessageStatus: {
    url: '/websocket/message/receiver/batch/update/message/status',
    method: 'post'
  },
  // 读取图片解析增值税发票
  getInvoiceFileListPublicApi: {
    url: '/contract/income/invoice/invoice/build',
    method: 'get',
    loading: true
  },
  // POST 查询角色关联的有效的子系统及菜单信息
  organizationQuickRoleMenu: {
    url: '/basicconfiguration/organization/quick/role/menu/vaild/list',
    method: 'post'
  },
  // 查询消息数量
  websocketMessageCountsPublicApi: {
      url: '/websocket/message/receiver/todo/session/counts',
      method: 'post'
  },
  // 分页查询我的待处理任务列表信息
  getTodoExecutePagePublicApi: {
      url: '/websocket/task/todo/execute/page',
      method: 'post'
  },
  // 获取发票
  getInvoiceListPublicApi: {
      url: '/contract/v1/expend/register/list/by/project',
      method: 'get'
  },
  // 租户文件分片上传接口
  uploadTenantFragmentPublicApi: {
    url: '/basic/file/tenant/fragment/upload',
    method: 'post'
  },
  // 租户统一文件上传接口后文件合并
  uploadTenantMergerPublicApi: {
    url: '/basic/file/tenant/merge/file',
    method: 'get'
  },
  // 用于前端文件上传到OSS服务器后保存文件记录信息
  uploadFilEditPublicApi: {
    url: '/basic/file/edit',
    method: 'post'
  },
  // 获取文件信息-Api
  getFileInfoPublicApi: {
    url: '/basic/file/api/file/inf',
    method: 'get'
  },
  // 查询表单单据打印次数
  getPrintCountsPublicApi: {
    url: '/basic/print/tenant/record/counts',
    method: 'get'
  },
  // 新增、修改租户打印表单记录
  setPrintCountsPublicApi: {
    url: '/basic/print/tenant/record/edit',
    method: 'post'
  },
  // 获取合同详细信息
  getContractInfoPublicApi: {
    url: '/contract/expend/register/info',
    method: 'get'
  },
  // 查询节点详细信息
  getStepTaskInfoPublicApi: {
    url: '/backstage/step/task/detail/info',
    method: 'get'
  },
  // 退回发起人
  getStepTaskReturnStartPublicApi: {
    url: '/backstage/step/task/return/start',
    method: 'post'
  },
  // 通过供应商用户ID获取用户信息
  getSupplierUserInfoPublicApi: {
    url: '/tenders/supplier/user/info',
    method: 'get'
  },
  // 获取流程日志
  getStepTaskLogListPublicApi: {
    url: '/backstage/step/task/detail/log/list',
    method: 'get'
  },
  // 查询任务单详细信息
  getStepTaskQueryInfoPublicApi: {
      url: '/backstage/step/task/info',
      method: 'get'
  },
  // 查询待办数量
  getStepTodoCounts: {
    url: '/backstage/step/task/detail/todo/counts',
    method: 'get'
  },
  // 查询流程实例详细信息及其节点和连线信息
  getStepPublishProcessWinPublicApi: {
      url: '/backstage/step/publish/process/win/info',
      method: 'get'
  },
  // 查询租户有效的页面控制设置记录
  getPageControlPublicApi: {
    url: '/backstage/sys/page/control/list',
    method: 'post'
  },
  // 查询用户权限的子系统code
  getUserAuthSubsystemCodes: {
    url: '/basicconfiguration/organization/role/user/auth/subsystemcodes',
    method: 'get'
  },
  // 根据用户权限的子系统code 查询租户有效的子系统(有权限的)
  getEffectiveSubsystem: {
    url: '/backstage/tenant/subsystem/permission/effective',
    method: 'post'
  },
  // 校验发票号码和代码是否已经存在(如果存在返回true,否则返回false)
  tenantInvoiceExist: {
      url: '/basic/tenant/invoice/record/check/invoce/code/exist',
      method: 'get'
  },
  // 查询租户发票记录信息
  tenantInvoiceInfo: {
      url: '/basic/tenant/invoice/record/invocie/info',
      method: 'get'
  },
  // 更改流程审批人
  updateAssigneePublicApi: {
      url: '/basic/workflow/task/execute/assignee/update',
      method: 'get'
  },
  // 根据formCode查询对应的流程主题设置信息
  getProcessRulePublicApi: {
    url: '/backstage/help/workflow/rule/valid/subject/rule',
    method: 'get'
  },
  // 查询项目的资金管控设置信息
  getCapitalProjectPaymentPublicApi: {
    url: '/capital/baseconfig/capital/control/project/payment/info',
    method: 'get'
  },
  // 查询对应员工和帐户号(不分页)
  getPersonnelAccountListPublicApi: {
    url: '/bff/baseconfig/personnel/account/list',
    method: 'get'
  },
  // 区号
  getSmsCountryEffectivePublicApi: {
    url: '/basic/sms/api/country/effective',
    method: 'get'
  },
  // 查询项目下的主计划主表数据
  getMasterPlanByprojectPublicApi: {
    url: '/proprogress/plan/master/byproject/list',
    method: 'get'
  },
  // 查询合同收票
  getContractExpendInvoicePublicApi: {
    url: '/contract/expend/invoice/page',
    method: 'post'
  },
  // 查询企业信息
  getOrganizationCompanyInfoPublicApi: {
    url: '/basicconfiguration/organization/company/info',
    method: 'get'
  }
};
