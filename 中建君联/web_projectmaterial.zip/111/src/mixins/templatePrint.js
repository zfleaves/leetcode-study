
import printConfigUrl from 'components/basicComponents/printTemplate/pintConfig/printConfigUrl.js';
import filters from 'mixins/filters/index';

export const templatePrint = {
    data() {
        return {
            printConfigUrl,
            editPageConfig: {},
            initPanels: {},
            cloneInitPanels: {
                index: 0,
                paperType: 'A4',
                height: 297,
                width: 210,
                paperHeader: 49.5,
                paperFooter: 780,
                printElements: [
                    {
                        options: {
                            left: 250.5,
                            top: 19.5,
                            height: 9.75,
                            width: 120,
                            title: '',
                            field: 'title',
                            fontSize: 21
                        },
                        printElementType: { type: 'text' }
                    }
                ],
                paperNumberLeft: 565.5,
                paperNumberTop: 819
            },
            mypanel: {
                panels: []
            },
            cloneMypanel: {},
            printDataAllList: [],
            printFormList: [], // 主表
            printDetailsList: {}, // 子表
            // 表头
            printMainListMypanel: [
              {
                flag: true,
                defaultFlag: true,
                columnName: this.$t('print.headerDescription'),
                columnCode: 'companyFullName',
                columnValue: this.$utils.Auth.hasUserInfo().companyFullName,
                status: 0,
                sortPart: 'title'
              },
              {flag: true, defaultFlag: true, columnName: this.$t('print.documentName'), columnCode: 'title',
              sortPart: 'title',
              columnValue: this.$t(`menu.${this.$route.name}`), status: 0},
              {flag: true, defaultFlag: true, columnName: this.$t('dialog.approvalRecord'), columnCode: 'approvalRecord',
              sortPart: 'title',
              columnValue: '', status: 0},
              {flag: true, defaultFlag: true, columnName: this.$t('print.logoShow'), columnCode: 'logoShow',
              sortPart: 'title',
              columnValue: '', status: 0}
            ]
        };
    },
    methods: {
        sysHandleBatchPrint() {
            if (this.tableSeleList.length === 0) {
                // 请您先选中想要提打印标签的一行数据
                this.$message({
                    message: this.$t('print.selePrintLabelTips'),
                    type: 'info'
                });
                return;
            }
            // 当前已选中的套打数据：
            // 是否要多选择的多行数据进行套打？如果套打将会直接将任务全部发送至打印机，为避免浪费纸张，建议可以先单张打印，确认输出格式满足要求后再进行套打。
            // 只可套打当前页面数据，一次打印数量不要超过10条！
            this.$confirm(`${this.$t('tips.batchPrintTips2')}：${this.tableSeleList.map(v => v.docNo).join('，')}<br>
            ${this.$t('tips.batchPrintTips')}<br>
            <span style="color:red">${this.$t('tips.batchPrintTips1')}</span>`, `${this.$t('button.batchPrint')}${this.$t('tips.tips')}`, {
                dangerouslyUseHTMLString: true,
                confirmButtonText: this.$t('button.batchPrint'),
                cancelButtonText: this.$t('button.close'),
                type: 'warning'
            }).then(() => {
                this.getPrintInit();
            }).catch(() => {
            });
        },
        // 获取info数据
        async _getInfoData (id, callBack) {
            const infoUrl = this.editPageConfig.processParmas.infoUrl;
            const res = await this.$store.dispatch(infoUrl.url, {[infoUrl.params]: id}).then();
            const results = this.$clone(res.results);
            if (results.continent) {
                results.areas = [];
                const keysList = ['continent', 'country', 'province', 'city', 'area'];
                for (const key of keysList) {
                if (results[key] && results[key].indexOf('-')) {
                    const id = results[key].split('-')[1];
                    results.areas.push(Number(id));
                }
                }
            }
            if (results.taskId) {
                const data = await this.$store.dispatch('processApi/getTasksQueryLogs', { taskId: results.taskId }).then();
                if (data.status === 0) {
                    const taskLogs = [];
                    for (const i in data.results) {
                        this.$set(data.results[i], 'index', Number(i) + 1);
                        if (data.results[i].nodeName !== '结束') {
                            taskLogs.push(data.results[i]);
                        }
                    }
                    this.$set(results, 'approvalRecordList', taskLogs);
                }
            }
            callBack && callBack(results);
        },
        getPrintInit() {
            const formConfig = this.printConfigUrl[this.pageConfig.formCode].printConfigUrl;
            const Page = require(`views/${formConfig}`).default;
            const page = new Page();
            this.editPageConfig = page.PageConfig;
            this.printFormList = this.$clone(this.editPageConfig.mainFormConfig.formList);
            for (const item of this.editPageConfig.subTableMatch) {
                this.$set(this.printDetailsList, item.assignment, this.$clone(this.editPageConfig.subTableConfig[item.assignment].tableList.slaveColumns));
            }
            this._getPrintDetail();
        },
        // 获取表单字段
        async _getPrintDetail() {
            this.printFieldList = {};
            await this.$store.dispatch('printApi/getPrintDetail', { printModelCode: this.pageConfig.formCode }).then(res => {
                if (!res.results) return;
                const results = res.results;
                for (const i in results) {
                  const item = results[i];
                  this.$set(this.printFieldList, `${item.columnCode}-${item.printModelPartCode}`, {
                    flag: item.isShow === 0,
                    printWidth: item.width
                  });
                }
                this._getPrintSort();
            });
        },
        // 获取字段排序
        async _getPrintSort() {
            await this.$store.dispatch('printApi/getPrintSort', { printModelCode: this.pageConfig.formCode }).then(res => {
                if (res.results) {
                    const results = res.results.filter(v => v.printModelCode === this.pageConfig.formCode);
                    this.setSortList(results, this.printFormList, 'head');
                    this.setSortList(results, this.printMainListMypanel, 'title');
                    for (const i in this.printDetailsList) {
                        this.setSortList(results, this.printDetailsList[i], 'body');
                    }
                    this.getPrintInitData();
                }
            });
        },
        // 排序
        setSortList(arr, setArr, part) {
            const list = arr.filter(v => v.printModelPartCode === part);
            for (const i in setArr) {
                const item = setArr[i];
                this.$set(item, 'flag', this.printFieldList[`${item.prop}-${part}`] ? this.printFieldList[`${item.prop}-${part}`].flag
                : item.printFlag || (item.printFlag !== false ? true : item.printFlag));
                this.$set(item, 'printWidth', this.printFieldList[`${item.prop}-${part}`] ? (this.printFieldList[`${item.prop}-${part}`].printWidth || item.printWidth || 8) : item.printWidth || 8);
                const index = list.findIndex(v => v.columnCode === (item.pintIdName ? item.pintIdName : (item.printProp || item.prop)));
                if (index >= 0) {
                    this.$set(item, 'sort', list[index].sort);
                }
            }
            setArr = setArr.sort(this.compare);
        },
        // 排序 比较大小
        compare(obj1, obj2) {
          const val1 = obj1.sort || 0;
          const val2 = obj2.sort || 0;
          if (val1 > val2) {
            return 1;
          } else if (val1 < val2) {
            return -1;
          } else {
            return 0;
          }
        },
        async getPrintInitData() {
            this.loading = true;
            this.printDataAllList = [];
            for (const i in this.tableSeleList) {
                const item = this.tableSeleList[i];
                await this._getInfoData(item.id, (results) => {
                    const formList = this.setMainList(this.printFormList, results);
                    const detailsList = this.setDetailsList(this.editPageConfig.subTableMatch, formList[formList.length - 1].options.top, results);
                    if (Number(i) === 0) {
                        this.cloneMypanel = this.$clone(this.mypanel);
                        this.initPanels = this.$clone(this.cloneInitPanels);
                        this.$set(this.initPanels, 'index', Number(i));
                        this.initPanels.printElements.push(...formList, ...detailsList);
                        this.cloneMypanel.panels.push(this.initPanels);
                    }
                    this.$set(results, 'title', this.$t(`menu.${this.$route.name}`));
                    this.printDataAllList.push(results);
                });
            }
            this.printTest(this.printDataAllList);
            this.loading = false;
        },
        setMainList(formList, results) {
            const data = [];
            let column = 0;
            const rowIndexList = [1];
            let rowIndex = 1;
            for (const i in formList) {
                const item = formList[i];
                if (item.prop !== 'attachment' && item.flag) {
                    results[item.prop] = filters.systemFilters(results[item.prop], item);
                    const printWidth = item.printWidth || 8;
                    column += printWidth;
                    if (column > 24) {
                        rowIndex += 1;
                    }
                    rowIndexList.push(rowIndex);
                    column > 24 && (column = printWidth);
                    const left = (printWidth === 24 || (24 / column) === 3) ? 33 : (rowIndexList[rowIndexList.length - 2] !== rowIndexList[rowIndexList.length - 1]) ? 33 : 550 / (24 / column) - 120;
                    // eslint-disable-next-line radix
                    const top = rowIndex === 1 ? 50 : rowIndex * 30 + 20;
                    data.push(
                        {
                            options: {
                                left,
                                top,
                                height: 16.5,
                                width: printWidth * 20,
                                title: this.$t(item.label),
                                field: item.pintIdName ? item.pintIdName : (item.printProp || item.prop),
                                fontSize: 12,
                                fontWeight: 500,
                                styler: () => {
                                    return {'line-height': '16px'};
                                }
                            },
                            printElementType: { type: 'longText' }
                        }
                    );
                }
            }
            return data;
        },
        setDetailsList(subTableMatch, top, results) {
            const detailsList = [];
            for (const i in subTableMatch) {
                const item = subTableMatch[i];
                const tableList = this.printDetailsList[item.assignment];
                const list = [
                    {
                        title: this.$t('fConfig.serialNumber'),
                        field: 'index',
                        width: 20,
                        colspan: 1,
                        rowspan: 1,
                        align: 'center',
                        checked: true
                    }
                ];
                const details = results[item.value];
                for (const li of tableList) {
                    if (li.flag) {
                        for (const j in details) {
                            const row = details[j];
                            this.$set(row, 'index', Number(j) + 1);
                            row[li.prop] = filters.systemFilters(row[li.prop], li);
                        }
                        list.push({
                            title: this.$t(li.label),
                            field: li.pintIdName ? li.pintIdName : (li.printProp || li.prop),
                            width: 63.16925398270368,
                            colspan: 1,
                            rowspan: 1,
                            align: 'center',
                            checked: true
                        });
                    }
                }
                detailsList.push(
                    {
                        options: {
                            left: 21,
                            top: (Number(i) + 1) * (Number(i) === 0 ? 60 : 80) + top,
                            height: 50,
                            width: 550,
                            field: item.value,
                            columns: [list]
                          },
                          printElementType: { title: this.$t(`${this.$route.name}.${item.assignment}`), type: 'tableCustom' }
                    }
                );
            }
            const index = this.printMainListMypanel.findIndex(v => v.columnCode === 'approvalRecord');
            const approvalRecordFlag = index >= 0 ? this.printMainListMypanel[index].flag : true;
            //  && results.taskId
            if (approvalRecordFlag) {
                detailsList.push(
                    {
                        options: {
                            left: 21,
                            top: (detailsList.length + 1) * (detailsList.length === 0 ? 60 : 80) + top,
                            height: 50,
                            width: 550,
                            field: 'approvalRecordList',
                            columns: [
                                [
                                    {
                                        title: this.$t('fConfig.serialNumber'),
                                        field: 'index',
                                        width: 20,
                                        colspan: 1,
                                        rowspan: 1,
                                        align: 'center',
                                        checked: true
                                    },
                                    {
                                        title: this.$t('dialog.nodeName'),
                                        field: 'nodeName',
                                        width: 63.16925398270368,
                                        colspan: 1,
                                        rowspan: 1,
                                        align: 'center',
                                        checked: true
                                    },
                                    {
                                        title: this.$t('dialog.approvedBy'),
                                        field: 'assigneeName',
                                        width: 50,
                                        colspan: 1,
                                        rowspan: 1,
                                        align: 'center',
                                        checked: true
                                    },
                                    {
                                        title: this.$t('dialog.autograph'),
                                        field: 'autograph',
                                        width: 63.16925398270368,
                                        colspan: 1,
                                        rowspan: 1,
                                        align: 'center',
                                        checked: true
                                    },
                                    {
                                        title: this.$t('dialog.approvalTime'),
                                        field: 'executeDate',
                                        width: 63.16925398270368,
                                        colspan: 1,
                                        rowspan: 1,
                                        align: 'center',
                                        checked: true
                                    },
                                    {
                                        title: this.$t('dialog.opinion'),
                                        field: 'comment',
                                        width: 80,
                                        colspan: 1,
                                        rowspan: 1,
                                        align: 'center',
                                        checked: true
                                    }
                                ]
                            ]
                        },
                        printElementType: { title: this.$t('dialog.approvalRecord'), type: 'tableCustom' }
                    }
                );
            }
            return detailsList;
        },
        printTest(printData) {
          //  打印模板的json
            const app = document.getElementById('app');
            const p = document.createElement('p'); // 创建段落节点
            const printDate = `print-${new Date().getTime()}`;
            p.setAttribute('id', printDate);
            app && app.appendChild(p);
          // eslint-disable-next-line no-undef
            hiprint.init();
          // 调用接口获取数据
          // eslint-disable-next-line no-undef
          const hiprintTemplate = new hiprint.PrintTemplate({
            template: this.cloneMypanel,
            settingContainer: `#${printDate}`
          });
          hiprintTemplate.print(printData);
          hiprintTemplate.clear();
        }
    }
};
