/*
 * @Author: your name
 * @Date: 2021-08-04 14:42:27
 * @LastEditTime: 2023-05-05 13:57:16
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_projectmaterial\src\mixins\processMixins.js
 */
export const process = {
    data() {
        return {
            isProcessOver: true, // 判断当前分支节点是否已经执行完成(不包含当前节点) true表示已经执行完成，false表示没执行完成
            // 选择员工
            userEntrustFlag: false,
            userEntrustDialogConfig: {
                title: this.$t('dialog.selectUser'),
                appendBody: false,
                center: true,
                top: '80px',
                width: '80%',
                span: '0.7'
            }
        };
    },
    components: {
        organizationUserTable (resolve) {
            require(['components/basicComponents/userDialog/organizationUserTable.vue'], resolve);
        }
    },
    methods: {
        // 提交
        nextStep () {
            // 将当前行存储于缓存中
            localStorage.setItem('dataInfo', JSON.stringify(this.pageConfigEdit.projectForm));
            this.checkRequired(() => {
              this.processType = 'next';
              this.$refs.processEdit.handleSave(true);
            });
        },
        // 快速同意
        quickConsent() {
            // 将当前行存储于缓存中
            localStorage.setItem('dataInfo', JSON.stringify(this.pageConfigEdit.projectForm));
            this.checkRequired(() => {
                this.processType = 'quickConsent';
                this.$refs.processEdit.handleSave(true);
            });
        },
        // 在流程审批时，对非必填字段根据字段状态进行约束
        checkRequired(callback) {
          if (this.nodeCode !== 'BEGIN') {
            const list = [];
            const subTableCustomRules = this.$refs.processEdit.subTableCustomRules || {};
            const pageConfigEdit = this.$refs.processEdit.page.PageConfig;
            const subTableMatch = pageConfigEdit.subTableMatch;
            if (subTableMatch && subTableMatch.length) {
                for (const subTable of subTableMatch) {
                    const subTableConfig = pageConfigEdit.subTableConfig[subTable.assignment];
                    const tableList = subTableConfig.tableList.slaveColumns;
                    const tableData = subTableConfig.tableData;
                    const rules = subTableConfig.tableList.rules;
                    const rule = {...rules, ...subTableCustomRules};
                    if (tableData && !tableData.length) {
                        for (const item of tableList) {
                            if (rule[item.prop] && item.inputStatus !== 'hide' && item.inputStatus !== 'disable') {
                                list.push(item);
                            }
                        }
                    }
                }
            }
            if (list && list.length) {
                if (this.parmasData.processPageName === 'sporadicReimburse' && pageConfigEdit.projectForm.deductionReserveFund === 1) {
                    callback && callback();
                } else {
                    const dataNull = list.map(v => this.$t(v.label)).join('，');
                    this.$message.error(`${this.$t('tips.pleaseFillIn')}：${dataNull}！`);
                }
            } else {
                callback && callback();
            }
          } else {
            callback && callback();
          }
        },
        // 提交流程
        processSubmit () {
            // 提交
            this.processType === 'next' && this._getProcessNodeInfo();
            // 快速提交
            this.processType === 'quickConsent' && this.handleQuickConsent();
        },
        // 快速同意
        handleQuickConsent() {
            this.getNextProcessInfo();
        },
        // 判断当前节点是否为分支节点
        async checkProcessOver(callback) {
            const overData = {
                processNodeCode: this.nextProcessForm.workflowNextNodes.currentProcessNodeCode,
                taskId: this.nextProcessForm.taskId
            };
            const overRes = await this.$store.dispatch('publicApi/judgeProcessOver', overData);
            // true表示已经执行完成，false表示没执行完成
            this.isProcessOver = overRes.results;
            callback && callback();
        },
        // 获取下一步流程节点信息
        getNextProcessInfo() {
            const nextInfo = this.pageConfigEdit.processParmas.nextInfo;
            const nextParmas = {};
            if (nextInfo.parmasList && nextInfo.parmasList.length) {
                for (const item of nextInfo.parmasList) {
                    nextParmas[item.receive] = this.processTaskInfo[item.value] || this.pageConfigEdit.projectForm[item.value] || '';
                }
            } else {
                nextParmas[nextInfo.parmas] = this.processTaskInfo.taskSid;
            }
            const processParmas = {
                processNodeCode: this.processTaskInfo.processNodeCode,
                taskId: this.processTaskInfo.taskId
            };
            const data = Object.assign(nextParmas, processParmas);
            this.$store.dispatch(nextInfo.url, data).then(res => {
                this.nextProcessForm = res.results;
                this.checkProcessOver(() => {
                    this.nextProcess();
                });
            });
        },
        nextProcess() {
            const currentNodeCode = this.nextProcessForm.workflowNextNodes.currentNodeCode;
            if (this.nextProcessForm.workflowNextNodes === null) {
                this.processName = 'noProcess';
                this.dialogProcess = true;
            } else {
                if (!this.isProcessOver && currentNodeCode !== 'COUNTERSIGN' && currentNodeCode !== 'PARALLEL') {
                    this.$message.error(this.$t('dialog.processOverTips'));
                    return;
                }
                const nextNodes = this.nextProcessForm.workflowNextNodes.nextNodes;
                const workflowTaskApproveNodes = [];
                let sendUsers = [];
                let isSendSms = 0;
                let isSendEmail = 0;
                for (const item of nextNodes) {
                    if (item.nodeCode !== 'END') {
                        workflowTaskApproveNodes.push(
                            {
                                assigneeIds: item.assigneeUsers.map(v => v.id),
                                processNodeCode: item.processNodeCode

                            }
                        );
                        sendUsers = sendUsers.concat(item.copyToUsers.map(v => v.id));
                    }
                }
                if (nextNodes.some(v => v.isSendSms === 1)) {
                    isSendSms = 1;
                }
                if (nextNodes.some(v => v.isSendEmail === 1)) {
                    isSendEmail = 1;
                }
                const data = {
                    comment: this.$t('dialog.agree'),
                    currentProcessNodeCode: this.nextProcessForm.workflowNextNodes.currentProcessNodeCode,
                    isSendSms,
                    isSendEmail,
                    processCode: this.nextProcessForm.workflowNextNodes.processCode,
                    projectId: this.nextProcessForm.projectId,
                    sendUsers: Array.from(new Set(sendUsers)),
                    sid: this.nextProcessForm.sid,
                    taskId: this.nextProcessForm.taskId,
                    taskName: this.nextProcessForm.taskName,
                    workflowTaskApproveNodes,
                    createBy: this.$utils.Auth.hasUserInfo().userId,
                    createByName: this.$utils.Auth.hasUserInfo().userName
                };
                if (nextNodes.some(v => v.nodeCode === 'END') && this.isProcessOver) {
                    // 提交后本条数据将更新为已审批状态。 已审批状态的数据不能撤回，不能修改，不能删除。
                    const mseeage = `${this.$t('dialog.nextTips1')}<br><span style="color:red;">${this.$t('dialog.nextTips2')}</span>`;
                    //  提交流程
                    this.$confirm(mseeage, this.$t('button.startProcess'), {
                        dangerouslyUseHTMLString: true,
                        confirmButtonText: this.$t('button.determine'),
                        cancelButtonText: this.$t('button.close'),
                        type: 'warning'
                    }).then(() => {
                        this.submitNextProcess({ url: this.pageConfigEdit.processParmas.approveSubmit.url, data });
                    }).catch(e => {
                    });
                } else {
                    const currentNodeCode = this.nextProcessForm.workflowNextNodes.currentNodeCode;
                    if (currentNodeCode === 'APPROVAL' || currentNodeCode === 'COUNTERSIGN' || currentNodeCode === 'BEGIN' || currentNodeCode === 'PARALLEL') {
                        for (const item of nextNodes) {
                            // 审批节点
                            if (item.nodeCode === 'APPROVAL' && (item.assigneeUsers.length > 1 || !item.assigneeUsers.length)) {
                                // 下一节点的默认处理人：不存在或者大于1人，请您通过提交按钮手动选择正确的处理人后提交，谢谢！
                                this.$message.error(this.$t('tips.processAPPROVALTips'));
                                return;
                            }
                            // 会签节点
                            if ((item.nodeCode === 'COUNTERSIGN' || currentNodeCode === 'BEGIN') && !item.assigneeUsers.length) {
                                // 下一节点的默认处理人：不存在，请您通过提交按钮手动选择正确的处理人后提交，谢谢！
                                this.$message.error(this.$t('tips.processCOUNTERSIGNTips'));
                                return;
                            }
                        }
                        this.submitNextProcess({ url: this.pageConfigEdit.processParmas.approveSubmit.url, data });
                    } else {
                        // 下一节点为分支任务，需要您通过提交按钮手动提交，谢谢！
                        this.$message.error(this.$t('tips.processBranchTips'));
                    }
                }
            }
        },
        // 委托
        handleEntrust() {
            this.userEntrustFlag = true;
        },
        // 获取员工
        getEntrustUser(arr) {
            if (arr.length === 0) {
                this.$message.error(this.$t('tips.pleaseSelectEntrust'));
                return;
            }
            if (arr[0].id === this.$utils.Auth.hasUserInfo().userId) {
                this.$message.error(this.$t('tips.entrustUserTips'));
                return;
            }
            const that = this;
            // 请输入委托原因或意见
            this.$prompt(`${this.$t('tips.entrustTips')} "${arr[0].userName}"?<br>${this.$t('tips.commentTips')}`, this.$t('dialog.selectEntrust'), {
                confirmButtonText: this.$t('button.determine'),
                cancelButtonText: this.$t('button.close'),
                dangerouslyUseHTMLString: true,
                type: 'warning',
                inputValidator(value) {
                    if (value === undefined || value === '' || value === null) {
                        return that.$t('tips.commentTips');
                    } else if (value.length > 64) {
                        // '请输入64个字符以内的委托原因或意见'
                        return that.$t('tips.commentErrorTips');
                    }
                },
                inputErrorMessage: this.$t('tips.commentTips')
            }).then(({ value }) => {
                this.handleSingleEntrust(arr, value);
            }).catch(() => {
            });
        },
        // 单个委托
        handleSingleEntrust(arr, comment) {
            const params = {
                assigneeId: arr[0].id,
                taskDetailId: this.parmasData.taskDetailId,
                comment
            };
            this.$store.dispatch('publicApi/updateAssigneePublicApi', params).then(res => {
                if (res.status === 0) {
                    this.$message.success(this.$t('tips.entrustSuccess'));
                    this.handleReturnTask();
                } else {
                    this.$message.error(this.$t(`exception.${res.errorCode}`));
                }
                this.userEntrustFlag = false;
            });
        },
        // 返回流程任务页面
        handleReturnTask () {
          const url = `${this.$utils.config.jumpUrl}/portal/#/task`;
          window.open(url, '_self');
        },
        //  判断下面表格 是否禁选
        judegMultitonColumns() {
            this.pageConfigEdit = this.$refs.processEdit.page.PageConfig;
            // 主表 mainFormConfig
            const mainFormConfig = this.pageConfigEdit.mainFormConfig.formList;
            // 主表 mainFormConfigChildren
            const mainFormConfigChildren = this.pageConfigEdit.mainFormConfigChildren ? this.pageConfigEdit.mainFormConfigChildren.formList : [];
            // 子表 subTableConfig
            const subTableConfig = this.pageConfigEdit.subTableConfig;
            // 主表状态 singletonColumns
            const singletonColumns = this.workflowFormColumnsList ? this.workflowFormColumnsList.singletonColumns : [];
            // 子表状态 multitonColumns
            const multitonColumns = this.workflowFormColumnsList ? this.workflowFormColumnsList.multitonColumns : [];
            this.$refs.processEdit.multitonColumns = multitonColumns;
            // 主表状态变更
            for (const item of mainFormConfig) {
                const val = singletonColumns.find(val => item.prop === val.columnCode);
                if (val) {
                    if (item.inputStatus === 'disable' && val.columnStatusCollectCode === 'HIDE') {
                        item.inputStatus = 'hide';
                    } else if (item.inputStatus === 'disable' && item.processStatus) {
                        item.inputStatus = val.columnStatusCollectCode.toLowerCase();
                    } else if (item.inputStatus === 'disable' && !item.processStatus) {
                        item.inputStatus = 'disable';
                    } else if (item.inputStatus === 'hide') {
                        item.inputStatus = 'hide';
                    } else {
                        item.inputStatus = val.columnStatusCollectCode.toLowerCase();
                    }
                    if (item.prop === 'areas') {
                        item.inputStatus = val.columnStatusCollectCode.toLowerCase();
                    }
                } else {
                    if (item.inputStatus === 'hide') {
                        item.inputStatus = 'hide';
                    } else {
                      item.inputStatus = 'disable';
                    }
                }
            }
            // 主表状态变更
            for (const item of mainFormConfigChildren) {
                const val = singletonColumns.find(val => item.prop === val.columnCode);
                if (val) {
                    if (item.inputStatus === 'disable' && val.columnStatusCollectCode === 'HIDE') {
                        item.inputStatus = 'hide';
                    } else if (item.inputStatus === 'disable' && item.processStatus) {
                        item.inputStatus = val.columnStatusCollectCode.toLowerCase();
                    } else if (item.inputStatus === 'disable' && !item.processStatus) {
                        item.inputStatus = 'disable';
                    } else if (item.inputStatus === 'hide') {
                        item.inputStatus = 'hide';
                    } else {
                        item.inputStatus = val.columnStatusCollectCode.toLowerCase();
                    }
                    if (item.prop === 'areas') {
                        item.inputStatus = val.columnStatusCollectCode.toLowerCase();
                    }
                } else {
                    if (item.inputStatus === 'hide') {
                        item.inputStatus = 'hide';
                    } else {
                      item.inputStatus = 'disable';
                    }
                }
            }
            // 子表状态变更
            for (const i in multitonColumns) {
                const item = multitonColumns[i];
                for (const val in subTableConfig) {
                    const subTable = subTableConfig[val];
                    if (item.multitonCode === val) {
                        for (const sub of subTable.tableList.slaveColumns) {
                            if (item.multitonColumns.some(v => v.columnStatusCollectCode === 'DISABLE')) {
                                subTable.subTableButton && subTable.subTableButton.forEach(item => item.disabled = true);
                                subTable.isNaNTableMust = false;
                                if (sub.formType === 'operate') {
                                    sub.buts && sub.buts.forEach(but => {
                                      but.disabled = true;
                                    });
                                }
                            } else if (item.multitonColumns.every(v => v.columnStatusCollectCode === 'HIDE')) {
                                subTable.subTableButton && subTable.subTableButton.forEach(item => item.disabled = true);
                                subTable.isNaNTableMust = false;
                                if (sub.formType === 'operate') {
                                    sub.buts && sub.buts.forEach(but => {
                                      but.disabled = true;
                                    });
                                }
                            } else {
                                if (subTable.isRelationTable && this.nodeCode !== 'BEGIN') {
                                    subTable.subTableButton && subTable.subTableButton.forEach(item => item.disabled = false);
                                    subTable.isNaNTableMust = true;
                                    if (sub.formType === 'operate') {
                                        sub.buts && sub.buts.forEach(but => {
                                          but.disabled = false;
                                        });
                                    }
                                }
                            }
                            const multiton = item.multitonColumns.find(multiton => sub.prop === multiton.columnCode);
                            if (multiton) {
                                if (sub.inputStatus === 'disable' && multiton.columnStatusCollectCode === 'HIDE') {
                                    sub.inputStatus = 'hide';
                                } else if (sub.inputStatus === 'disable' && sub.processStatus) {
                                    sub.inputStatus = multiton.columnStatusCollectCode.toLowerCase();
                                } else if (sub.inputStatus === 'disable' && !sub.processStatus) {
                                    sub.inputStatus = 'disable';
                                } else if (sub.inputStatus === 'disable' && sub.processStatus === 'true') {
                                    sub.inputStatus = 'edit';
                                } else if (sub.inputStatus === 'hide') {
                                    sub.inputStatus = 'hide';
                                } else {
                                    sub.inputStatus = multiton.columnStatusCollectCode.toLowerCase();
                                }
                                if (sub.prop === 'areas') {
                                    sub.inputStatus = multiton.columnStatusCollectCode.toLowerCase();
                                }
                            } else {
                                if (sub.inputStatus === 'hide') {
                                    sub.inputStatus = 'hide';
                                } else {
                                  sub.inputStatus = 'disable';
                                }
                            }
                        }
                        if (subTable.tableList.childrenSlaveColumns) {
                            for (const sub of subTable.tableList.childrenSlaveColumns) {
                                if (item.multitonColumns.some(v => v.columnStatusCollectCode === 'DISABLE')) {
                                    subTable.subTableButton && subTable.subTableButton.forEach(item => item.disabled = true);
                                    subTable.isNaNTableMust = false;
                                    if (sub.formType === 'operate') {
                                        sub.buts && sub.buts.forEach(but => {
                                          but.disabled = true;
                                        });
                                    }
                                } else if (item.multitonColumns.every(v => v.columnStatusCollectCode === 'HIDE')) {
                                    subTable.subTableButton && subTable.subTableButton.forEach(item => item.disabled = true);
                                    subTable.isNaNTableMust = false;
                                    if (sub.formType === 'operate') {
                                        sub.buts && sub.buts.forEach(but => {
                                          but.disabled = true;
                                        });
                                    }
                                } else {
                                    if (subTable.isRelationTable && this.nodeCode !== 'BEGIN') {
                                        subTable.subTableButton && subTable.subTableButton.forEach(item => item.disabled = false);
                                        subTable.isNaNTableMust = true;
                                        if (sub.formType === 'operate') {
                                            sub.buts && sub.buts.forEach(but => {
                                              but.disabled = false;
                                            });
                                        }
                                    }
                                }
                                const multiton = item.multitonColumns.find(multiton => sub.prop === multiton.columnCode);
                                if (multiton) {
                                    if (sub.inputStatus === 'disable' && multiton.columnStatusCollectCode === 'HIDE') {
                                        sub.inputStatus = 'hide';
                                    } else if (sub.inputStatus === 'disable' && sub.processStatus) {
                                        sub.inputStatus = multiton.columnStatusCollectCode.toLowerCase();
                                    } else if (sub.inputStatus === 'disable' && !sub.processStatus) {
                                        sub.inputStatus = 'disable';
                                    } else if (sub.inputStatus === 'disable' && sub.processStatus === 'true') {
                                        sub.inputStatus = 'edit';
                                    } else if (sub.inputStatus === 'hide') {
                                        sub.inputStatus = 'hide';
                                    } else {
                                        sub.inputStatus = multiton.columnStatusCollectCode.toLowerCase();
                                    }
                                    if (sub.prop === 'areas') {
                                        sub.inputStatus = multiton.columnStatusCollectCode.toLowerCase();
                                    }
                                } else {
                                    if (sub.inputStatus === 'hide') {
                                        sub.inputStatus = 'hide';
                                    } else {
                                      sub.inputStatus = 'disable';
                                    }
                                }
                            }
                        }
                    }
                }
            }
            this.$refs.processEdit.pageConfig = this.pageConfigEdit;
            this.$refs.processEdit.pageConfigLoading = true;
        }
    }
};
