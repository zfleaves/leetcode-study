/*
 * @Author: your name
 * @Date: 2020-07-13 09:00:27
 * @LastEditTime: 2023-02-23 16:18:50
 * @LastEditors: wumaoxia 1805428335@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_unit\src\mixins\editMixins.js
 */
import {closeRoute} from 'mixins/index';
import Auth from 'util/auth';
import Utils from 'util';

export const editPage = {
  mixins: [closeRoute],
  data () {
      return {
        pageConfig: {},
        type: 'add',
        id: 0,
        dialogVisible: false,
        deleteList: {},
        pageDisabled: false,
        loading: false,
        pageConfigLoading: true,
        isProcess: false,
        translateName: '',
        pageData: '',
        subTableData: [],
        oldProjectForm: {},
        isSumbitSave: false, // 是否是提交流程,
        editPage: null, // editPage
        wbsFlag: false,
        subTableWbsRow: {},
        wbsDialogConfig: {
          title: `${this.$t('tips.pleaseSelect')}${this.$t('fConfig.progressProcess')}`,
          appendBody: false,
          center: true,
          top: '80px',
          width: '60%',
          span: '0.7'
        },
        isPayDataIncomplete: false // 是否存在未完成的付款单
      };
  },
  created () {
    if (this.$route.name === 'processApprovalPage' || this.$route.name === 'sceneProcessApprovalPage') {
      this.type = this.$base64.decode(this.$route.params.type);
      this.translateName = this.$route.params.translateName;
      this.isProcess = true;
    } else {
      if (!this.$route.params.type) return;
      this.type = this.$base64.decode(this.$route.params.type);
      this.id = Number(this.$base64.decode(this.$route.params.id));
      this.translateName = this.$route.params.translateName;
      if (this.page) {
        if (this.type !== 'add' && this.id) {
          this.pageConfig.projectForm = this.projectForm; // 挂载form 对象
          this._getInfoData(this.id);
        } else {
          this.pageConfig = this.page.PageConfig;
          this.pageConfig.projectForm = this.projectForm; // 挂载form 对象
          this.oldProjectForm = this.$clone(this.projectForm);
          if (this.pageConfig.subTableMatch) {
            for (const item of this.pageConfig.subTableMatch) {
              const slaveColumns = this.pageConfig.subTableConfig[item.assignment].tableList.slaveColumns;
              const tableList = slaveColumns.filter(v => {
                const index = this.$utils.config.currencyList.findIndex(r => r === v.prop);
                if (index >= 0) {
                  return false;
                } else {
                  return true;
                }
              });
              this.$set(this.pageConfig.subTableConfig[item.assignment].tableList, 'slaveColumns', tableList);
              this.$set(this.pageConfig.subTableConfig[item.assignment], 'tableData', this.$clone(this.subTableData));
            }
          }
          this.pageConfigLoading = true;
          // 项目自动赋值
          this.setPorjcetData && this.setPorjcetData();
          // 所属组织自动赋值
          this.setOrgData && this.setOrgData();
        }
      }
    }
    this.pageStatus();
  },
  activated() {
    if (this.page) {
      this.page.init();
      this.pageConfig = this.page.PageConfig;
    }
  },
  methods: {
    // 校验
    repeatCheckData(rule, value, callback, params) {
      if (!value) {
        // 请输入
        callback(new Error(`${this.$t('tips.pleaseEnter')}${this.$t(params.codeName)}`));
      } else {
        this.$store.dispatch(params.url, {[params.keyName]: value, [params.keyId]: this.id || ''}).then(res => {
            if (res.results) {
                // 重复，请重新输入
                callback(new Error(`${this.$t(this.$t(params.codeName))}${this.$t('tips.repeat')}`));
            } else {
                callback();
            }
        });
      }
    },
    // 获取数据
    handleGetInfoData(id = 0, infoUrl, callback) {
      if (Number(id) === 0) {
        this.pageConfig.projectForm = this.projectForm; // 挂载form 对象
        this.pageConfigLoading = true;
        return;
      }
      this.id = id;
      this.loading = true;
      this.$store.dispatch(infoUrl.url, {[infoUrl.params]: this.id}).then(res => {
          const results = this.$clone(res.results);
          if (!results) {
            this.pageConfig = this.page.PageConfig;
            this.pageConfig.projectForm = this.projectForm; // 挂载form 对象
            this.pageConfigLoading = true;
            this.loading = false;
            return;
          }
          if (results.continent) {
            results.areas = [];
            const keysList = ['continent', 'country', 'province', 'city', 'area'];
            for (const key of keysList) {
              if (results[key] && results[key].indexOf('-')) {
                  const id = results[key].split('-')[1];
                  results.areas.push(Number(id));
              }
            }
          }
          this.pageConfig = this.page.PageConfig;
          this.$set(this.pageConfig, 'projectForm', results);
          this.oldProjectForm = this.$clone(results);
          if (this.pageConfig.subTableMatch) {
            for (const item of this.pageConfig.subTableMatch) {
              const slaveColumns = this.pageConfig.subTableConfig[item.assignment].tableList.slaveColumns;
              const tableList = slaveColumns.filter(v => {
                const index = this.$utils.config.currencyList.findIndex(r => r === v.prop);
                if (index >= 0) {
                  return false;
                } else {
                  return true;
                }
              });
              this.$set(this.pageConfig.subTableConfig[item.assignment].tableList, 'slaveColumns', tableList);
              this.$set(this.pageConfig.subTableConfig[item.assignment], 'tableData', results[item.value]);
              if (this.pageConfig.subTableConfig[item.assignment].isSetTableStatus) {
                // this.setSysHandleExportDetailStatus(item.assignment);
              }
            }
          }
          callback && callback();
          this.pageConfigLoading = true;
          this.loading = false;
      });
    },
    // 设置导入明细按钮状态
    setSysHandleExportDetailStatus(tableName) {
      if (this.type !== 'info') return;
      const subTableButton = this.pageConfig.subTableConfig[tableName].subTableButton;
      const index = subTableButton.findIndex(v => v.code === 'sysHandleExportDetail');
      if (index >= 0) {
        this.$set(this.pageConfig.subTableConfig[tableName].subTableButton[index], 'disabled', false);
      }
      this.$forceUpdate();
    },
    // 保存数据
    handleSaveData (data, isProcess = false, callback) {
      this.$set(data, 'currencyCode', '01');
      this.$set(data, 'currencyValue', '人民币CNY');
      this.$set(data, 'currencyPropertyType', '01');
      this.$set(data, 'currencyPropertyName', '人民币CNY');
      if (this.pageConfig.subTableMatch) {
        for (const item of this.pageConfig.subTableMatch) {
          for (const val of data[item.value]) {
            this.$set(val, 'currencyCode', '01');
            this.$set(val, 'currencyValue', '人民币CNY');
            this.$set(val, 'currencyPropertyType', '01');
            this.$set(val, 'currencyPropertyName', '人民币CNY');
          }
        }
      }
      if (!isProcess) {
        this.saveData(data, isProcess, callback);
        return;
      }
      this.pageData = this.$clone(data);
      this.handleProcess();
    },
    // 保存数据
    saveData(data, isProcess, callback) {
      const loadingSubmit = this.$loading({
        lock: true,
        background: 'rgba(0,0,0,0.7)',
        spinner: 'el-icon-loading'
      });
      const saveUrl = this.page.PageConfig.processParmas.saveUrl;
      data.projectId ? data.projectId = data.projectId : data.projectId = null;
      data.projectName ? data.projectName = data.projectName : data.projectName = null;
      this.$store.dispatch(saveUrl.url, data).then(res => {
          const status = this.type === 'add' ? this.$t('button.add') : this.$t('button.edit');
          if (res.status === 0) {
            if (!isProcess) {
              if (this.isSumbitSave) { // 是否是保存流程后提交
                this.handleStartProcess(data, res.results, loadingSubmit); // 传入ID
                this.$message.success(`${status}${this.$t('tips.success')}!`);
              } else {
                // 特殊提示
                if (data.specialTips) {
                  this.$message.success(`${data.specialTips}${this.$t('tips.success')}!`);
                } else {
                  this.$message.success(`${status}${this.$t('tips.success')}!`);
                }
                loadingSubmit.close();
                this.setRoute();
                return;
              }
            }
            loadingSubmit.close();
            callback && callback();
          } else {
            this.$message.error(`${status}${this.$t('tips.fail')}!${this.$t(`exception.${res.errorCode}`)}`);
            loadingSubmit.close();
          }
      }).catch(e => {
        loadingSubmit.close();
      });
    },
    // 保存后 的 提交流程
    handleStartProcess(data, id, loadingSubmit) {
      const infoUrl = this.pageConfig.processParmas.infoUrl;
      this.$store.dispatch(infoUrl.url, {[infoUrl.params]: id}).then(res => {
        const results = this.$clone(res.results);
        const translateName = this.$route.params.translateName;
        const currentMenu = this.$utils.menu.getCurrentMenu(translateName);
        const component = currentMenu.component;
        const componentUrlList = component.split('/');
        componentUrlList[componentUrlList.length - 1] = 'config';
        const SearchPage = require(`views/${componentUrlList.join('/')}.js`).default;
        const searchPage = new SearchPage();
        this.editPage.handleStartProcess && this.editPage.handleStartProcess({ data: results, id, processParmas: searchPage.PageConfig.processParmas});
        loadingSubmit && loadingSubmit.close();
      });
    },
    handleProcess() {
      this.$emit('processSubmit', true);
    },
    // 页面状态
    pageStatus() {
      this.pageDisabled = this.type !== 'info';
      if (this.type === 'info') {
        for (const i in this.page.PageConfig.subTableConfig) {
          const item = this.page.PageConfig.subTableConfig[i];
          item.isSelection = false;
          for (const child of item.tableList.slaveColumns) {
            this.$set(child, 'inputStatus', 'disable');
          }
          for (const but of item.subTableButton) {
            but.disabled === undefined ? (but.disabled = false) : (but.disabled = true);
          }
        }
      }
    },
    editEvent({ eventName, editPage}) {
      if (eventName === 'close') {
        this.isSumbitSave = false;
        this.setRoute();
      }
      if (eventName === 'save') {
        this.isSumbitSave = false;
        this.handleSave();
      }
      if (eventName === 'startProcess') {
        this.isSumbitSave = true;
        this.editPage = editPage;
        this.handleSave(); // 先保存数据
      }
      if (eventName === 'startProcessSaveSuccess') {
        this.isSumbitSave = false;
        this.setRoute();
      }
      if (eventName === 'startProcessSaveFail') {
        this.isSumbitSave = false;
        this.setRoute();
      }
      // 初始化表单
      if (eventName === 'initForm') {
        this.isSumbitSave = false;
        if (!this.page.PageConfig.formCode) {
          this.$message.error('configEdit.js未配置formCode，不能初始化');
          return;
        }
        this.$confirm('<span style="color:red">该操作建议由技术人员进行操作，避免出现不可逆转的功能性问题。</span><br>你确定继续进行该操作吗？',
        `${this.$t(`menu.${this.$route.params.translateName}`)}${this.$t('button.initForm')}`, {
            dangerouslyUseHTMLString: true,
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
        }).then(() => {
          this.checkFormcodeExistPublicApi(() => {
            this.sysInitForm();
          });
        }).catch(() => {
        });
      }
      if (eventName === 'monitorProcess') {
        const projectForm = this.$clone(this.page.PageConfig.projectForm);
        // 判断是否否已提交
        if (projectForm.flowStatus === '0') {
          // 该流程未提交
          this.$message.warning(this.$t('tips.monitorProcessTips2'));
          return;
        }
        if (!projectForm.taskId) {
          // 该数据没有流程
          this.$message.warning(this.$t('tips.monitorProcessTips3'));
          return;
        }
        // 将当前行存储于缓存中 是否为场景流程
        localStorage.setItem('processType', this.page.PageConfig.processType);
        this.$store.commit('diaLog/set_process_dialog', projectForm.taskId);
      }
    },
    // 校验formCode是否存在
    checkFormcodeExistPublicApi(callback) {
      this.$store.dispatch('publicApi/checkFormcodeExistPublicApi', {formCode: this.page.PageConfig.formCode}).then(res => {
        if (res.status === 0) {
          if (res.results) {
            this.$confirm(`<span style="color:red">当前formCode【${this.page.PageConfig.formCode}】已初始化数据。</span><br>你确定继续进行该操作吗？`,
            `${this.$t(`menu.${this.$route.params.translateName}`)}${this.$t('button.initForm')}`, {
                dangerouslyUseHTMLString: true,
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
              callback && callback();
            }).catch(() => {
            });
          } else {
            callback && callback();
          }
        } else {
          this.$message.error('初始化失败，请查看日志');
        }
      });
    },
    sysInitForm() {
      const mainColumns = [];
      const detailsColumns = [];
      const pageConfig = this.page.PageConfig;
      const formList = pageConfig.mainFormConfig.formList;
      const subTableConfig = pageConfig.subTableConfig;
      const subTableMatch = pageConfig.subTableMatch;
      // 主表
      for (const item of formList) {
        if ((item.inputStatus === 'disable' || item.formType === 'operate') && !item.processStatus) {
          continue;
        } else {
          mainColumns.push(
            {
              columnCode: item.prop,
              columnName: this.$t(item.label)
            }
          );
        }
      }
      // 子表
      if (subTableMatch) {
        for (const subTable of subTableMatch) {
          const multitonColumns = [];
          for (const item of subTableConfig[subTable.assignment].tableList.slaveColumns) {
            if ((item.formType === 'operate') && !item.processStatus) {
              continue;
            } else {
              multitonColumns.push(
                {
                  columnCode: item.prop,
                  columnName: this.$t(item.label)
                }
              );
            }
          }
          detailsColumns.push(
            {
              columns: multitonColumns,
              multitonCode: subTable.assignment,
              multitonName: this.$t(`${this.$route.params.translateName}.${subTable.assignment}`)
            }
          );
        }
      }
      let formName = '';
      if (Utils.config.subSystemCode === 'oa') {
        formName = this.$route.meta.title;
      } else {
        formName = this.$t(`menu.${this.$route.params.translateName}`);
      }
      const data = {
        columns: mainColumns,
        details: detailsColumns,
        formCode: this.page.PageConfig.formCode,
        formName,
        position: ''
      };
      // console.log(data, 'data');
      this.$store.dispatch('publicApi/initWorkflowFormPublicApi', data).then(res => {
        if (res.status === 0) {
          this.$message.success('正在初始化，请勿重复点击');
        } else {
          this.$message.error('初始化失败，请查看日志');
        }
      });
    },
    // ------------------------------------- 主表 ----------------------------------------------------
    // 获取编辑表单的项目
    editFormEvent({eventName, params}) {
      if (eventName === 'clearProjcet') {
        this.handleClearProject(params);
      }
      if (eventName === 'projcet') {
        this.handleSelectProject(params);
      }
      if (eventName === 'clearPartyA') {
        this.handleClearPartyA(params);
      }
      if (eventName === 'partyA') {
        this.handleSelectPartyA(params);
      }
      if (eventName === 'clearPartyB') {
        this.handleClearPartyB(params);
      }
      if (eventName === 'partyB') {
        this.handleSelectPartyB(params);
      }
      // 合同
      if (eventName === 'clearContractIncome') {
        this.handleClearContractIncome(params);
      }
      if (eventName === 'contractIncome') {
        this.handleSelectContractIncome(params);
      }
      // 分包计划
      if (eventName === 'clearSubcontract') {
        this.handleClearSubcontract(params);
      }
      if (eventName === 'subcontract') {
        this.handleSelectSubcontract(params);
      }
      if (eventName === 'relationTable') {
        this.handleOtherSelect(params);
      }
      if (eventName === 'clearProjectChild') {
        this.handleClearProjectChild(params);
      }
      if (eventName === 'projectChild') {
        this.handleSelectProjectChild(params);
      }
      if (eventName === 'clearUsePlace') {
        this.handleClearUsePlace(params);
      }
      if (eventName === 'usePlace') {
        this.handleSelectUsePlace(params);
      }
      if (eventName === 'operateFun') {
        this[params.operateFun] && this[params.operateFun](params);
      }
      if (eventName === 'clearUser') { // 清除用户
        this.handleClearUser(params);
      }
      if (eventName === 'user') { // 获取用户
        this.handleSelectUser(params);
      }
      // 所属公司
      if (eventName === 'clearOrg') { // 清除用户
        this.handleClearOrg(params);
      }
      if (eventName === 'org') { // 获取用户
        this.handleSelectOrg(params);
      }
      // 组织权限
      if (eventName === 'clearAsPropertyOrg') { // 清除用户
        this.handleClearAs(params);
      }
      if (eventName === 'asPropertyOrg') { // 获取用户
        this.handleSelectAs(params);
      }
      if (eventName === 'identify') { // 自动识别
        this.handleIdentify(params);
      }
      if (eventName === 'moreIdentifyList') { // 自动识别
        this.handleMoreIdentify(params);
      }
    },
    // 自动识别附件
    handleIdentify(params) {

    },
    // ----------------------------- 项目 -------------------------------
    // 清除项目
    handleClearProject(params) {
      if (params.item && params.item.formType === 'multipleProject') {
        const projectList = this.pageConfig.projectForm[params.item.prop];
        projectList.splice(projectList.indexOf(params.tag), 1);
        return;
      }
      this.handleSelectProject({selectList: [], paramsConfig: params});
    },
    // 选择项目
    handleSelectProject(params) {
      if (params.paramsConfig.check) {
        this.handleCheckProject(params);
        return;
      }
      // 多选项目
      if (params.paramsConfig.formType === 'multipleProject') {
        this.$set(this.pageConfig.projectForm, params.paramsConfig.prop, this.$clone(params.selectList));
        return;
      }
      this.handleSelect(params, 'projectName');
    },
    // ----------------------------- 甲方单位 -------------------------------
    // 清除甲方单位
    handleClearPartyA(params) {
      this.handleSelectPartyA({selectList: [], paramsConfig: params});
    },
    // 选择甲方单位
    handleSelectPartyA(params) {
      this.handleSelect(params, 'partyAName');
    },
    // ----------------------------- 乙方单位 -------------------------------
    // 清除甲方单位
    handleClearPartyB(params) {
      this.handleSelectPartyB({selectList: [], paramsConfig: params});
    },
    // 选择甲方单位
    handleSelectPartyB(params) {
      this.handleSelect(params, 'partyBName');
    },
    // ----------------------------- 收入合同 -------------------------------
    // 清除收入合同
    handleClearContractIncome(params) {
      this.handleSelectContractIncome({selectList: [], paramsConfig: params});
    },
    // 选择收入合同
    handleSelectContractIncome(params) {
      console.log(params, 'params');
      this.handleSelect(params, 'contractName');
    },
    // ----------------------------- 分包计划 -------------------------------
    // 清除分包计划
    handleClearSubcontract(params) {
      this.handleSelectSubcontract({selectList: [], paramsConfig: params});
    },
    // 选择分包计划
    handleSelectSubcontract(params) {
      this.handleSelect(params, 'subcontractContent');
    },
    // ----------------------------- 子工程 -------------------------------
    // 清除子工程
    handleClearProjectChild(params) {
      this.handleSelectProjectChild({selectList: [], paramsConfig: params});
    },
    // 选择子工程
    handleSelectProjectChild(params) {
      this.handleSelect(params, 'usePlaceName');
    },
    // ----------------------------- 目标工程量明细清单 (拟使用部位) -------------------------------
    // 清除目标工程量明细清单
    handleClearUsePlace(params) {
      this.handleSelectUsePlace({selectList: [], paramsConfig: params});
    },
    // 选择目标工程量明细清单
    handleSelectUsePlace(params) {
      this.handleSelect(params, 'projectDetailName');
    },
    // ----------------------------- 员工 ---------------------------------
    // 清除员工
    handleClearUser(params) {
      this.handleSelectUser({selectList: [], paramsConfig: params});
    },
    // 选择子工程
    handleSelectUser(params) {
      this.handleSelect(params, 'userName');
    },
    // ----------------------------- 所属公司 ---------------------------------
    // 清除所属公司
    handleClearOrg(params) {
      this.handleSelectOrg({ selectList: [], paramsConfig: params });
    },
    // 选择所属公司
    handleSelectOrg(params) {
      for (const item of params.selectList) {
        item[params.paramsConfig.prop] = item.orgName;
      }
      this.handleSelect(params, params.paramsConfig.prop);
    },
    // ------------------------------  权限组织 ------------------------------
    handleClearAs(params) {
      this.handleSelectAs({ selectList: [], paramsConfig: params });
    },
    // 选择权限组织
    handleSelectAs(params) {
      this.handleSelect(params, params.paramsConfig.prop);
    },
    // ----------------------------- 其他与子表关联 -------------------------------
    // 下拉选择框
    handleOtherSelect(params) {
      const arr = params.selectList;
      const item = params.paramsConfig;
      const oldRelationForm = params.oldRelationForm;
      const oldProjectForm = this.oldProjectForm;
      let isTableList = false;
      if (!item.isRelationTable && (!item.relationTable || item.relationTable.length === 0)) {
        this.setSelectValue(item, this.pageConfig.projectForm[item.prop]);
        return;
      }
      for (const table of item.relationTable) {
        if (this.pageConfig.subTableConfig[table] && this.pageConfig.subTableConfig[table].tableData.length) {
          isTableList = true;
        }
      }
      if (oldProjectForm[item.prop] && isTableList) {
        const deletMessage = this.$t('tips.chengeDataTips').replace('{keyValue}', this.$t(`${item.label}`));
        this.$confirm(deletMessage, this.$t('tips.dataChangePrompt'), {
          confirmButtonText: this.$t('button.determine'),
          cancelButtonText: this.$t('button.close'),
          dangerouslyUseHTMLString: true,
          type: 'warning'
        }).then(() => {
          for (const table of item.relationTable) {
            this.deleteDetail(table);
          }
          this.setSelectValue(item, this.pageConfig.projectForm[item.prop]);
        }).catch(() => {
          this.$set(this.pageConfig.projectForm, item.prop, oldProjectForm[item.prop] || ''); // 显示值
          this.setSelectValue(item, this.pageConfig.projectForm[item.prop], false); //
          if (item.formType === 'week') {
            this.$refs.editForm.setWeek(this.pageConfig.projectForm.applyDate);
          }
        });
      } else {
        this.setSelectValue(item, this.pageConfig.projectForm[item.prop]);
      }
    },
    // 根据日期判断是月的第几周
    getWeekInMonth(t, item) {
      if (t === undefined || t === '' || t == null) {
        t = new Date();
      } else {
        const _t = new Date();
        _t.setYear(t.getFullYear());
        _t.setMonth(t.getMonth());
        _t.setDate(t.getDate());
        const date = _t.getDate(); // 给定的日期是几号
        _t.setDate(1);
        const d = _t.getDay(); // 1. 得到当前的1号是星期几。
        let fisrtWeekend = d;
        if (d === 0) {
          fisrtWeekend = 1;
          // 1号就是星期天
        } else {
          fisrtWeekend = 7 - d + 1; // 第一周的周未是几号
        }
        if (date <= fisrtWeekend) {
          return 1;
        } else {
          return 1 + Math.ceil((date - fisrtWeekend) / 7);
        }
      }
    },
    // 下拉框联动赋值
    setSelectValue(item, event, cancleFlag = true) {
      this.$set(this.oldProjectForm, item.prop, event);
      if (item.isRelation) {
        item.relationList && item.relationList.forEach(row => {
          let index = 0;
          if (item.formType === 'select') {
            index = item.selectList.findIndex(v => v[item.valueCode] === event);
          } else {
            index = item.selectList.findIndex(v => v.dataCode === event);
          }
          const value = item.selectList[index] ? item.isTranslate ? this.$t(item.selectList[index][row.value]) : item.selectList[index][row.value] : '';
          this.$set(this.pageConfig.projectForm, row.receive, value); // 显示值
          this.$set(this.oldProjectForm, row.receive, value); // 显示值
        });
      }
      if (item.otherOperate && cancleFlag) {
        item.otherOperateFun && this[item.otherOperateFun](item);
      }
    },
    // ----------------------------- 使用弹出框选择后的一系列赋值操作 -------------------------------
    // 确认选择
    handleSelect(params, displayValue, callback) {
      // console.log(params, 'this.pageConfig.projectForm');
      const arr = params.selectList;
      const item = params.paramsConfig;
      if (!callback) { // 弹窗选择后的下拉框回调
        if (item.otherOperate && item.otherOperateFun) {
          callback = this[item.otherOperateFun];
        }
      }
      // 关联子表时
      if (item.relationTable && item.relationTable.length) {
        let isTableList = false;
        for (const table of item.relationTable) {
          if (this.pageConfig.subTableConfig[table] && this.pageConfig.subTableConfig[table].tableData.length) {
            isTableList = true;
          }
        }
        if (this.pageConfig.projectForm[item.prop] && isTableList) {
          this.selectChange(item, arr, displayValue, callback);
        } else {
          this.setRelationData(item, arr, displayValue, callback);
        }
      } else {
        this.setRelationData(item, arr, displayValue, callback);
      }
    },
    // 选择 关联明细删除提示
    selectChange(item, arr, displayValue, callback) {
      const deletMessage = this.$t('tips.chengeDataTips').replace('{keyValue}', this.$t(`fConfig.${displayValue}`));
      this.$confirm(deletMessage, this.$t('tips.dataChangePrompt'), {
        confirmButtonText: this.$t('button.determine'),
        cancelButtonText: this.$t('button.close'),
        dangerouslyUseHTMLString: true,
        type: 'warning'
      }).then(() => {
        for (const table of item.relationTable) {
          this.deleteDetail(table);
        }
        this.setRelationData(item, arr, displayValue, callback);
      }).catch(() => {
      });
    },
    // 主表联动赋值
    setRelationData(item, arr, displayValue, callback) {
      this.$set(this.pageConfig.projectForm, item.prop, arr.length > 0 ? arr[0][displayValue] : ''); // 显示值
      this.$set(this.pageConfig.projectForm, item.key, arr.length > 0 ? arr[0].id : ''); // 关键值
      if (item.isRelation) {
        item.relationList.forEach(row => {
          if (row.isAddress) {
            // 获取详细地址
            let address = '';
            if (arr.length > 0) {
                const continent = arr[0].continent && arr[0].continent.split('-')[0];
                const country = arr[0].country && arr[0].country.split('-')[0];
                const province = arr[0].province && arr[0].province.split('-')[0];
                const city = arr[0].city && arr[0].city.split('-')[0];
                const area = arr[0].area && arr[0].area.split('-')[0];
                address = `${continent}${country}${province}${city}${area}`;
            }
            this.$set(this.pageConfig.projectForm, row.receive, arr.length > 0 ? address : ''); // 显示值
          } else if (row.areaCode) {
            // 货取地址代码
            const areas = [];
            const keysList = ['continent', 'country', 'province', 'city', 'area'];
            for (const key of keysList) {
              if (arr.length && arr[0][key] && arr[0][key].indexOf('-')) {
                  const id = arr[0][key].split('-')[1];
                  areas.push(Number(id));
              }
              this.$set(this.pageConfig.projectForm, key, arr.length && arr[0][key] ? arr[0][key] : ''); // 显示值
            }
            this.$set(this.pageConfig.projectForm, row.receive, arr.length > 0 ? areas : ''); // 显示值
          } else {
            let value = '';
            if (arr.length) {
              value = arr[0][row.value] === undefined ? '' : arr[0][row.value];
            } else {
              value = '';
            }
            this.$set(this.pageConfig.projectForm, row.receive, value); // 显示值
          }
        });
      }
      if (item.clearRelation && item.clearRelation.length) {
        this.clearRelationData(item.clearRelation);
      }
      callback && callback();
      if (item.formType === 'project') {
        // console.log(item.formType, 'item.formType');
        this.setAutoContractIncome(callback);
      }
    },
    // 清除相关连动数据
    clearRelationData(clearList) {
      for (const v of clearList) {
        const index = this.pageConfig.mainFormConfig.formList.findIndex(item => item.prop === v.prop);
        if (index >= 0) {
          this[v.clearFun] && this[v.clearFun](this.pageConfig.mainFormConfig.formList[index]);
        }
      }
    },
    // 收入合同支持自动带出
    setAutoContractIncome(callback) {
      const contract = this.pageConfig.mainFormConfig.formList.find(item => item.formType === 'contractIncome');
      if (!contract) return;
      if (contract.isNotProject) return;
      const data = {
        flowStatus: ['02'],
        contractClassifyId: '',
        contractCode: '',
        contractName: '',
        contractNatureCode: '',
        executionStatus: ['01', '02'],
        partyAUnitId: '',
        partyAUnitName: '',
        projectId: this.pageConfig.projectForm.projectId,
        signTimeFrom: '',
        signTimeTo: '',
        pageNo: 1,
        pageSize: 10
      };
      this.$store.dispatch('publicApi/getContractIncomeSummaryPage', data).then(res => {
        console.log(callback, 'callback');
        // 收入合同赋值
        if (res.results && res.results.records.length === 1) {
          const params = {
            selectList: [res.results.records[0]],
            paramsConfig: contract
          };
          console.log(params, 'params');
          this.handleSelect(params, 'contractName');
        }
      });
    },
    // -------------------------------------------- 子表 ----------------------------------------
    // 子表事件按钮事件传出
    mainOperateBtnSubTable(parameter) {
      this[parameter.code](parameter.subTableCode);
    },
    // 导出明细
    sysHandleExportDetail(tableName) {
      if (this.type === 'add' || this.type === 'edit') {
          this.$message.info(this.$t('tips.exportDetailTips'));
          return;
      }
      const exportParams = {
          url: this.page.PageConfig.processParmas.exportDetail.url,
          params: {
              [this.page.PageConfig.processParmas.exportDetail.params]: this.id
          }
      };
      this.handleExportDetail(exportParams);
    },
    // 导出明细列表操作
    handleExportDetail(exportParams, tableName) {
      const pageName = this.$route.params && this.$route.params.translateName ? this.$route.params.translateName : this.$route.name;
      const tranSlateName = `menu.${pageName}`;
      this.$store.dispatch(exportParams.url, exportParams.params).then(data => {
        if (!data) return;
        const url = window.URL.createObjectURL(new Blob([data]));
        const link = document.createElement('a');
        link.style.display = 'none';
        link.href = url;
        link.setAttribute('download', `${this.$t(tranSlateName)} ${this.$t('dialog.tendersDetail')} ${this.$t('fConfig.excel')}.xls`);
        document.body.appendChild(link);
        link.click();
      });
    },
    // 添加明细
    sysHandleDeletaAdd (tableName) {
      if (this.tableRow) {
        this.pageConfig.subTableConfig[tableName].tableData.push(this.$clone(this.tableRow));
        return ;
      }
      const tableDataRow = this.$clone(this.pageConfig.subTableConfig[tableName].tableList.tableDataRow);
      this.pageConfig.subTableConfig[tableName].tableData.push(tableDataRow);
    },
    // 批量删除
    sysHandleDeletaBatch (tableName, otherOperate) {
      if (otherOperate) {
        this.handleDeleteSubTable(Array.from(this.pageConfig.subTableConfig[tableName].tableData), this.$t(`${this.translateName}.${tableName}`), tableName);
      } else {
        if (this.deleteList[tableName] && this.deleteList[tableName].length) {
          this.handleDeleteSubTable(this.deleteList[tableName], this.$t(`${this.translateName}.${tableName}`), tableName);
        } else {
          this.$message.error(this.$t('tips.pleaseSelectDetailed'));
        }
      }
    },
    // 批量删除操作
    handleDeleteSubTable (arr, keyValue, tableName) {
        if (arr && arr.length > 0) {
            const deletMessage = this.$t('tips.deleteDetailedTips').replace('{keyValue}', keyValue);
            const deleteDetailsMessage = this.$t('tips.deleteDetailsApiTips').replace('{keyValue}', keyValue);
            let messageTips = deletMessage;
            (this.pageConfig.processParmas.deleteDetailsParams && this.pageConfig.processParmas.deleteDetailsParams.url) && (messageTips = deleteDetailsMessage);
            this.$confirm(messageTips, `${this.$t('button.batchDeletion')}${keyValue}`, {
              dangerouslyUseHTMLString: true,
              confirmButtonText: this.$t('button.determine'),
              cancelButtonText: this.$t('button.close'),
              type: 'warning'
            }).then(() => {
              this.deleteDetail(tableName, arr);
            }).catch(e => {});
        } else {
          // 请选择明细清单
          arr && this.$message.error(this.$t('tips.pleaseSelectDetailed'));
        }
    },
    deleteDetail (tableName, deleteList) {
      if (!this.pageConfig.subTableConfig[tableName]) return;
      if (!deleteList) {
        deleteList = Array.from(this.pageConfig.subTableConfig[tableName].tableData);
      }
      deleteList.forEach(v => {
          this.pageConfig.subTableConfig[tableName].tableData.splice(this.pageConfig.subTableConfig[tableName].tableData.indexOf(v), 1);
      });
      if (this.pageConfig.processParmas.deleteDetailsParams && this.pageConfig.processParmas.deleteDetailsParams.url) {
        const deleteDetailsParams = this.pageConfig.processParmas.deleteDetailsParams;
        const deleteIds = deleteList.filter(v => v.id).map(i => i.id);
        deleteIds.length && this.$store.dispatch(deleteDetailsParams.url, deleteIds).then(res => {
          if (res.status === 0) {
            this.$message.success(`${this.$t('button.delete')}${this.$t('tips.success')}!`);
          } else {
            this.$message.error(`${this.$t('button.delete')}${this.$t('tips.fail')}!`);
          }
        });
      }
      this.$refs[tableName][0].clearSelectionTable();
      // 删除后的数值计算回调
      this.deletTableCallback && this.deletTableCallback(tableName);
    },
    // 子表操作事件
    editTableEvent({eventName, params}) {
      if (eventName === 'tableSelect') { // 下拉选择
        this.handleTableSelect(params);
      }
      if (eventName === 'operateDataEvent') { // 数值计算
        this.handleCalculation(params);
      }
      if (eventName === 'handleTable') { // 表格文本操作事件
        params.item && params.item.fn && this[params.item.fn](params);
      }
     if (eventName === 'fnRowName') { // 表格操作按钮
        const {btnParameter, row, index} = params;
        btnParameter.fn && this[btnParameter.fn](row, index);
      }
    },
    // 子表下拉选择赋值
    handleTableSelect({item, row, event, subTable, rowIndex}) {
      item.relationList.forEach(res => {
        let index = 0;
        if (item.formType === 'select') {
          index = item.selectList.findIndex(v => v[item.valueCode] === event);
        } else {
          index = item.selectList.findIndex(v => v.dataCode === event);
        }
        const value = item.selectList[index] ? item.isTranslate ? this.$t(item.selectList[index][res.value]) : item.selectList[index][res.value] : '';
        this.$set(this.pageConfig.subTableConfig[subTable.subTableName].tableData[rowIndex], res.receive, value);
      });
    },
    // 数值计算
    handleCalculation(params) {
    },
    // 行内样式表格方法
    getRowClassName({row, rowIndex}) {
      if (!this.checkRow(row)) {
        return '';
      } else { // 返回true 则爆红
        return 'error-active';
      }
    },
    // 明细模板下载
    sysHandleDownloadTemplate() {
      const pageName = this.$route.params && this.$route.params.translateName ? this.$route.params.translateName : this.$route.name;
      const tranSlateName = `menu.${pageName}`;
      const tableName = this.page.PageConfig.processParmas.dowanloadDetail.tableName;
      const table = `${pageName}.${tableName}`;
      this.$store.dispatch(this.page.PageConfig.processParmas.dowanloadDetail.url).then(data => {
          if (!data) return;
          const url = window.URL.createObjectURL(new Blob([data]));
          const link = document.createElement('a');
          link.style.display = 'none';
          link.href = url;
          link.setAttribute('download', `${this.$t(tranSlateName)} ${this.$t(table)} ${this.$t('fConfig.excel')}.xls`);
          document.body.appendChild(link);
          link.click();
      });
    },
    // ------------------------------- 主表自动赋值 -------------------------
    // 仓库赋值
    setWareHouse(arr) {
      if (arr.length === 0) return;
      const warehouse = this.pageConfig.mainFormConfig.formList.find(v => v.prop === 'warehouseId' && v.inputStatus !== 'disable');
      if (!warehouse) return;
      const { prop, valueCode, selectList } = warehouse;
      if (selectList.length > 1) return;
      this.$set(this.pageConfig.projectForm, prop, arr[0][valueCode]);
      const params = {
        paramsConfig: this.$clone(warehouse),
        selectList: arr,
        oldRelationForm: {}
      };
      this.handleOtherSelect(params);
    },
    // 项目赋值
    setPorjcetData() {
      const project = this.pageConfig.mainFormConfig.formList.find(v => v.formType === 'project' && v.inputStatus !== 'disable');
      if (!project) return;
      const data = {
        pageNo: 1,
        pageSize: 10,
        beginTimeFrom: '',
        beginTimeTo: '',
        orgId: '',
        projectName: '',
        projectStatus: [1, 2, 3],
        projectTypeCode: [],
        projectManagerName: ''
      };
      const url = project.isNoAutn ? 'publicApi/getProjectAllPublicApi' : 'publicApi/getProjectPermissionList';
      if (project.isNoAutn) {
        data.projectStatus = [1, 2, 3]; // 查询已启用且未竣工的项目
      }
      this.$store.dispatch(url, data).then(res => {
        const records = res.results.records;
        if (records.length === 0 || records.length > 1) return;
          const params = {
            paramsConfig: this.$clone(project),
            selectList: [records[0]]
          };
          this.handleSelectProject(params);
      });
    },
    // 所属组织赋值
    setOrgData() {
      const org = this.pageConfig.mainFormConfig.formList.find(v => v.formType === 'orgName' && v.inputStatus !== 'disable' && !v.isShowDepartName);
      if (!org) return;
      const { isShowDepartName, isOnlyCheckDepartName } = org;
      const authorityOrgIdList = this.$utils.Auth.hasUserInfo().data || [];
      this.$store.dispatch('publicApi/getEffectiveOrgTree').then(res => {
        if (res.results.length === 0 || authorityOrgIdList.length > 1 || authorityOrgIdList.length === 0) return;
        if (!isShowDepartName) {
          this.filterOgr(res.results);
        }
        // const firstOrg = res.result[0];
        const firstOrg = this.getSignleOrg(res.results, authorityOrgIdList[0]);
        firstOrg[org.prop] = firstOrg.orgName;
        const params = {
          paramsConfig: this.$clone(org),
          selectList: [firstOrg]
        };
        this.handleSelectOrg(params);
      });
    },
    filterOgr(targetList) { // 遍历后台传来的路由字符串，转换为组件对象
      const filterList = targetList.filter(v => {
        if (v.children && v.children.length) {
          v.children = this.filterOgr(v.children);
        }
        return v.orgAttributeCode !== '04';
      });
      return filterList;
    },
    // 获取单个组织
    getSignleOrg(data, id) {
      // console.log(data, 'data');
      let hasFound = false; // 表示是否有找到id值
      let result = null;
      const fn = function (data) {
        if (Array.isArray(data) && !hasFound) { // 判断是否是数组并且没有的情况下，
          data.forEach(item => {
            if (item.id === id) { // 数据循环每个子项，并且判断子项下边是否有id值
              result = item; // 返回的结果等于每一项
              hasFound = true; // 并且找到id值
            } else if (item.children) {
              fn(item.children); // 递归调用下边的子项
            }
          });
        }
      };
      fn(data); // 调用一下
      return result;
    },
    // 根据项目管控类型显示字段
    async displayFieldsAccordingToProjectControlType(tableName) {
      if (!this.pageConfig.projectForm.costControlRuleCode || !this.pageConfig.projectForm.projectNatureCode) {
      await this.$store.dispatch('publicApi/getProjectInfo', {id: this.pageConfig.projectForm.projectId}).then(res => {
          if (res.status === 0) {
            this.$set(this.pageConfig.projectForm, 'costControlRuleCode', res.results.costControlRuleCode);
            this.$set(this.pageConfig.projectForm, 'costControlRuleValue', res.results.costControlRuleValue);
            this.$set(this.pageConfig.projectForm, 'projectNatureCode', res.results.projectNatureCode);
            this.$set(this.pageConfig.projectForm, 'projectNatureValue', res.results.projectNatureValue);
            this.$set(this.pageConfig.projectForm, 'masterCostControl', res.results.masterCostControl);
          }
        });
      }
      const isProjectNatureB = this.page.PageConfig.subTableConfig[tableName].isProjectNatureB;
      const tableList = this.$clone(this.page.PageConfig.subTableConfig[tableName].tableList.slaveColumns);
      if (isProjectNatureB && this.pageConfig.projectForm.projectNatureCode === '02') {
        for (const item of tableList) {
          item.isProjectNatureAShow && this.$set(item, 'inputStatus', 'hide');
          item.isProjectNatureBShow && this.$set(item, 'formType', 'input');
        }
        this.$set(this.page.PageConfig.subTableConfig[tableName].tableList, 'slaveColumns', tableList);
        // 子表按钮赋值
        const subTableButton = this.page.PageConfig.subTableConfig[tableName].BSubTableButton;
        this.$set(this.page.PageConfig.subTableConfig[tableName], 'subTableButton', subTableButton);
        // 子表校验赋值
        const rules = this.page.PageConfig.subTableConfig[tableName].tableList.BRules;
        this.$set(this.page.PageConfig.subTableConfig[tableName].tableList, 'rules', rules);
        this.projectControlTypePageStatus();
      } else {
        for (const item of tableList) {
          item.isProjectNatureAShow && item.formType !== 'slot' && this.$set(item, 'inputStatus', 'disable');
          item.isProjectNatureBShow && this.$set(item, 'formType', 'text');
        }
        const quantitiesStatus = ['quantitiesName', 'quantitiesCode']; // 所属工程量清单
        const expenseStatus = ['expenseName', 'expenseCode']; // 所属费用科目
        // 精细成本管控 01  执行策划管控03  时显示 所属工程量名称 显示所属工程量名称
        if (this.pageConfig.projectForm.costControlRuleCode === '01' || this.pageConfig.projectForm.costControlRuleCode === '03') {
          for (const i of expenseStatus) {
            const index = tableList.findIndex(v => v.prop === i);
            index >= 0 && this.$set(tableList[index], 'inputStatus', 'hide');
          }
          for (const i of quantitiesStatus) {
            const index = tableList.findIndex(v => v.prop === i);
            index >= 0 && this.$set(tableList[index], 'inputStatus', 'edit');
          }
        }
        // 费用类型管控02  时显示所属费用科目
        if (this.pageConfig.projectForm.costControlRuleCode === '02') {
          for (const i of expenseStatus) {
            const index = tableList.findIndex(v => v.prop === i);
            index >= 0 && this.$set(tableList[index], 'inputStatus', 'edit');
          }
          for (const i of quantitiesStatus) {
            const index = tableList.findIndex(v => v.prop === i);
            index >= 0 && this.$set(tableList[index], 'inputStatus', 'hide');
          }
        }
        this.$set(this.page.PageConfig.subTableConfig[tableName].tableList, 'slaveColumns', tableList);
        if (isProjectNatureB) {
          // 子表按钮赋值
          const subTableButton = this.page.PageConfig.subTableConfig[tableName].ASubTableButton;
          this.$set(this.page.PageConfig.subTableConfig[tableName], 'subTableButton', subTableButton);
          // 子表校验赋值
          const rules = this.page.PageConfig.subTableConfig[tableName].tableList.ARules;
          this.$set(this.page.PageConfig.subTableConfig[tableName].tableList, 'rules', rules);
          this.projectControlTypePageStatus();
        }
      }
    },
    // 页面状态
    projectControlTypePageStatus() {
      this.pageDisabled = this.type !== 'info';
      if (this.type === 'info' && (this.$route.name !== 'processApprovalPage' && this.$route.name !== 'sceneProcessApprovalPage')) {
        for (const i in this.page.PageConfig.subTableConfig) {
          const item = this.page.PageConfig.subTableConfig[i];
          for (const but of item.subTableButton) {
            but.disabled === undefined ? (but.disabled = false) : (but.disabled = true);
          }
        }
      } else {
        for (const i in this.page.PageConfig.subTableConfig) {
          const item = this.page.PageConfig.subTableConfig[i];
          if ((this.$route.name === 'processApprovalPage' || this.$route.name === 'sceneProcessApprovalPage')) {
            if (item.tableList.slaveColumns.some(v => v.inputStatus === 'disable')) {
              item.subTableButton && item.subTableButton.forEach(item => item.disabled = true);
            } else {
              item.subTableButton && item.subTableButton.forEach(item => item.disabled = false);
            }
          }
        }
      }
    },
    // 字段变化后
    changeStyle (row, item) {
      const relationKeyIds = item.relationKeyIds || [];
      if (!relationKeyIds.length) return;
      if (relationKeyIds.length > 1) {
        if ((row[relationKeyIds[0]] || row[relationKeyIds[1]]) && row[item.prop] !== row[item.originProp]) {
          return 'afterStatus';
        }
      }
      if (relationKeyIds.length === 1) {
        if (row[relationKeyIds[0]] && row[item.prop] !== row[item.originProp]) {
          return 'afterStatus';
        }
      }
    },
    // 是否显示变更前
    showChangeProp(row, item) {
      const relationKeyIds = item.relationKeyIds || [];
      if (!relationKeyIds.length) return false;
      if (relationKeyIds.length > 1) {
          if ((row[relationKeyIds[0]] || row[relationKeyIds[1]]) && row[item.prop] !== row[item.originProp]) {
          return true;
          }
      }
      if (relationKeyIds.length === 1) {
          if (row[relationKeyIds[0]] && row[item.prop] !== row[item.originProp]) {
            return true;
          }
      }
    },
    // 变更前数据
    setChangeContent (row, item) {
      return row[item.originProp] ? item.filterName === 'setMoney' ? this.$utils.commonUtil.toQfw(row[item.originProp], item.precision) : row[item.originProp] : '';
    },
    // ------------------------ 子表选择所属进度工序 ---------------------------------
    handleSubTableClearWbs (item, row, rowIndex, tableName) {
        this.$set(this.pageConfig.subTableConfig[tableName].tableData[rowIndex], 'wbs', '');
        this.$set(this.pageConfig.subTableConfig[tableName].tableData[rowIndex], 'taskName', '');
        this.$set(this.pageConfig.subTableConfig[tableName].tableData[rowIndex], 'progressMasterPlanId', '');
    },
    // 选择所属进度工序
    handleSubTableSelectWbs (item, row, rowIndex, tableName) {
        this.subTableWbsRow = { item, row, rowIndex, tableName };
        this.wbsFlag = true;
    },
    // 获取所属进度工序
    getWbs (arr) {
        const { item, row, rowIndex, tableName } = {...this.subTableWbsRow};
        this.$set(this.pageConfig.subTableConfig[tableName].tableData[rowIndex], 'wbs', arr.length > 0 ? arr[0].wbs : '');
        this.$set(this.pageConfig.subTableConfig[tableName].tableData[rowIndex], 'taskName', arr.length > 0 ? arr[0].taskName : '');
        this.$set(this.pageConfig.subTableConfig[tableName].tableData[rowIndex], 'progressMasterPlanId', arr.length > 0 ? arr[0].masterPlanId : '');
        this.wbsFlag = false;
    },
    // 获取合同后判断 所选合同是否有结算单、收票单、付款单  是未审批或审批中状态
    async getContractJudgeSettlePay(parameter, callback) {
      const loading = this.$loading({
        lock: true,
        background: 'rgba(0,0,0,0.7)',
        spinner: 'el-icon-loading'
      });
      const data = {
        pageNo: 1,
        pageSize: 10,
        flowStatus: ['0', '01']
      };
      // 结算
      const settleRes = await this.$store.dispatch(parameter['settle'].url, {...data, ...parameter['settle'].data});
      // 收票
      const billRes = await this.$store.dispatch('publicApi/getContractExpendInvoicePublicApi', {...data, ...parameter['bill'].data});
      // 付款
      const payRes = await this.$store.dispatch(parameter['pay'].url, {...data, ...parameter['pay'].data});
      loading.close();
      const tipsList = [];
      this.isPayDataIncomplete = false;
      if (settleRes.results && settleRes.results.records && settleRes.results.records.length) {
        // 此合同有结算单 还未完成审批，建议您核对后再申请付款，否则会导致付款时的累计结算额不正确。
        tipsList.push(`${tipsList.length + 1}：${this.$t('tips.contractJudgeSettleTips1')}`);
      }
      if (billRes.results && billRes.results.records && billRes.results.records.length) {
        // 此合同有收票单 还未完成审批，建议您核对后再申请付款，否则会导致付款时的累计收票额不正确。
        tipsList.push(`${tipsList.length + 1}：${this.$t('tips.contractJudgeBillTips1')}`);
      }
      if (payRes.results && payRes.results.records && payRes.results.records.length) {
        // 当前合同已有付款申请正在进行中，请等待上一笔付款完成后再提交！
        this.isPayDataIncomplete = true;
        // 此合同有付款单 还未完成审批，建议您核对后再申请付款，否则此单据将不允许保存。
        tipsList.push(`${tipsList.length + 1}：${this.$t('tips.contractJudgePayTips1')}`);
      }
      if (!tipsList.length) {
        callback && callback();
      } else {
          this.$confirm(tipsList.join('</br>'), this.$t('tips.tips'), {
              confirmButtonText: this.$t('button.determine'),
              cancelButtonText: this.$t('button.close'),
              dangerouslyUseHTMLString: true,
              type: 'warning'
          }).then(() => {
            callback && callback();
          });
      }
    }
  }
};
