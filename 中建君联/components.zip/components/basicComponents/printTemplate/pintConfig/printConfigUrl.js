/*
 * @Author: your name
 * @Date: 2020-08-25 11:58:42
 * @LastEditTime: 2022-12-02 14:11:43
 * @LastEditors: zengqin 1058574586@qq.com
 * @Description: In User Settings Edit
 * @FilePath: \web_projectmachinery\src\components\basicComponents\printTemplate\pintConfig\printConfigUrl.js
 */
// 项目管理平台
import promanager from './printConfigUrl/promanager';

export default {
    ...promanager
};
